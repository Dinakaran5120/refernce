import { Tabs } from "expo-router";
import { View, Text, Pressable } from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import type { BottomTabBarProps } from "@react-navigation/bottom-tabs";
import { LinearGradient } from "expo-linear-gradient";
import { Ionicons } from "@expo/vector-icons";
import { useTheme } from "@/context/ThemeContext";
import TopNavBar from "@components/TopNavBar";
import { useConnectionsStore } from "@/store/connectionsStore";
import { useCommunityStore } from "@/store/communityStore";

type IName = React.ComponentProps<typeof Ionicons>["name"];

// Matches Image 1 tab bar: flame | grid | sparkles(center) | chatbubbles | person
const TABS: { name: string; icon: IName; iconActive: IName; label: string }[] = [
  { name: "index",        icon: "flame-outline",       iconActive: "flame",          label: "Discover"  },
  { name: "explore",      icon: "grid-outline",         iconActive: "grid",           label: "Explore"   },
  { name: "post",         icon: "sparkles-outline",     iconActive: "sparkles",       label: "Top Picks" },
  { name: "connections",  icon: "chatbubbles-outline",  iconActive: "chatbubbles",    label: "Chats"     },
  { name: "profile",      icon: "person-outline",       iconActive: "person",         label: "Profile"   },
];

function CustomTabBar({ state, navigation }: BottomTabBarProps) {
  const insets = useSafeAreaInsets();
  const { colors, isDark } = useTheme();

  const activeConvId      = useConnectionsStore(s => s.activeConversationId);
  const activeCall        = useConnectionsStore(s => s.call);
  const activeCommunityId = useCommunityStore(s => s.activeCommunityId);
  if (activeConvId || activeCall || activeCommunityId) return null;

  return (
    <View
      style={{
        backgroundColor: colors.tabBar,
        paddingBottom: insets.bottom || 12,
        paddingTop: 10,
        borderTopWidth: 1,
        borderTopColor: colors.tabBarBorder,
        shadowColor: "#000",
        shadowOffset: { width: 0, height: -3 },
        shadowOpacity: isDark ? 0.5 : 0.08,
        shadowRadius: 12,
        elevation: 20,
      }}
    >
      <View style={{ flexDirection: "row", alignItems: "center" }}>
        {state.routes.map((route, index) => {
          const isActive = state.index === index;
          const tabCfg   = TABS.find(t => t.name === route.name) ?? TABS[0];
          const isCenter = route.name === "post";

          const onPress = () => {
            const event = navigation.emit({ type: "tabPress", target: route.key, canPreventDefault: true });
            if (!isActive && !event.defaultPrevented) navigation.navigate(route.name);
          };

          // ── CENTER sparkle tab (matches Image 1 center sparkle) ──
          if (isCenter) {
            return (
              <View key={route.key} style={{ flex: 1, alignItems: "center" }}>
                <Pressable
                  onPress={onPress}
                  style={({ pressed }) => ({ opacity: pressed ? 0.8 : 1, alignItems: "center" })}
                >
                  <LinearGradient
                    colors={isActive ? [colors.primary, colors.accent] : ["#2A2A2A", "#333333"]}
                    start={{ x: 0, y: 0 }}
                    end={{ x: 1, y: 1 }}
                    style={{
                      width: 46,
                      height: 46,
                      borderRadius: 14,
                      alignItems: "center",
                      justifyContent: "center",
                      shadowColor: isActive ? colors.primary : "transparent",
                      shadowOffset: { width: 0, height: 4 },
                      shadowOpacity: isActive ? 0.55 : 0,
                      shadowRadius: 10,
                      elevation: isActive ? 8 : 0,
                    }}
                  >
                    <Ionicons
                      name={isActive ? tabCfg.iconActive : tabCfg.icon}
                      size={22}
                      color={isActive ? "#fff" : colors.textMuted}
                    />
                  </LinearGradient>
                  <Text
                    style={{
                      fontSize: 10,
                      fontWeight: isActive ? "700" : "500",
                      color: isActive ? colors.primary : colors.textMuted,
                      marginTop: 4,
                      letterSpacing: 0.2,
                    }}
                  >
                    {tabCfg.label}
                  </Text>
                </Pressable>
              </View>
            );
          }

          // ── Regular tab ──
          return (
            <Pressable
              key={route.key}
              onPress={onPress}
              style={({ pressed }) => ({
                flex: 1,
                alignItems: "center",
                opacity: pressed ? 0.6 : 1,
              })}
            >
              <Ionicons
                name={isActive ? tabCfg.iconActive : tabCfg.icon}
                size={24}
                color={isActive ? colors.primary : colors.textMuted}
              />
              <Text
                style={{
                  fontSize: 10,
                  fontWeight: isActive ? "700" : "500",
                  color: isActive ? colors.primary : colors.textMuted,
                  marginTop: 3,
                  letterSpacing: 0.2,
                }}
              >
                {tabCfg.label}
              </Text>
            </Pressable>
          );
        })}
      </View>
    </View>
  );
}

function DynamicHeader() {
  const activeConvId      = useConnectionsStore(s => s.activeConversationId);
  const activeCall        = useConnectionsStore(s => s.call);
  const activeCommunityId = useCommunityStore(s => s.activeCommunityId);
  if (activeConvId || activeCall || activeCommunityId) return null;
  return <TopNavBar />;
}

export default function TabLayout() {
  return (
    <Tabs
      tabBar={props => <CustomTabBar {...props} />}
      screenOptions={{ header: () => <DynamicHeader /> }}
    >
      <Tabs.Screen name="index"        options={{ title: "Discover"    }} />
      <Tabs.Screen name="explore"      options={{ title: "Explore"     }} />
      <Tabs.Screen name="post"         options={{ title: "Top Picks"   }} />
      <Tabs.Screen name="connections"  options={{ title: "Chats"       }} />
      <Tabs.Screen name="communities"  options={{ title: "Communities", href: null }} />
      <Tabs.Screen name="profile"      options={{ title: "Profile", headerShown: false }} />
    </Tabs>
  );
}
