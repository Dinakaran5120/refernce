import { useState, useCallback, useRef } from "react";
import {
  View,
  Text,
  Pressable,
  Animated,
  Dimensions,
  Modal,
  ScrollView,
} from "react-native";
import { LinearGradient } from "expo-linear-gradient";
import { Ionicons } from "@expo/vector-icons";
import { useTheme } from "@/context/ThemeContext";
import { useDiscoverStore } from "@/store/discoverStore";
import { useLastSeen } from "@/hooks/useDiscoverFilters";
import type { NearbyUser } from "@/types/discover";

const { width: W, height: H } = Dimensions.get("window");
export const CARD_W = W - 32;
export const CARD_H = H * 0.58;

const INTENT_COLORS: Record<string, string> = {
  Dating:        "#E63946",
  Friends:       "#B06BFF",
  Hookup:        "#FF8C6B",
  "LGBTQ+":      "#FF6B9D",
  "Open to all": "#FFD166",
};

// ─── Distance chip ────────────────────────────────────────────────────────────
function DistancePill({ km }: { km: number }) {
  const label = km < 1 ? "< 1 km" : `${km.toFixed(1)} km`;
  return (
    <View
      style={{
        flexDirection: "row",
        alignItems: "center",
        backgroundColor: "rgba(0,0,0,0.45)",
        paddingHorizontal: 10,
        paddingVertical: 4,
        borderRadius: 12,
        gap: 4,
      }}
    >
      <Ionicons name="location-outline" size={11} color="#fff" />
      <Text style={{ color: "#fff", fontSize: 11, fontWeight: "700" }}>{label}</Text>
    </View>
  );
}

// ─── Online indicator ─────────────────────────────────────────────────────────
function OnlinePill({ online, lastSeen }: { online: boolean; lastSeen: string }) {
  const ago = useLastSeen(lastSeen);
  if (online) {
    return (
      <View
        style={{
          flexDirection: "row",
          alignItems: "center",
          backgroundColor: "#16a34a",
          paddingHorizontal: 10,
          paddingVertical: 4,
          borderRadius: 12,
          gap: 4,
        }}
      >
        <View style={{ width: 6, height: 6, borderRadius: 3, backgroundColor: "#fff" }} />
        <Text style={{ color: "#fff", fontSize: 11, fontWeight: "700" }}>Online</Text>
      </View>
    );
  }
  return (
    <View
      style={{
        backgroundColor: "rgba(0,0,0,0.4)",
        paddingHorizontal: 10,
        paddingVertical: 4,
        borderRadius: 12,
      }}
    >
      <Text style={{ color: "rgba(255,255,255,0.75)", fontSize: 11, fontWeight: "600" }}>
        {ago}
      </Text>
    </View>
  );
}

// ─── Private profile overlay ──────────────────────────────────────────────────
function PrivateOverlay({
  requestStatus,
  onRequest,
}: {
  requestStatus: NearbyUser["requestStatus"];
  onRequest: () => void;
}) {
  const { colors } = useTheme();
  return (
    <View
      style={{
        position: "absolute",
        top: 0, left: 0, right: 0, bottom: 0,
        borderRadius: 28,
        overflow: "hidden",
        alignItems: "center",
        justifyContent: "center",
        backgroundColor: "rgba(0,0,0,0.55)",
      }}
    >
      <View style={{ alignItems: "center", padding: 24, gap: 12 }}>
        <View
          style={{
            width: 64, height: 64, borderRadius: 32,
            backgroundColor: "rgba(255,255,255,0.15)",
            alignItems: "center", justifyContent: "center",
          }}
        >
          <Ionicons name="lock-closed" size={32} color="#fff" />
        </View>
        <Text style={{ color: "#fff", fontSize: 16, fontWeight: "800", textAlign: "center" }}>
          Private Profile
        </Text>
        <Text
          style={{
            color: "rgba(255,255,255,0.75)",
            fontSize: 13, textAlign: "center", lineHeight: 19,
          }}
        >
          Send a request to view this{"\n"}person's full profile
        </Text>
        <Pressable
          onPress={onRequest}
          style={({ pressed }) => ({
            opacity: pressed ? 0.85 : 1,
            transform: [{ scale: pressed ? 0.96 : 1 }],
          })}
        >
          {requestStatus === "pending" ? (
            <View
              style={{
                paddingHorizontal: 24, paddingVertical: 12,
                borderRadius: 16, borderWidth: 1.5,
                borderColor: "rgba(255,255,255,0.5)",
                backgroundColor: "rgba(255,255,255,0.1)",
              }}
            >
              <Text style={{ color: "#fff", fontWeight: "700", fontSize: 14 }}>
                Request Sent
              </Text>
            </View>
          ) : (
            <LinearGradient
              colors={[colors.primary, colors.accent]}
              start={{ x: 0, y: 0 }} end={{ x: 1, y: 0 }}
              style={{ paddingHorizontal: 24, paddingVertical: 12, borderRadius: 16 }}
            >
              <Text style={{ color: "#fff", fontWeight: "800", fontSize: 14 }}>
                Send Request
              </Text>
            </LinearGradient>
          )}
        </Pressable>
      </View>
    </View>
  );
}

// ─── Photo strip dots ─────────────────────────────────────────────────────────
function PhotoDots({ photos, activeIndex }: { photos: string[]; activeIndex: number }) {
  if (photos.length <= 1) return null;
  return (
    <View
      style={{
        position: "absolute", top: 14, left: 0, right: 0,
        flexDirection: "row", justifyContent: "center", gap: 5,
      }}
    >
      {photos.map((_, i) => (
        <View
          key={i}
          style={{
            width: i === activeIndex ? 20 : 6,
            height: 6, borderRadius: 3,
            backgroundColor: i === activeIndex ? "#fff" : "rgba(255,255,255,0.45)",
          }}
        />
      ))}
    </View>
  );
}

// ─── Profile detail modal ─────────────────────────────────────────────────────
function ProfileModal({
  user, visible, onClose,
}: {
  user: NearbyUser; visible: boolean; onClose: () => void;
}) {
  const { colors } = useTheme();
  const likeUser        = useDiscoverStore((s) => s.likeUser);
  const superLikeUser   = useDiscoverStore((s) => s.superLikeUser);
  const toggleFavourite = useDiscoverStore((s) => s.toggleFavourite);
  const requestProfile  = useDiscoverStore((s) => s.requestProfile);
  const ago             = useLastSeen(user.lastSeen);

  return (
    <Modal
      visible={visible}
      animationType="slide"
      presentationStyle="pageSheet"
      onRequestClose={onClose}
    >
      <View style={{ flex: 1, backgroundColor: colors.background }}>
        {/* Header gradient */}
        <LinearGradient
          colors={user.gradient}
          start={{ x: 0, y: 0 }} end={{ x: 1, y: 1 }}
          style={{ height: 280, alignItems: "center", justifyContent: "center" }}
        >
          <Text style={{ fontSize: 90 }}>{user.avatarEmoji}</Text>

          {/* Close button */}
          <Pressable
            onPress={onClose}
            style={{
              position: "absolute", top: 16, right: 16,
              width: 36, height: 36, borderRadius: 18,
              backgroundColor: "rgba(0,0,0,0.3)",
              alignItems: "center", justifyContent: "center",
            }}
          >
            <Ionicons name="close" size={20} color="#fff" />
          </Pressable>

          {/* Status pills */}
          <View
            style={{
              position: "absolute", bottom: 16, left: 0, right: 0,
              flexDirection: "row", justifyContent: "center", gap: 8,
            }}
          >
            <OnlinePill online={user.online} lastSeen={user.lastSeen} />
            <DistancePill km={user.distanceKm} />
          </View>
        </LinearGradient>

        <ScrollView contentContainerStyle={{ padding: 20, paddingBottom: 48 }}>
          {/* Name row */}
          <View style={{ flexDirection: "row", alignItems: "center", gap: 10, marginBottom: 6 }}>
            <Text style={{ fontSize: 26, fontWeight: "800", color: colors.text, letterSpacing: -0.3 }}>
              {user.name}, {user.age}
            </Text>
            {user.verified && (
              <View
                style={{
                  backgroundColor: "#3b82f6", width: 24, height: 24,
                  borderRadius: 12, alignItems: "center", justifyContent: "center",
                }}
              >
                <Ionicons name="checkmark" size={14} color="#fff" />
              </View>
            )}
            {user.privacy === "private" && (
              <View
                style={{
                  backgroundColor: colors.card, paddingHorizontal: 8, paddingVertical: 3,
                  borderRadius: 8, borderWidth: 1, borderColor: colors.border,
                  flexDirection: "row", alignItems: "center", gap: 4,
                }}
              >
                <Ionicons name="lock-closed-outline" size={11} color={colors.textMuted} />
                <Text style={{ fontSize: 11, color: colors.textMuted, fontWeight: "600" }}>
                  Private
                </Text>
              </View>
            )}
          </View>

          {/* Orientation */}
          <Text style={{ fontSize: 14, color: colors.textMuted, marginBottom: 14 }}>
            {user.orientation} · {user.languages.join(", ")}
          </Text>

          {/* Bio */}
          <Text style={{ fontSize: 15, color: colors.text, lineHeight: 23, marginBottom: 18 }}>
            {user.bio}
          </Text>

          {/* Looking for — section header matching Image 1 right phone */}
          <View
            style={{
              backgroundColor: colors.card,
              borderRadius: 16, padding: 16,
              borderWidth: 1, borderColor: colors.border,
              marginBottom: 14,
            }}
          >
            <View style={{ flexDirection: "row", alignItems: "center", gap: 8, marginBottom: 12 }}>
              <Ionicons name="heart-outline" size={16} color={colors.primary} />
              <Text style={{ fontSize: 13, fontWeight: "800", color: colors.textMuted, letterSpacing: 0.6 }}>
                LOOKING FOR
              </Text>
            </View>
            <View style={{ flexDirection: "row", flexWrap: "wrap", gap: 8 }}>
              {user.lookingFor.map((l) => (
                <LinearGradient
                  key={l}
                  colors={[colors.primary, colors.accent]}
                  start={{ x: 0, y: 0 }} end={{ x: 1, y: 0 }}
                  style={{ paddingHorizontal: 12, paddingVertical: 6, borderRadius: 14 }}
                >
                  <Text style={{ color: "#fff", fontSize: 13, fontWeight: "700" }}>{l}</Text>
                </LinearGradient>
              ))}
            </View>
          </View>

          {/* Essentials — orientation + intent */}
          <View
            style={{
              backgroundColor: colors.card,
              borderRadius: 16, padding: 16,
              borderWidth: 1, borderColor: colors.border,
              marginBottom: 14,
            }}
          >
            <View style={{ flexDirection: "row", alignItems: "center", gap: 8, marginBottom: 12 }}>
              <Ionicons name="sparkles-outline" size={16} color={colors.violet} />
              <Text style={{ fontSize: 13, fontWeight: "800", color: colors.textMuted, letterSpacing: 0.6 }}>
                ESSENTIALS
              </Text>
            </View>
            <View style={{ gap: 8 }}>
              <View style={{ flexDirection: "row", alignItems: "center", gap: 10 }}>
                <Ionicons name="person-outline" size={14} color={colors.textMuted} />
                <Text style={{ fontSize: 14, color: colors.text, fontWeight: "600" }}>{user.orientation}</Text>
              </View>
              <View style={{ flexDirection: "row", alignItems: "center", gap: 10 }}>
                <Ionicons name="language-outline" size={14} color={colors.textMuted} />
                <Text style={{ fontSize: 14, color: colors.text, fontWeight: "600" }}>{user.languages.join(", ")}</Text>
              </View>
              {user.mutualFriends > 0 && (
                <View style={{ flexDirection: "row", alignItems: "center", gap: 10 }}>
                  <Ionicons name="people-outline" size={14} color={colors.textMuted} />
                  <Text style={{ fontSize: 14, color: colors.text, fontWeight: "600" }}>
                    {user.mutualFriends} mutual {user.mutualFriends === 1 ? "friend" : "friends"}
                  </Text>
                </View>
              )}
            </View>
          </View>

          {/* Basics — intent chips */}
          <View
            style={{
              backgroundColor: colors.card,
              borderRadius: 16, padding: 16,
              borderWidth: 1, borderColor: colors.border,
              marginBottom: 20,
            }}
          >
            <View style={{ flexDirection: "row", alignItems: "center", gap: 8, marginBottom: 12 }}>
              <Ionicons name="grid-outline" size={16} color={colors.accent} />
              <Text style={{ fontSize: 13, fontWeight: "800", color: colors.textMuted, letterSpacing: 0.6 }}>
                BASICS
              </Text>
            </View>
            <View style={{ flexDirection: "row", flexWrap: "wrap", gap: 8 }}>
              {user.intent.map((i) => (
                <View
                  key={i}
                  style={{
                    paddingHorizontal: 12, paddingVertical: 6, borderRadius: 14,
                    backgroundColor: (INTENT_COLORS[i] ?? colors.primary) + "22",
                    borderWidth: 1, borderColor: INTENT_COLORS[i] ?? colors.primary,
                  }}
                >
                  <Text style={{ color: INTENT_COLORS[i] ?? colors.primary, fontSize: 13, fontWeight: "700" }}>
                    {i}
                  </Text>
                </View>
              ))}
            </View>
          </View>

          {/* Interests tags */}
          <Text style={{ fontSize: 13, fontWeight: "800", color: colors.textMuted, marginBottom: 10, letterSpacing: 0.6 }}>
            INTERESTS
          </Text>
          <View style={{ flexDirection: "row", flexWrap: "wrap", gap: 8, marginBottom: 24 }}>
            {user.tags.map((tag) => (
              <View
                key={tag}
                style={{
                  paddingHorizontal: 12, paddingVertical: 7, borderRadius: 14,
                  backgroundColor: colors.card, borderWidth: 1, borderColor: colors.border,
                }}
              >
                <Text style={{ color: colors.textSecondary, fontSize: 13, fontWeight: "600" }}>{tag}</Text>
              </View>
            ))}
          </View>

          {/* Action buttons */}
          {user.privacy === "private" && user.requestStatus !== "accepted" ? (
            <Pressable
              onPress={() => requestProfile(user.id)}
              style={({ pressed }) => ({
                opacity: pressed ? 0.85 : 1,
                transform: [{ scale: pressed ? 0.97 : 1 }],
              })}
            >
              <LinearGradient
                colors={
                  user.requestStatus === "pending"
                    ? [colors.muted, colors.textMuted]
                    : [colors.primary, colors.accent]
                }
                start={{ x: 0, y: 0 }} end={{ x: 1, y: 0 }}
                style={{
                  borderRadius: 18, paddingVertical: 17, alignItems: "center", marginBottom: 12,
                }}
              >
                <Text style={{ color: "#fff", fontSize: 15, fontWeight: "800" }}>
                  {user.requestStatus === "pending"
                    ? "Request Sent — Cancel?"
                    : "Request to View Profile"}
                </Text>
              </LinearGradient>
            </Pressable>
          ) : (
            <View style={{ flexDirection: "row", gap: 12 }}>
              <Pressable
                onPress={() => toggleFavourite(user.id)}
                style={({ pressed }) => ({
                  flex: 1, paddingVertical: 16, borderRadius: 16, alignItems: "center",
                  backgroundColor: user.favourited ? "#FFD16622" : colors.card,
                  borderWidth: 1.5,
                  borderColor: user.favourited ? "#FFD166" : colors.border,
                  opacity: pressed ? 0.7 : 1,
                })}
              >
                <Ionicons name={user.favourited ? "star" : "star-outline"} size={22} color={user.favourited ? "#FFD166" : colors.textMuted} />
                <Text style={{ fontSize: 11, fontWeight: "700", color: user.favourited ? "#FFD166" : colors.textMuted, marginTop: 4 }}>
                  {user.favourited ? "Saved" : "Save"}
                </Text>
              </Pressable>

              <Pressable
                onPress={() => { likeUser(user.id); onClose(); }}
                style={({ pressed }) => ({
                  flex: 2, opacity: pressed ? 0.85 : 1,
                  transform: [{ scale: pressed ? 0.97 : 1 }],
                })}
              >
                <LinearGradient
                  colors={user.liked ? [colors.muted, colors.textMuted] : [colors.primary, colors.accent]}
                  start={{ x: 0, y: 0 }} end={{ x: 1, y: 0 }}
                  style={{
                    borderRadius: 16, paddingVertical: 16, alignItems: "center",
                    shadowColor: colors.primary,
                    shadowOffset: { width: 0, height: 4 },
                    shadowOpacity: user.liked ? 0 : 0.3,
                    shadowRadius: 10, elevation: user.liked ? 0 : 4,
                  }}
                >
                  <Ionicons name={user.liked ? "heart-dislike" : "heart"} size={22} color="#fff" />
                  <Text style={{ fontSize: 11, fontWeight: "800", color: "#fff", marginTop: 4 }}>
                    {user.liked ? "Unlike" : "Like"}
                  </Text>
                </LinearGradient>
              </Pressable>
            </View>
          )}
        </ScrollView>
      </View>
    </Modal>
  );
}

// ─── Main DiscoverCard ────────────────────────────────────────────────────────
export function DiscoverCard({ user }: { user: NearbyUser }) {
  const likeUser        = useDiscoverStore((s) => s.likeUser);
  const superLikeUser   = useDiscoverStore((s) => s.superLikeUser);
  const passUser        = useDiscoverStore((s) => s.passUser);
  const toggleFavourite = useDiscoverStore((s) => s.toggleFavourite);
  const requestProfile  = useDiscoverStore((s) => s.requestProfile);

  const [photoIndex, setPhotoIndex] = useState(0);
  const [showModal, setShowModal]   = useState(false);

  const handleTap = useCallback(
    (side: "left" | "right") => {
      if (user.privacy === "private" && user.requestStatus !== "accepted") return;
      if (side === "right" && photoIndex < user.photos.length - 1) {
        setPhotoIndex((i) => i + 1);
      } else if (side === "left" && photoIndex > 0) {
        setPhotoIndex((i) => i - 1);
      }
    },
    [photoIndex, user.photos.length, user.privacy, user.requestStatus]
  );

  const isPrivateBlocked = user.privacy === "private" && user.requestStatus !== "accepted";

  return (
    <>
      <View
        style={{
          width: CARD_W,
          height: CARD_H,
          borderRadius: 28,
          overflow: "hidden",
          marginBottom: 8,
          shadowColor: "#000",
          shadowOffset: { width: 0, height: 10 },
          shadowOpacity: 0.18,
          shadowRadius: 24,
          elevation: 12,
        }}
      >
        {/* Card background */}
        <LinearGradient
          colors={user.gradient}
          start={{ x: 0, y: 0 }} end={{ x: 1, y: 1 }}
          style={{ flex: 1 }}
        >
          {/* Tap zones */}
          <View style={{ flex: 1, flexDirection: "row" }}>
            <Pressable style={{ flex: 1 }} onPress={() => handleTap("left")} />
            <Pressable style={{ flex: 1 }} onPress={() => handleTap("right")} onLongPress={() => setShowModal(true)} />
          </View>

          {/* Avatar */}
          <View
            style={{
              position: "absolute", top: 0, left: 0, right: 0, bottom: 0,
              alignItems: "center", justifyContent: "center",
              pointerEvents: "none",
            }}
          >
            <View
              style={{
                width: 120, height: 120, borderRadius: 60,
                backgroundColor: "rgba(255,255,255,0.25)",
                alignItems: "center", justifyContent: "center",
                borderWidth: 3, borderColor: "rgba(255,255,255,0.55)",
              }}
            >
              {isPrivateBlocked ? (
                <Ionicons name="lock-closed" size={48} color="#fff" />
              ) : (
                <Text style={{ fontSize: 58 }}>
                  {user.photos[photoIndex] ?? user.avatarEmoji}
                </Text>
              )}
            </View>
          </View>

          {/* Photo dots */}
          {!isPrivateBlocked && (
            <PhotoDots photos={user.photos} activeIndex={photoIndex} />
          )}

          {/* Favourite star top-right */}
          <Pressable
            onPress={() => toggleFavourite(user.id)}
            style={({ pressed }) => ({
              position: "absolute", top: 14, right: 14,
              width: 36, height: 36, borderRadius: 18,
              backgroundColor: user.favourited ? "rgba(255,209,102,0.9)" : "rgba(0,0,0,0.35)",
              alignItems: "center", justifyContent: "center",
              opacity: pressed ? 0.7 : 1,
              transform: [{ scale: pressed ? 0.88 : 1 }],
            })}
          >
            <Ionicons name={user.favourited ? "star" : "star-outline"} size={17} color="#fff" />
          </Pressable>

          {/* LIKED stamp */}
          {user.liked && (
            <View
              style={{
                position: "absolute", top: 40, left: 20,
                borderWidth: 3, borderColor: "#22c55e",
                borderRadius: 8, paddingHorizontal: 12, paddingVertical: 4,
                transform: [{ rotate: "-15deg" }],
              }}
            >
              <Text style={{ color: "#22c55e", fontSize: 22, fontWeight: "900", letterSpacing: 1 }}>
                LIKED
              </Text>
            </View>
          )}

          {/* SUPER stamp */}
          {user.superLiked && (
            <View
              style={{
                position: "absolute", top: 40, right: 20,
                borderWidth: 3, borderColor: "#3b82f6",
                borderRadius: 8, paddingHorizontal: 10, paddingVertical: 4,
                transform: [{ rotate: "12deg" }],
              }}
            >
              <Text style={{ color: "#3b82f6", fontSize: 18, fontWeight: "900", letterSpacing: 0.5 }}>
                SUPER
              </Text>
            </View>
          )}

          {/* Bottom info overlay */}
          <LinearGradient
            colors={["transparent", "rgba(0,0,0,0.75)"]}
            style={{
              position: "absolute", bottom: 0, left: 0, right: 0,
              padding: 20, paddingTop: 64,
            }}
            pointerEvents="none"
          >
            {/* Intent + online badges */}
            <View style={{ flexDirection: "row", gap: 6, marginBottom: 8, flexWrap: "wrap" }}>
              {user.intent.map((i) => (
                <View
                  key={i}
                  style={{
                    backgroundColor: INTENT_COLORS[i] ?? "#E63946",
                    paddingHorizontal: 10, paddingVertical: 4, borderRadius: 10,
                  }}
                >
                  <Text style={{ color: "#fff", fontSize: 11, fontWeight: "700" }}>{i}</Text>
                </View>
              ))}
              <OnlinePill online={user.online} lastSeen={user.lastSeen} />
            </View>

            {/* Name + verified */}
            <View style={{ flexDirection: "row", alignItems: "center", gap: 8, marginBottom: 4 }}>
              <Text style={{ color: "#fff", fontSize: 26, fontWeight: "800", letterSpacing: -0.3 }}>
                {user.name}, {user.age}
              </Text>
              {user.verified && (
                <View
                  style={{
                    backgroundColor: "#3b82f6", width: 22, height: 22,
                    borderRadius: 11, alignItems: "center", justifyContent: "center",
                  }}
                >
                  <Ionicons name="checkmark" size={13} color="#fff" />
                </View>
              )}
            </View>

            {/* Distance + orientation */}
            <View style={{ flexDirection: "row", alignItems: "center", gap: 8, marginBottom: 8 }}>
              <DistancePill km={user.distanceKm} />
              <Text style={{ color: "rgba(255,255,255,0.75)", fontSize: 12, fontWeight: "600" }}>
                {user.orientation}
              </Text>
            </View>

            {/* Bio */}
            {!isPrivateBlocked && (
              <Text
                style={{ color: "rgba(255,255,255,0.9)", fontSize: 13, lineHeight: 19, marginBottom: 10 }}
                numberOfLines={2}
              >
                {user.bio}
              </Text>
            )}

            {/* Tags */}
            {!isPrivateBlocked && (
              <View style={{ flexDirection: "row", flexWrap: "wrap", gap: 6 }}>
                {user.tags.slice(0, 3).map((tag) => (
                  <View
                    key={tag}
                    style={{
                      backgroundColor: "rgba(255,255,255,0.18)",
                      paddingHorizontal: 10, paddingVertical: 4,
                      borderRadius: 10, borderWidth: 1, borderColor: "rgba(255,255,255,0.25)",
                    }}
                  >
                    <Text style={{ color: "#fff", fontSize: 11, fontWeight: "600" }}>{tag}</Text>
                  </View>
                ))}
              </View>
            )}
          </LinearGradient>

          {/* Private overlay */}
          {isPrivateBlocked && (
            <PrivateOverlay
              requestStatus={user.requestStatus}
              onRequest={() => requestProfile(user.id)}
            />
          )}

          {/* View profile button */}
          <Pressable
            onPress={() => setShowModal(true)}
            style={({ pressed }) => ({
              position: "absolute", bottom: 20, right: 20,
              backgroundColor: "rgba(255,255,255,0.2)",
              paddingHorizontal: 14, paddingVertical: 7,
              borderRadius: 14, borderWidth: 1, borderColor: "rgba(255,255,255,0.35)",
              opacity: pressed ? 0.7 : 1,
              flexDirection: "row", alignItems: "center", gap: 5,
            })}
          >
            <Text style={{ color: "#fff", fontSize: 12, fontWeight: "700" }}>View profile</Text>
            <Ionicons name="chevron-forward" size={12} color="#fff" />
          </Pressable>
        </LinearGradient>
      </View>

      {/* ── Action buttons row — matches Image 1 left phone exactly ── */}
      <ActionRow
        user={user}
        onLike={() => likeUser(user.id)}
        onSuperLike={() => superLikeUser(user.id)}
        onPass={() => passUser(user.id)}
        onFav={() => toggleFavourite(user.id)}
      />

      <ProfileModal user={user} visible={showModal} onClose={() => setShowModal(false)} />
    </>
  );
}

// ─── Animated Like Button ─────────────────────────────────────────────────────
function AnimatedLikeBtn({ onPress, liked }: { onPress: () => void; liked: boolean }) {
  const { colors } = useTheme();
  const scale = useRef(new Animated.Value(1)).current;

  const onPressIn = () =>
    Animated.spring(scale, { toValue: 0.85, useNativeDriver: true, speed: 50, bounciness: 6 }).start();

  const onPressOut = () =>
    Animated.spring(scale, { toValue: 1, useNativeDriver: true, speed: 22, bounciness: 18 }).start();

  return (
    <Animated.View
      style={{
        transform: [{ scale }],
        width: 66, height: 66, borderRadius: 33, overflow: "hidden",
        shadowColor: liked ? colors.muted : colors.primary,
        shadowOffset: { width: 0, height: 6 },
        shadowOpacity: 0.45, shadowRadius: 14, elevation: 8,
      }}
    >
      <Pressable onPress={onPress} onPressIn={onPressIn} onPressOut={onPressOut} style={{ flex: 1 }}>
        <LinearGradient
          colors={liked ? [colors.muted, colors.textMuted] : [colors.primary, colors.accent]}
          start={{ x: 0, y: 0 }} end={{ x: 1, y: 1 }}
          style={{ flex: 1, alignItems: "center", justifyContent: "center" }}
        >
          <Ionicons name={liked ? "heart-dislike" : "heart"} size={30} color="#fff" />
        </LinearGradient>
      </Pressable>
    </Animated.View>
  );
}

// ─── Action Row — 5-button row matching Image 1 left phone ───────────────────
function ActionRow({
  user, onLike, onSuperLike, onPass, onFav,
}: {
  user: NearbyUser;
  onLike: () => void;
  onSuperLike: () => void;
  onPass: () => void;
  onFav: () => void;
}) {
  const { colors } = useTheme();

  return (
    <View
      style={{
        flexDirection: "row",
        justifyContent: "center",
        alignItems: "center",
        gap: 12,
        paddingVertical: 16,
        marginBottom: 8,
      }}
    >
      {/* 1 — Rewind (gold) */}
      <ActionBtn
        onPress={() => {}}
        size={50}
        borderColor="#FFD166"
        bg={colors.surface}
        shadowColor="#FFD166"
      >
        <Ionicons name="return-up-back" size={22} color="#FFD166" />
      </ActionBtn>

      {/* 2 — Pass (red/coral) */}
      <ActionBtn
        onPress={onPass}
        size={56}
        borderColor="#E63946"
        bg={colors.surface}
        shadowColor="#E63946"
      >
        <Ionicons name="close" size={26} color="#E63946" />
      </ActionBtn>

      {/* 3 — Like (large gradient — center CTA) */}
      <AnimatedLikeBtn onPress={onLike} liked={user.liked} />

      {/* 4 — Super Like (blue star) */}
      <ActionBtn
        onPress={onSuperLike}
        size={56}
        borderColor={user.superLiked ? "#3b82f6" : "#3b82f6"}
        bg={user.superLiked ? "#3b82f622" : colors.surface}
        shadowColor="#3b82f6"
      >
        <Ionicons name="star" size={24} color="#3b82f6" />
      </ActionBtn>

      {/* 5 — Send/Boost (blue paper-plane) */}
      <ActionBtn
        onPress={() => {}}
        size={50}
        borderColor="#3b82f6"
        bg={colors.surface}
        shadowColor="#3b82f6"
      >
        <Ionicons name="paper-plane" size={20} color="#3b82f6" />
      </ActionBtn>
    </View>
  );
}

// ─── Generic animated action button ──────────────────────────────────────────
function ActionBtn({
  onPress, size, borderColor, bg, shadowColor, children,
}: {
  onPress: () => void;
  size: number;
  borderColor: string;
  bg: string;
  shadowColor?: string;
  children: React.ReactNode;
}) {
  const scale = useRef(new Animated.Value(1)).current;

  const onPressIn = () =>
    Animated.spring(scale, { toValue: 0.88, useNativeDriver: true, speed: 50, bounciness: 6 }).start();

  const onPressOut = () =>
    Animated.spring(scale, { toValue: 1, useNativeDriver: true, speed: 28, bounciness: 14 }).start();

  return (
    <Animated.View style={{ transform: [{ scale }] }}>
      <Pressable
        onPress={onPress}
        onPressIn={onPressIn}
        onPressOut={onPressOut}
        style={{
          width: size, height: size, borderRadius: size / 2,
          backgroundColor: bg, borderWidth: 1.5, borderColor,
          alignItems: "center", justifyContent: "center",
          shadowColor: shadowColor ?? "#000",
          shadowOffset: { width: 0, height: 4 },
          shadowOpacity: 0.18, shadowRadius: 10, elevation: 4,
        }}
      >
        {children}
      </Pressable>
    </Animated.View>
  );
}
