import { useState } from "react";
import { View, Text, ScrollView, Pressable, Dimensions } from "react-native";
import { LinearGradient } from "expo-linear-gradient";
import { useRouter } from "expo-router";
import { Colors } from "@constants/theme";
import { useAuthStore } from "@/store/authStore";

const { width: SCREEN_W } = Dimensions.get("window");
const GRID_TILE = (SCREEN_W - 32 - 8) / 3;

const STATS = [
  { label: "Posts",   value: "48"  },
  { label: "Matches", value: "126" },
  { label: "Friends", value: "83"  },
];

const HIGHLIGHTS = [
  { id: "1", label: "Travel", emoji: "✈️", gradient: [Colors.sky, Colors.violet]     as [string, string] },
  { id: "2", label: "Foodie", emoji: "🍜", gradient: [Colors.accent, Colors.gold]    as [string, string] },
  { id: "3", label: "Art",    emoji: "🎨", gradient: [Colors.rose, Colors.violet]    as [string, string] },
  { id: "4", label: "Music",  emoji: "🎵", gradient: [Colors.primary, Colors.accent] as [string, string] },
  { id: "5", label: "Vibes",  emoji: "✨", gradient: [Colors.secondary, Colors.rose] as [string, string] },
];

const GRID_ITEMS = [
  { id: "1", emoji: "🌆", gradient: [Colors.secondary, Colors.rose]  as [string, string], span: 1 },
  { id: "2", emoji: "☕", gradient: [Colors.accent, Colors.gold]     as [string, string], span: 1 },
  { id: "3", emoji: "🎨", gradient: [Colors.violet, Colors.sky]      as [string, string], span: 1 },
  { id: "4", emoji: "🌊", gradient: [Colors.sky, Colors.mint]        as [string, string], span: 2 },
  { id: "5", emoji: "🌸", gradient: [Colors.rose, Colors.secondary]  as [string, string], span: 1 },
  { id: "6", emoji: "🍣", gradient: [Colors.primary, Colors.accent]  as [string, string], span: 1 },
  { id: "7", emoji: "🌙", gradient: [Colors.violet, Colors.rose]     as [string, string], span: 1 },
  { id: "8", emoji: "🌈", gradient: [Colors.gold, Colors.accent]     as [string, string], span: 1 },
];

const INTENT_PILLS = [
  { label: "Dating 💕",  colors: [Colors.primary, Colors.accent]  as [string, string] },
  { label: "Friends 🤝", colors: [Colors.violet, Colors.sky]      as [string, string] },
  { label: "LGBTQ+ 🌈",  colors: [Colors.violet, Colors.rose]     as [string, string] },
];

const INTEREST_TAGS = ["☕ Coffee", "🎵 Indie music", "✈️ Travel", "📸 Photography", "🍜 Ramen", "🌿 Plants"];

export default function ProfileScreen() {
  const router  = useRouter();
  const profile = useAuthStore((s) => s.profile);
  const [activeGrid, setActiveGrid] = useState<"posts" | "liked">("posts");

  const displayName  = profile.name || "Your Name";
  const displayEmoji = profile.photoEmoji || "😊";

  return (
    <ScrollView style={{ flex: 1, backgroundColor: Colors.background }} showsVerticalScrollIndicator={false}>
      {/* Banner */}
      <LinearGradient
        colors={[Colors.primary, Colors.secondary, Colors.accent]}
        start={{ x: 0, y: 0 }} end={{ x: 1, y: 1 }}
        style={{ height: 130, width: "100%" }}
      />

      {/* Avatar row */}
      <View style={{ paddingHorizontal: 20, marginTop: -48, flexDirection: "row", alignItems: "flex-end", justifyContent: "space-between", marginBottom: 16 }}>
        <LinearGradient
          colors={[Colors.primary, Colors.accent]}
          start={{ x: 0, y: 0 }} end={{ x: 1, y: 1 }}
          style={{ width: 90, height: 90, borderRadius: 45, padding: 3, shadowColor: Colors.primary, shadowOffset: { width: 0, height: 4 }, shadowOpacity: 0.35, shadowRadius: 10, elevation: 8 }}
        >
          <View style={{ flex: 1, borderRadius: 43, backgroundColor: Colors.card, alignItems: "center", justifyContent: "center", borderWidth: 2.5, borderColor: Colors.surface }}>
            <Text style={{ fontSize: 40 }}>{displayEmoji}</Text>
          </View>
        </LinearGradient>

        <View style={{ flexDirection: "row", gap: 10, marginBottom: 4 }}>
          {/* Edit Profile */}
          <Pressable
            onPress={() => router.push("/(tabs)/profile/edit")}
            style={({ pressed }) => ({
              paddingHorizontal: 18, paddingVertical: 9,
              borderRadius: 14, borderWidth: 1.5, borderColor: Colors.border,
              backgroundColor: Colors.surface, opacity: pressed ? 0.7 : 1,
            })}
          >
            <Text style={{ color: Colors.text, fontSize: 13, fontWeight: "700" }}>Edit</Text>
          </Pressable>
          {/* Settings */}
          <Pressable
            onPress={() => router.push("/(tabs)/profile/settings")}
            style={({ pressed }) => ({
              width: 38, height: 38, borderRadius: 14,
              borderWidth: 1.5, borderColor: Colors.border,
              backgroundColor: Colors.surface,
              alignItems: "center", justifyContent: "center",
              opacity: pressed ? 0.7 : 1,
            })}
          >
            <Text style={{ fontSize: 18 }}>⚙</Text>
          </Pressable>
        </View>
      </View>

      {/* Name & bio */}
      <View style={{ paddingHorizontal: 20, marginBottom: 16, gap: 6 }}>
        <View style={{ flexDirection: "row", alignItems: "center", gap: 8 }}>
          <Text style={{ fontSize: 22, fontWeight: "800", color: Colors.text, letterSpacing: -0.3 }}>
            {displayName}
          </Text>
          <View style={{ backgroundColor: "#3b82f6", width: 22, height: 22, borderRadius: 11, alignItems: "center", justifyContent: "center" }}>
            <Text style={{ color: "#fff", fontSize: 12, fontWeight: "800" }}>✓</Text>
          </View>
        </View>
        <Text style={{ color: Colors.textSecondary, fontSize: 14 }}>@{(displayName || "you").toLowerCase().replace(/\s+/g,"_")} · Mumbai, IN 📍</Text>
        <Text style={{ color: Colors.text, fontSize: 14, lineHeight: 21, marginTop: 4 }}>
          Living in colour ✨ Coffee addict, sunset chaser, music lover.{"\n"}Here for connections that feel real 🌈
        </Text>
        <View style={{ flexDirection: "row", gap: 8, marginTop: 8, flexWrap: "wrap" }}>
          {INTENT_PILLS.map((pill) => (
            <LinearGradient key={pill.label} colors={pill.colors} start={{ x: 0, y: 0 }} end={{ x: 1, y: 0 }} style={{ paddingHorizontal: 12, paddingVertical: 5, borderRadius: 14 }}>
              <Text style={{ color: "#fff", fontSize: 12, fontWeight: "700" }}>{pill.label}</Text>
            </LinearGradient>
          ))}
        </View>
      </View>

      {/* Quick actions — Notifications and Settings shortcuts */}
      <View style={{ flexDirection: "row", paddingHorizontal: 20, gap: 10, marginBottom: 16 }}>
        <Pressable
          onPress={() => router.push("/(tabs)/profile/notifications")}
          style={({ pressed }) => ({
            flex: 1, flexDirection: "row", alignItems: "center", gap: 8,
            padding: 12, borderRadius: 14, backgroundColor: Colors.card,
            borderWidth: 1, borderColor: Colors.border, opacity: pressed ? 0.7 : 1,
          })}
        >
          <Text style={{ fontSize: 18 }}>🔔</Text>
          <Text style={{ fontSize: 13, fontWeight: "700", color: Colors.textSecondary }}>Notifications</Text>
          <Text style={{ fontSize: 14, color: Colors.textMuted, marginLeft: "auto" }}>›</Text>
        </Pressable>
        <Pressable
          onPress={() => router.push("/(tabs)/profile/settings")}
          style={({ pressed }) => ({
            flex: 1, flexDirection: "row", alignItems: "center", gap: 8,
            padding: 12, borderRadius: 14, backgroundColor: Colors.card,
            borderWidth: 1, borderColor: Colors.border, opacity: pressed ? 0.7 : 1,
          })}
        >
          <Text style={{ fontSize: 18 }}>⚙</Text>
          <Text style={{ fontSize: 13, fontWeight: "700", color: Colors.textSecondary }}>Settings</Text>
          <Text style={{ fontSize: 14, color: Colors.textMuted, marginLeft: "auto" }}>›</Text>
        </Pressable>
      </View>

      {/* Stats */}
      <View style={{ flexDirection: "row", marginHorizontal: 20, backgroundColor: Colors.surface, borderRadius: 20, paddingVertical: 14, marginBottom: 20, borderWidth: 1, borderColor: Colors.border, shadowColor: "#000", shadowOffset: { width: 0, height: 2 }, shadowOpacity: 0.05, shadowRadius: 8, elevation: 2 }}>
        {STATS.map((stat, i) => (
          <View key={stat.label} style={{ flex: 1, alignItems: "center", gap: 3, borderRightWidth: i < STATS.length - 1 ? 1 : 0, borderRightColor: Colors.border }}>
            <Text style={{ fontSize: 20, fontWeight: "800", color: Colors.text }}>{stat.value}</Text>
            <Text style={{ fontSize: 12, color: Colors.textMuted, fontWeight: "600" }}>{stat.label}</Text>
          </View>
        ))}
      </View>

      {/* Highlights */}
      <ScrollView horizontal showsHorizontalScrollIndicator={false} contentContainerStyle={{ paddingHorizontal: 20, gap: 14, paddingBottom: 4 }} style={{ marginBottom: 20 }}>
        {HIGHLIGHTS.map((h) => (
          <Pressable key={h.id} style={({ pressed }) => ({ alignItems: "center", gap: 6, opacity: pressed ? 0.7 : 1 })}>
            <LinearGradient colors={h.gradient} start={{ x: 0, y: 0 }} end={{ x: 1, y: 1 }} style={{ width: 64, height: 64, borderRadius: 32, alignItems: "center", justifyContent: "center" }}>
              <Text style={{ fontSize: 28 }}>{h.emoji}</Text>
            </LinearGradient>
            <Text style={{ fontSize: 11, color: Colors.textSecondary, fontWeight: "600" }}>{h.label}</Text>
          </Pressable>
        ))}
        <Pressable
          onPress={() => router.push("/(tabs)/profile/edit")}
          style={{ alignItems: "center", gap: 6 }}
        >
          <View style={{ width: 64, height: 64, borderRadius: 32, backgroundColor: Colors.card, alignItems: "center", justifyContent: "center", borderWidth: 1.5, borderColor: Colors.border, borderStyle: "dashed" }}>
            <Text style={{ fontSize: 24 }}>+</Text>
          </View>
          <Text style={{ fontSize: 11, color: Colors.textMuted, fontWeight: "600" }}>New</Text>
        </Pressable>
      </ScrollView>

      {/* Interests */}
      <View style={{ paddingHorizontal: 20, marginBottom: 20 }}>
        <View style={{ flexDirection: "row", alignItems: "center", justifyContent: "space-between", marginBottom: 10 }}>
          <Text style={{ fontSize: 14, fontWeight: "700", color: Colors.text }}>My interests</Text>
          <Pressable onPress={() => router.push("/(tabs)/profile/edit")}>
            <Text style={{ fontSize: 13, color: Colors.primary, fontWeight: "700" }}>Edit</Text>
          </Pressable>
        </View>
        <View style={{ flexDirection: "row", flexWrap: "wrap", gap: 8 }}>
          {(profile.interests && profile.interests.length > 0 ? profile.interests : INTEREST_TAGS).map((tag) => (
            <View key={tag} style={{ paddingHorizontal: 14, paddingVertical: 7, borderRadius: 16, backgroundColor: Colors.card, borderWidth: 1, borderColor: Colors.border }}>
              <Text style={{ color: Colors.textSecondary, fontSize: 13, fontWeight: "600" }}>{tag}</Text>
            </View>
          ))}
        </View>
      </View>

      {/* Grid tab switcher */}
      <View style={{ flexDirection: "row", borderTopWidth: 1, borderTopColor: Colors.border, marginBottom: 4 }}>
        {(["posts", "liked"] as const).map((tab) => {
          const isActive = activeGrid === tab;
          return (
            <Pressable key={tab} onPress={() => setActiveGrid(tab)} style={{ flex: 1, paddingVertical: 12, alignItems: "center", borderBottomWidth: 2, borderBottomColor: isActive ? Colors.primary : "transparent" }}>
              <Text style={{ fontSize: 20 }}>{tab === "posts" ? "▦" : "♥"}</Text>
            </Pressable>
          );
        })}
      </View>

      {/* Photo grid */}
      <View style={{ flexDirection: "row", flexWrap: "wrap", gap: 4, paddingHorizontal: 16, paddingBottom: 40 }}>
        {GRID_ITEMS.map((item) => {
          const isWide = item.span === 2;
          return (
            <Pressable key={item.id} style={({ pressed }) => ({ width: isWide ? GRID_TILE * 2 + 4 : GRID_TILE, height: GRID_TILE, borderRadius: 12, overflow: "hidden", opacity: pressed ? 0.85 : 1, transform: [{ scale: pressed ? 0.97 : 1 }] })}>
              <LinearGradient colors={item.gradient} start={{ x: 0, y: 0 }} end={{ x: 1, y: 1 }} style={{ flex: 1, alignItems: "center", justifyContent: "center" }}>
                <Text style={{ fontSize: isWide ? 36 : 28 }}>{item.emoji}</Text>
              </LinearGradient>
            </Pressable>
          );
        })}
      </View>
    </ScrollView>
  );
}
