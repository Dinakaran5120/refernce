import { useState } from "react";
import {
  View, Text, ScrollView, Pressable,
  Dimensions, ImageBackground,
} from "react-native";
import { LinearGradient } from "expo-linear-gradient";
import { Ionicons } from "@expo/vector-icons";
import { useTheme } from "@/context/ThemeContext";
import { useDiscoverStore } from "@/store/discoverStore";
import { useDiscoverFilters } from "@/hooks/useDiscoverFilters";
import { FilterSheet } from "@components/discover/FilterSheet";
import { DiscoverCard } from "@components/discover/DiscoverCard";
import { EmptyDiscover } from "@components/discover/EmptyDiscover";
import type { NearbyUser } from "@/types/discover";

const { width: W } = Dimensions.get("window");
const CARD_W = (W - 48) / 2;   // 2-col grid with 16px side padding + 16px gap
const CARD_H = CARD_W * 1.38;

type DiscoverMode = "likes" | "topPicks";

// ── 2-col profile card matching Image 1 center phone ─────────────────────────
function ProfileGridCard({ user, onPress }: { user: NearbyUser; onPress: () => void }) {
  const { colors } = useTheme();
  const [bookmarked, setBookmarked] = useState(false);

  return (
    <Pressable
      onPress={onPress}
      style={({ pressed }) => ({
        width: CARD_W,
        height: CARD_H,
        borderRadius: 20,
        overflow: "hidden",
        opacity: pressed ? 0.92 : 1,
        transform: [{ scale: pressed ? 0.975 : 1 }],
        shadowColor: "#000",
        shadowOffset: { width: 0, height: 8 },
        shadowOpacity: 0.35,
        shadowRadius: 16,
        elevation: 10,
      })}
    >
      {/* Card background gradient */}
      <LinearGradient
        colors={user.gradient as [string, string]}
        start={{ x: 0, y: 0 }}
        end={{ x: 1, y: 1 }}
        style={{ flex: 1 }}
      >
        {/* ── Top row: online badge + bookmark ── */}
        <View style={{ flexDirection: "row", justifyContent: "space-between", alignItems: "flex-start", padding: 10 }}>
          {/* Recently Active badge */}
          {user.online ? (
            <View
              style={{
                flexDirection: "row",
                alignItems: "center",
                backgroundColor: "rgba(0,0,0,0.45)",
                paddingHorizontal: 7,
                paddingVertical: 4,
                borderRadius: 10,
                gap: 4,
              }}
            >
              <View style={{ width: 6, height: 6, borderRadius: 3, backgroundColor: "#22c55e" }} />
              <Text style={{ color: "#fff", fontSize: 9, fontWeight: "700" }}>Recently Active</Text>
            </View>
          ) : (
            <View />
          )}

          {/* Bookmark icon — blue, matching Image 1 */}
          <Pressable
            onPress={() => setBookmarked(b => !b)}
            style={{
              width: 30,
              height: 30,
              borderRadius: 15,
              backgroundColor: bookmarked ? "#3b82f6" : "rgba(0,0,0,0.4)",
              alignItems: "center",
              justifyContent: "center",
            }}
          >
            <Ionicons
              name={bookmarked ? "bookmark" : "bookmark-outline"}
              size={14}
              color="#fff"
            />
          </Pressable>
        </View>

        {/* ── Avatar centered ── */}
        <View style={{ flex: 1, alignItems: "center", justifyContent: "center" }}>
          <View
            style={{
              width: 68,
              height: 68,
              borderRadius: 34,
              backgroundColor: "rgba(255,255,255,0.22)",
              alignItems: "center",
              justifyContent: "center",
              borderWidth: 2.5,
              borderColor: "rgba(255,255,255,0.45)",
            }}
          >
            <Text style={{ fontSize: 34 }}>{user.avatarEmoji}</Text>
          </View>
        </View>

        {/* ── Bottom gradient overlay with name ── */}
        <LinearGradient
          colors={["transparent", "rgba(0,0,0,0.72)"]}
          style={{ paddingHorizontal: 12, paddingBottom: 12, paddingTop: 32 }}
          pointerEvents="none"
        >
          <Text style={{ color: "#fff", fontSize: 15, fontWeight: "800", letterSpacing: -0.3 }}>
            {user.name} {user.age}
          </Text>
          {user.verified && (
            <View style={{ flexDirection: "row", alignItems: "center", gap: 4, marginTop: 2 }}>
              <Ionicons name="checkmark-circle" size={13} color="#3b82f6" />
              <Text style={{ color: "rgba(255,255,255,0.7)", fontSize: 11 }}>Verified</Text>
            </View>
          )}
        </LinearGradient>
      </LinearGradient>
    </Pressable>
  );
}

// ── Section header ─────────────────────────────────────────────────────────────
function SectionHead({ title, onSeeMore }: { title: string; onSeeMore?: () => void }) {
  const { colors } = useTheme();
  return (
    <View style={{ flexDirection: "row", justifyContent: "space-between", alignItems: "center", paddingHorizontal: 16, paddingTop: 20, paddingBottom: 12 }}>
      <Text style={{ fontSize: 18, fontWeight: "800", color: colors.text, letterSpacing: -0.3 }}>
        {title}
      </Text>
      {onSeeMore && (
        <Pressable onPress={onSeeMore}>
          <Text style={{ fontSize: 13, color: colors.textMuted, fontWeight: "600" }}>See More</Text>
        </Pressable>
      )}
    </View>
  );
}

// ── "1 Like | Top Picks" mode switcher — matches Image 1 exactly ─────────────
function ModeSwitcher({ mode, onSelect }: { mode: DiscoverMode; onSelect: (m: DiscoverMode) => void }) {
  const { colors, isDark } = useTheme();

  const pill = (label: string, value: DiscoverMode) => {
    const active = mode === value;
    return (
      <Pressable
        key={value}
        onPress={() => onSelect(value)}
        style={{
          paddingHorizontal: 22,
          paddingVertical: 9,
          borderRadius: 24,
          backgroundColor: active
            ? "#fff"
            : "transparent",
          borderWidth: active ? 0 : 1.5,
          borderColor: active ? "transparent" : "rgba(255,255,255,0.35)",
        }}
      >
        <Text
          style={{
            fontSize: 14,
            fontWeight: "700",
            color: active ? "#111" : "rgba(255,255,255,0.85)",
          }}
        >
          {label}
        </Text>
      </Pressable>
    );
  };

  return (
    <View
      style={{
        flexDirection: "row",
        justifyContent: "center",
        alignItems: "center",
        gap: 8,
        paddingVertical: 14,
        paddingHorizontal: 16,
      }}
    >
      {pill("1 Like", "likes")}
      {pill("Top Picks", "topPicks")}
    </View>
  );
}

// ── Main Discover Screen ───────────────────────────────────────────────────────
export default function DiscoverScreen() {
  const { colors, isDark } = useTheme();
  const [mode, setMode]     = useState<DiscoverMode>("topPicks");
  const [showAllCards, setShowAllCards] = useState(false);

  const filteredUsers = useDiscoverFilters();
  const setShowSheet  = useDiscoverStore(s => s.setShowFilterSheet);

  const onlineUsers      = filteredUsers.filter(u => u.online);
  const offlineUsers     = filteredUsers.filter(u => !u.online);

  // "Likes" mode: show users who liked you (mock: first 4 reversed)
  const likedYouUsers = [...filteredUsers].reverse().slice(0, 6);

  return (
    <View style={{ flex: 1, backgroundColor: colors.background }}>

      {/* ── Mode switcher "1 Like | Top Picks" ── */}
      <ModeSwitcher mode={mode} onSelect={setMode} />

      {/* ── Filter row ── */}
      <View style={{ flexDirection: "row", alignItems: "center", paddingHorizontal: 16, paddingBottom: 4, gap: 8 }}>
        <Pressable
          onPress={() => setShowSheet(true)}
          style={{
            flexDirection: "row",
            alignItems: "center",
            gap: 6,
            paddingHorizontal: 14,
            paddingVertical: 7,
            borderRadius: 12,
            backgroundColor: colors.card,
            borderWidth: 1,
            borderColor: colors.border,
          }}
        >
          <Ionicons name="options-outline" size={15} color={colors.textMuted} />
          <Text style={{ fontSize: 13, fontWeight: "600", color: colors.textMuted }}>Filters</Text>
        </Pressable>

        <View style={{ flex: 1 }} />

        <Pressable
          onPress={() => useDiscoverStore.getState().setFilters({ onlineOnly: !useDiscoverStore.getState().filters.onlineOnly })}
          style={{
            flexDirection: "row",
            alignItems: "center",
            gap: 5,
            paddingHorizontal: 14,
            paddingVertical: 7,
            borderRadius: 12,
            backgroundColor: colors.card,
            borderWidth: 1,
            borderColor: colors.border,
          }}
        >
          <View style={{ width: 7, height: 7, borderRadius: 4, backgroundColor: "#22c55e" }} />
          <Text style={{ fontSize: 13, fontWeight: "600", color: colors.textMuted }}>Online</Text>
        </Pressable>
      </View>

      <ScrollView showsVerticalScrollIndicator={false} contentContainerStyle={{ paddingBottom: 32 }}>

        {/* ── "Likes" mode ── */}
        {mode === "likes" && (
          <>
            {likedYouUsers.length === 0 ? (
              <EmptyDiscover />
            ) : (
              <>
                <SectionHead title="Liked You" />
                <View style={{ flexDirection: "row", flexWrap: "wrap", paddingHorizontal: 16, gap: 16 }}>
                  {likedYouUsers.map(user => (
                    <ProfileGridCard key={user.id + "_like"} user={user} onPress={() => {}} />
                  ))}
                </View>
              </>
            )}
          </>
        )}

        {/* ── "Top Picks" mode — matches Image 1 center phone exactly ── */}
        {mode === "topPicks" && (
          <>
            {filteredUsers.length === 0 ? (
              <EmptyDiscover />
            ) : (
              <>
                {/* Recently Active section */}
                {onlineUsers.length > 0 && (
                  <>
                    <SectionHead title="Recently Active" />
                    <View style={{ flexDirection: "row", flexWrap: "wrap", paddingHorizontal: 16, gap: 16 }}>
                      {onlineUsers.slice(0, 4).map(user => (
                        <ProfileGridCard key={user.id} user={user} onPress={() => {}} />
                      ))}
                    </View>
                  </>
                )}

                {/* Recommended section */}
                {offlineUsers.length > 0 && (
                  <>
                    <SectionHead title="Recommended" onSeeMore={() => setShowAllCards(v => !v)} />
                    <View style={{ flexDirection: "row", flexWrap: "wrap", paddingHorizontal: 16, gap: 16 }}>
                      {offlineUsers.slice(0, 4).map(user => (
                        <ProfileGridCard key={user.id} user={user} onPress={() => {}} />
                      ))}
                    </View>
                  </>
                )}

                {/* Divider + Swipe Cards */}
                <View style={{ marginTop: 24 }}>
                  <View style={{ flexDirection: "row", alignItems: "center", paddingHorizontal: 16, marginBottom: 16, gap: 10 }}>
                    <View style={{ flex: 1, height: 1, backgroundColor: colors.border }} />
                    <Text style={{ fontSize: 11, color: colors.textMuted, fontWeight: "700", letterSpacing: 0.6 }}>
                      SWIPE CARDS
                    </Text>
                    <View style={{ flex: 1, height: 1, backgroundColor: colors.border }} />
                  </View>

                  <View style={{ alignItems: "center", paddingHorizontal: 16, gap: 4 }}>
                    {(showAllCards ? filteredUsers : filteredUsers.slice(0, 3)).map(user => (
                      <DiscoverCard key={user.id + "_swipe"} user={user} />
                    ))}
                  </View>
                </View>
              </>
            )}
          </>
        )}

      </ScrollView>

      <FilterSheet />
    </View>
  );
}
