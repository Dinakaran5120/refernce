import { useRef, useEffect, useCallback } from "react";
import {
  View,
  Text,
  Pressable,
  Modal,
  ScrollView,
  Animated,
  Dimensions,
} from "react-native";
import { LinearGradient } from "expo-linear-gradient";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import { useTheme } from "@/context/ThemeContext";
import { useDiscoverStore } from "@/store/discoverStore";
import { useActiveFilterCount } from "@/hooks/useDiscoverFilters";
import type { Orientation, Intent, DiscoverFilters } from "@/types/discover";

const { height: H } = Dimensions.get("window");
const SHEET_H = H * 0.88;

const ORIENTATIONS: Orientation[] = [
  "Straight", "Gay", "Lesbian", "Bisexual",
  "Pansexual", "Queer", "Asexual", "Questioning",
];

const INTENTS: Intent[] = [
  "Dating", "Friends", "Hookup", "LGBTQ+", "Open to all",
];

const DISTANCE_PRESETS = [5, 10, 25, 50, 100];
const AGE_MIN_OPTS     = [18, 20, 22, 25, 28, 30];
const AGE_MAX_OPTS     = [25, 30, 35, 40, 45, 50, 60];

// ─── Chip ─────────────────────────────────────────────────────────────────────
function FilterChip({
  label, selected, onPress, color,
}: {
  label: string; selected: boolean; onPress: () => void; color?: string;
}) {
  const { colors } = useTheme();
  const c = color ?? colors.primary;
  return (
    <Pressable onPress={onPress} style={({ pressed }) => ({ opacity: pressed ? 0.75 : 1 })}>
      {selected ? (
        <LinearGradient
          colors={[c, colors.accent]}
          start={{ x: 0, y: 0 }} end={{ x: 1, y: 0 }}
          style={{ paddingHorizontal: 14, paddingVertical: 9, borderRadius: 20 }}
        >
          <Text style={{ color: "#fff", fontSize: 13, fontWeight: "700" }}>{label} ✓</Text>
        </LinearGradient>
      ) : (
        <View style={{ paddingHorizontal: 14, paddingVertical: 9, borderRadius: 20, borderWidth: 1.5, borderColor: colors.border, backgroundColor: colors.card }}>
          <Text style={{ color: colors.textSecondary, fontSize: 13, fontWeight: "600" }}>{label}</Text>
        </View>
      )}
    </Pressable>
  );
}

// ─── Toggle switch ────────────────────────────────────────────────────────────
function ToggleRow({
  label,
  subtitle,
  value,
  onToggle,
  emoji,
}: {
  label: string;
  subtitle?: string;
  value: boolean;
  onToggle: () => void;
  emoji: string;
}) {
  const { colors } = useTheme();
  const slideAnim = useRef(new Animated.Value(value ? 1 : 0)).current;

  useEffect(() => {
    Animated.spring(slideAnim, {
      toValue: value ? 1 : 0,
      useNativeDriver: true,
      stiffness: 280,
      damping: 22,
    }).start();
  }, [value]);

  const translateX = slideAnim.interpolate({ inputRange: [0, 1], outputRange: [2, 22] });

  return (
    <Pressable
      onPress={onToggle}
      style={{
        flexDirection: "row",
        alignItems: "center",
        justifyContent: "space-between",
        paddingVertical: 14,
        borderBottomWidth: 1,
        borderBottomColor: colors.border,
      }}
    >
      <View style={{ flexDirection: "row", alignItems: "center", gap: 12, flex: 1 }}>
        <View
          style={{
            width: 40,
            height: 40,
            borderRadius: 12,
            backgroundColor: value ? colors.primary + "18" : colors.card,
            alignItems: "center",
            justifyContent: "center",
            borderWidth: 1,
            borderColor: value ? colors.primary + "44" : colors.border,
          }}
        >
          <Text style={{ fontSize: 18 }}>{emoji}</Text>
        </View>
        <View style={{ flex: 1 }}>
          <Text style={{ fontSize: 15, fontWeight: "700", color: colors.text }}>{label}</Text>
          {subtitle && (
            <Text style={{ fontSize: 12, color: colors.textMuted, marginTop: 2 }}>{subtitle}</Text>
          )}
        </View>
      </View>

      {/* Track */}
      <Pressable
        onPress={onToggle}
        style={{
          width: 48,
          height: 28,
          borderRadius: 14,
          backgroundColor: value ? colors.primary : colors.border,
          justifyContent: "center",
          paddingHorizontal: 0,
        }}
      >
        <Animated.View
          style={{
            width: 22,
            height: 22,
            borderRadius: 11,
            backgroundColor: "#fff",
            transform: [{ translateX }],
            shadowColor: "#000",
            shadowOffset: { width: 0, height: 2 },
            shadowOpacity: 0.15,
            shadowRadius: 4,
            elevation: 2,
          }}
        />
      </Pressable>
    </Pressable>
  );
}

// ─── Section title ────────────────────────────────────────────────────────────
function SectionTitle({ title }: { title: string }) {
  const { colors } = useTheme();
  return (
    <Text style={{ fontSize: 12, fontWeight: "800", color: colors.textMuted, letterSpacing: 0.8, marginTop: 20, marginBottom: 12 }}>
      {title}
    </Text>
  );
}

// ─── Main FilterSheet ─────────────────────────────────────────────────────────
export function FilterSheet() {
  const insets         = useSafeAreaInsets();
  const { colors }     = useTheme();
  const filters        = useDiscoverStore((s) => s.filters);
  const setFilters     = useDiscoverStore((s) => s.setFilters);
  const resetFilters   = useDiscoverStore((s) => s.resetFilters);
  const showSheet      = useDiscoverStore((s) => s.showFilterSheet);
  const setShowSheet   = useDiscoverStore((s) => s.setShowFilterSheet);
  const activeCount    = useActiveFilterCount();

  const slideAnim = useRef(new Animated.Value(SHEET_H)).current;

  useEffect(() => {
    Animated.spring(slideAnim, {
      toValue: showSheet ? 0 : SHEET_H,
      useNativeDriver: true,
      stiffness: 300,
      damping: 30,
    }).start();
  }, [showSheet]);

  const toggleOrientation = useCallback(
    (o: Orientation) => {
      setFilters({
        orientations: filters.orientations.includes(o)
          ? filters.orientations.filter((x) => x !== o)
          : [...filters.orientations, o],
      });
    },
    [filters.orientations, setFilters]
  );

  const toggleIntent = useCallback(
    (i: Intent) => {
      setFilters({
        intents: filters.intents.includes(i)
          ? filters.intents.filter((x) => x !== i)
          : [...filters.intents, i],
      });
    },
    [filters.intents, setFilters]
  );

  return (
    <Modal
      visible={showSheet}
      transparent
      animationType="none"
      onRequestClose={() => setShowSheet(false)}
    >
      {/* Backdrop */}
      <Pressable
        style={{ flex: 1, backgroundColor: "rgba(0,0,0,0.5)" }}
        onPress={() => setShowSheet(false)}
      />

      {/* Sheet */}
      <Animated.View
        style={{
          position: "absolute",
          bottom: 0,
          left: 0,
          right: 0,
          height: SHEET_H,
          backgroundColor: colors.surface,
          borderTopLeftRadius: 28,
          borderTopRightRadius: 28,
          transform: [{ translateY: slideAnim }],
          shadowColor: "#000",
          shadowOffset: { width: 0, height: -6 },
          shadowOpacity: 0.12,
          shadowRadius: 20,
          elevation: 20,
        }}
      >
        {/* Handle */}
        <View style={{ alignItems: "center", paddingTop: 12, paddingBottom: 4 }}>
          <View
            style={{
              width: 40,
              height: 4,
              borderRadius: 2,
              backgroundColor: colors.border,
            }}
          />
        </View>

        {/* Header */}
        <View
          style={{
            flexDirection: "row",
            alignItems: "center",
            justifyContent: "space-between",
            paddingHorizontal: 20,
            paddingVertical: 14,
            borderBottomWidth: 1,
            borderBottomColor: colors.border,
          }}
        >
          <Text style={{ fontSize: 20, fontWeight: "800", color: colors.text }}>
            Filters
            {activeCount > 0 && (
              <Text style={{ color: colors.primary }}> ({activeCount})</Text>
            )}
          </Text>
          <View style={{ flexDirection: "row", gap: 10 }}>
            <Pressable
              onPress={resetFilters}
              style={({ pressed }) => ({
                paddingHorizontal: 14,
                paddingVertical: 7,
                borderRadius: 12,
                backgroundColor: colors.card,
                opacity: pressed ? 0.7 : 1,
              })}
            >
              <Text style={{ color: colors.primary, fontSize: 13, fontWeight: "700" }}>
                Reset
              </Text>
            </Pressable>
            <Pressable
              onPress={() => setShowSheet(false)}
              style={({ pressed }) => ({
                width: 32,
                height: 32,
                borderRadius: 16,
                backgroundColor: colors.card,
                alignItems: "center",
                justifyContent: "center",
                opacity: pressed ? 0.7 : 1,
              })}
            >
              <Text style={{ fontSize: 16, color: colors.text }}>✕</Text>
            </Pressable>
          </View>
        </View>

        <ScrollView
          contentContainerStyle={{
            paddingHorizontal: 20,
            paddingBottom: insets.bottom + 100,
          }}
          showsVerticalScrollIndicator={false}
        >
          {/* ── Age range ─────────────────────────────────────────── */}
          <SectionTitle title="AGE RANGE" />
          <View style={{ gap: 14 }}>
            <View>
              <Text style={{ fontSize: 13, color: colors.textMuted, marginBottom: 8, fontWeight: "600" }}>
                Min age —{" "}
                <Text style={{ color: colors.primary, fontWeight: "800" }}>
                  {filters.ageMin}
                </Text>
              </Text>
              <View style={{ flexDirection: "row", flexWrap: "wrap", gap: 8 }}>
                {AGE_MIN_OPTS.map((a) => (
                  <FilterChip
                    key={a}
                    label={String(a)}
                    selected={filters.ageMin === a}
                    onPress={() =>
                      setFilters({
                        ageMin: a,
                        ageMax: filters.ageMax < a ? a + 5 : filters.ageMax,
                      })
                    }
                  />
                ))}
              </View>
            </View>

            <View>
              <Text style={{ fontSize: 13, color: colors.textMuted, marginBottom: 8, fontWeight: "600" }}>
                Max age —{" "}
                <Text style={{ color: colors.primary, fontWeight: "800" }}>
                  {filters.ageMax}
                </Text>
              </Text>
              <View style={{ flexDirection: "row", flexWrap: "wrap", gap: 8 }}>
                {AGE_MAX_OPTS.map((a) => (
                  <FilterChip
                    key={a}
                    label={String(a)}
                    selected={filters.ageMax === a}
                    onPress={() =>
                      setFilters({
                        ageMax: a,
                        ageMin: filters.ageMin > a ? a - 5 : filters.ageMin,
                      })
                    }
                  />
                ))}
              </View>
            </View>
          </View>

          {/* ── Distance ─────────────────────────────────────────── */}
          <SectionTitle title="MAX DISTANCE" />
          <View style={{ flexDirection: "row", flexWrap: "wrap", gap: 8 }}>
            {DISTANCE_PRESETS.map((d) => (
              <FilterChip
                key={d}
                label={`${d} km`}
                selected={filters.maxDistanceKm === d}
                onPress={() => setFilters({ maxDistanceKm: d })}
                color={colors.violet}
              />
            ))}
          </View>

          {/* ── Orientation ───────────────────────────────────────── */}
          <SectionTitle title="ORIENTATION" />
          <View style={{ flexDirection: "row", flexWrap: "wrap", gap: 8 }}>
            {ORIENTATIONS.map((o) => (
              <FilterChip
                key={o}
                label={o}
                selected={filters.orientations.includes(o)}
                onPress={() => toggleOrientation(o)}
                color={colors.rose}
              />
            ))}
          </View>

          {/* ── Looking for ───────────────────────────────────────── */}
          <SectionTitle title="LOOKING FOR" />
          <View style={{ flexDirection: "row", flexWrap: "wrap", gap: 8 }}>
            {INTENTS.map((i) => (
              <FilterChip
                key={i}
                label={i}
                selected={filters.intents.includes(i)}
                onPress={() => toggleIntent(i)}
                color={colors.accent}
              />
            ))}
          </View>

          {/* ── Quick toggles ─────────────────────────────────────── */}
          <SectionTitle title="QUICK FILTERS" />
          <View
            style={{
              backgroundColor: colors.card,
              borderRadius: 18,
              paddingHorizontal: 16,
              borderWidth: 1,
              borderColor: colors.border,
            }}
          >
            <ToggleRow
              emoji="🟢"
              label="Online now"
              subtitle="Only show people currently active"
              value={filters.onlineOnly}
              onToggle={() => setFilters({ onlineOnly: !filters.onlineOnly })}
            />
            <ToggleRow
              emoji="⭐"
              label="Favourites only"
              subtitle="People you've saved"
              value={filters.favouritesOnly}
              onToggle={() => setFilters({ favouritesOnly: !filters.favouritesOnly })}
            />
          </View>
        </ScrollView>

        {/* Apply button */}
        <View
          style={{
            position: "absolute",
            bottom: insets.bottom + 16,
            left: 20,
            right: 20,
          }}
        >
          <Pressable
            onPress={() => setShowSheet(false)}
            style={({ pressed }) => ({
              opacity: pressed ? 0.88 : 1,
              transform: [{ scale: pressed ? 0.97 : 1 }],
            })}
          >
            <LinearGradient
              colors={[colors.primary, colors.accent]}
              start={{ x: 0, y: 0 }}
              end={{ x: 1, y: 0 }}
              style={{
                borderRadius: 18,
                paddingVertical: 18,
                alignItems: "center",
                shadowColor: colors.primary,
                shadowOffset: { width: 0, height: 6 },
                shadowOpacity: 0.35,
                shadowRadius: 14,
                elevation: 8,
              }}
            >
              <Text
                style={{
                  color: "#fff",
                  fontSize: 16,
                  fontWeight: "800",
                  letterSpacing: 0.3,
                }}
              >
                {activeCount > 0
                  ? `Apply ${activeCount} Filter${activeCount > 1 ? "s" : ""}`
                  : "Apply Filters"}
              </Text>
            </LinearGradient>
          </Pressable>
        </View>
      </Animated.View>
    </Modal>
  );
}
