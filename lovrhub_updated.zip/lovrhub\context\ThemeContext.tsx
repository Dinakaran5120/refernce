import React, { createContext, useContext, useState, useCallback } from "react";

export type ThemeMode = "light" | "dark";

// ── Light palette ─────────────────────────────────────────────────────────────
export const LightColors = {
  primary:        "#E63946",
  primaryLight:   "#FF5A66",
  primaryDark:    "#C0202E",
  secondary:      "#F7A1C4",
  secondaryLight: "#FFC4DC",
  secondaryDark:  "#E07AA0",
  accent:         "#FF8C6B",
  accentLight:    "#FFAA8A",
  accentDark:     "#E06A48",

  rose:   "#FF6B9D",
  violet: "#B06BFF",
  sky:    "#6BD4FF",
  gold:   "#FFD166",
  mint:   "#6BFFB8",

  pride: ["#FF6B6B","#FF8C6B","#FFD166","#6BFF9E","#6BD4FF","#B06BFF","#FF6B9D"] as string[],

  background: "#FFF8F5",
  surface:    "#FFFFFF",
  card:       "#FFF0EC",
  border:     "#F0D9D4",
  muted:      "#9B8A87",

  text:          "#2B2B2B",
  textSecondary: "#6B5E5B",
  textMuted:     "#9B8A87",
  textInverse:   "#FFFFFF",

  tabBar:        "#FFFFFF",
  tabBarBorder:  "#F0D9D4",
  headerBg:      "#FFFFFF",
  inputBg:       "#FFF0EC",
  statusBar:     "dark" as "dark" | "light",
};

// ── Dark palette ──────────────────────────────────────────────────────────────
export const DarkColors = {
  primary:        "#E63946",
  primaryLight:   "#FF5A66",
  primaryDark:    "#C0202E",
  secondary:      "#F7A1C4",
  secondaryLight: "#FFC4DC",
  secondaryDark:  "#E07AA0",
  accent:         "#FF8C6B",
  accentLight:    "#FFAA8A",
  accentDark:     "#E06A48",

  rose:   "#FF6B9D",
  violet: "#B06BFF",
  sky:    "#6BD4FF",
  gold:   "#FFD166",
  mint:   "#6BFFB8",

  pride: ["#FF6B6B","#FF8C6B","#FFD166","#6BFF9E","#6BD4FF","#B06BFF","#FF6B9D"] as string[],

  background: "#111111",
  surface:    "#1C1C1C",
  card:       "#242424",
  border:     "#333333",
  muted:      "#666666",

  text:          "#F2F2F2",
  textSecondary: "#AAAAAA",
  textMuted:     "#666666",
  textInverse:   "#111111",

  tabBar:       "#1C1C1C",
  tabBarBorder: "#2A2A2A",
  headerBg:     "#1C1C1C",
  inputBg:      "#242424",
  statusBar:    "light" as "dark" | "light",
};

export type ThemeColors = typeof LightColors;

interface ThemeContextType {
  theme:       ThemeMode;
  colors:      ThemeColors;
  isDark:      boolean;
  toggleTheme: () => void;
}

const ThemeContext = createContext<ThemeContextType>({
  theme:       "light",
  colors:      LightColors,
  isDark:      false,
  toggleTheme: () => {},
});

export function ThemeProvider({ children }: { children: React.ReactNode }) {
  const [theme, setTheme] = useState<ThemeMode>("light");

  const toggleTheme = useCallback(() => {
    setTheme((t) => (t === "light" ? "dark" : "light"));
  }, []);

  const colors = theme === "dark" ? DarkColors : LightColors;

  return (
    <ThemeContext.Provider value={{ theme, colors, isDark: theme === "dark", toggleTheme }}>
      {children}
    </ThemeContext.Provider>
  );
}

export const useTheme = () => useContext(ThemeContext);
