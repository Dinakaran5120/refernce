import { Tabs } from "expo-router";
import { View, Text, Pressable } from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import type { BottomTabBarProps } from "@react-navigation/bottom-tabs";
import { LinearGradient } from "expo-linear-gradient";
import { Ionicons } from "@expo/vector-icons";
import { useTheme } from "@/context/ThemeContext";
import TopNavBar from "@components/TopNavBar";
import { useConnectionsStore } from "@/store/connectionsStore";
import { useCommunityStore } from "@/store/communityStore";

type IoniconsName = React.ComponentProps<typeof Ionicons>["name"];

const TAB_ICONS: Record<string, { active: IoniconsName; inactive: IoniconsName }> = {
  index:        { active: "flame",            inactive: "flame-outline"        },
  explore:      { active: "compass",          inactive: "compass-outline"      },
  post:         { active: "add-circle",       inactive: "add-circle-outline"   },
  connections:  { active: "chatbubbles",      inactive: "chatbubbles-outline"  },
  communities:  { active: "people",           inactive: "people-outline"       },
  profile:      { active: "person-circle",    inactive: "person-circle-outline"},
};

const TAB_LABELS: Record<string, string> = {
  index:        "Discover",
  explore:      "Explore",
  post:         "Post",
  connections:  "Chats",
  communities:  "Groups",
  profile:      "Profile",
};

function CustomTabBar({ state, navigation }: BottomTabBarProps) {
  const insets = useSafeAreaInsets();
  const { colors } = useTheme();

  const activeConvId      = useConnectionsStore((s) => s.activeConversationId);
  const activeCall        = useConnectionsStore((s) => s.call);
  const activeCommunityId = useCommunityStore((s) => s.activeCommunityId);

  if (activeConvId || activeCall || activeCommunityId) return null;

  return (
    <View
      style={{
        backgroundColor: colors.tabBar,
        paddingBottom: insets.bottom + 2,
        paddingTop: 8,
        borderTopWidth: 1,
        borderTopColor: colors.tabBarBorder,
        shadowColor: "#000",
        shadowOffset: { width: 0, height: -4 },
        shadowOpacity: 0.12,
        shadowRadius: 16,
        elevation: 16,
      }}
    >
      <View style={{ flexDirection: "row", paddingHorizontal: 4 }}>
        {state.routes.map((route, index) => {
          const isActive = state.index === index;
          const isPost   = route.name === "post";

          const onPress = () => {
            const event = navigation.emit({
              type: "tabPress",
              target: route.key,
              canPreventDefault: true,
            });
            if (!isActive && !event.defaultPrevented) {
              navigation.navigate(route.name);
            }
          };

          if (isPost) {
            return (
              <View key={route.key} style={{ flex: 1, alignItems: "center", justifyContent: "center" }}>
                <Pressable
                  onPress={onPress}
                  style={({ pressed }) => ({
                    opacity: pressed ? 0.85 : 1,
                    transform: [{ scale: pressed ? 0.92 : 1 }],
                  })}
                >
                  <LinearGradient
                    colors={[colors.primary, colors.accent]}
                    start={{ x: 0, y: 0 }}
                    end={{ x: 1, y: 1 }}
                    style={{
                      width: 50,
                      height: 50,
                      borderRadius: 25,
                      alignItems: "center",
                      justifyContent: "center",
                      marginTop: -18,
                      shadowColor: colors.primary,
                      shadowOffset: { width: 0, height: 6 },
                      shadowOpacity: 0.5,
                      shadowRadius: 12,
                      elevation: 8,
                    }}
                  >
                    <Ionicons name="add" size={28} color="#fff" />
                  </LinearGradient>
                </Pressable>
                <Text
                  style={{
                    fontSize: 10,
                    fontWeight: "600",
                    marginTop: 4,
                    color: colors.textMuted,
                    letterSpacing: 0.2,
                  }}
                >
                  {TAB_LABELS[route.name]}
                </Text>
              </View>
            );
          }

          const iconName = isActive
            ? TAB_ICONS[route.name]?.active
            : TAB_ICONS[route.name]?.inactive;

          const iconColor = isActive ? colors.primary : colors.textMuted;

          return (
            <Pressable
              key={route.key}
              onPress={onPress}
              style={({ pressed }) => ({
                flex: 1,
                alignItems: "center",
                paddingVertical: 4,
                opacity: pressed ? 0.6 : 1,
              })}
            >
              {/* Active indicator dot */}
              {isActive && (
                <View
                  style={{
                    position: "absolute",
                    top: 0,
                    width: 4,
                    height: 4,
                    borderRadius: 2,
                    backgroundColor: colors.primary,
                  }}
                />
              )}

              <View
                style={{
                  width: 44,
                  height: 34,
                  alignItems: "center",
                  justifyContent: "center",
                  borderRadius: 12,
                  backgroundColor: isActive ? colors.primary + "18" : "transparent",
                }}
              >
                <Ionicons
                  name={iconName}
                  size={route.name === "index" ? 24 : 22}
                  color={iconColor}
                />
              </View>

              <Text
                style={{
                  fontSize: 10,
                  fontWeight: isActive ? "700" : "500",
                  marginTop: 2,
                  color: iconColor,
                  letterSpacing: 0.2,
                }}
              >
                {TAB_LABELS[route.name]}
              </Text>
            </Pressable>
          );
        })}
      </View>
    </View>
  );
}

function DynamicHeader() {
  const activeConvId      = useConnectionsStore((s) => s.activeConversationId);
  const activeCall        = useConnectionsStore((s) => s.call);
  const activeCommunityId = useCommunityStore((s) => s.activeCommunityId);
  if (activeConvId || activeCall || activeCommunityId) return null;
  return <TopNavBar />;
}

export default function TabLayout() {
  return (
    <Tabs
      tabBar={(props) => <CustomTabBar {...props} />}
      screenOptions={{ header: () => <DynamicHeader /> }}
    >
      <Tabs.Screen name="index"       options={{ title: "Discover"    }} />
      <Tabs.Screen name="explore"     options={{ title: "Explore"     }} />
      <Tabs.Screen name="post"        options={{ title: "Post"        }} />
      <Tabs.Screen name="connections" options={{ title: "Connections" }} />
      <Tabs.Screen name="communities" options={{ title: "Communities" }} />
      <Tabs.Screen name="profile"     options={{ title: "Profile", headerShown: false }} />
    </Tabs>
  );
}
