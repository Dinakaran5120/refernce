import { useMemo } from "react";
import { useConnectionsStore } from "@/store/connectionsStore";
import type { Conversation, ChatMessage } from "@/types/connections";

/** Sort conversations: pinned first, then by latest message */
export function useSortedConversations(search: string): Conversation[] {
  const conversations = useConnectionsStore((s) => s.conversations);
  return useMemo(() => {
    const q = search.toLowerCase().trim();
    return [...conversations]
      .filter((c) => {
        if (!q) return true;
        const name = c.type === "group"
          ? c.groupName ?? ""
          : c.participants[0]?.name ?? "";
        return name.toLowerCase().includes(q) || c.lastMessage.toLowerCase().includes(q);
      })
      .sort((a, b) => {
        if (a.isPinned !== b.isPinned) return a.isPinned ? -1 : 1;
        return new Date(b.lastMessageTime).getTime() - new Date(a.lastMessageTime).getTime();
      });
  }, [conversations, search]);
}

/** Total unread message count — for tab badge */
export function useTotalUnreadMessages(): number {
  const conversations = useConnectionsStore((s) => s.conversations);
  return useMemo(
    () => conversations.reduce((sum, c) => sum + c.unreadCount, 0),
    [conversations]
  );
}

/** Messages for active conversation, filtering deleted */
export function useConversationMessages(convId: string): ChatMessage[] {
  const messages = useConnectionsStore((s) => s.messages);
  return useMemo(
    () => (messages[convId] ?? []).filter((m) => !m.deletedForMe),
    [messages, convId]
  );
}

/** Format call duration mm:ss */
export function formatDuration(seconds: number): string {
  const m = Math.floor(seconds / 60).toString().padStart(2, "0");
  const s = (seconds % 60).toString().padStart(2, "0");
  return `${m}:${s}`;
}

/** Remaining call time string */
export function formatRemaining(seconds: number): string {
  const rem = 5 * 60 - seconds;
  if (rem <= 0) return "0:00";
  const m = Math.floor(rem / 60).toString().padStart(2, "0");
  const s = (rem % 60).toString().padStart(2, "0");
  return `${m}:${s}`;
}

/** Time-ago for message timestamps */
export function msgTimeAgo(iso: string): string {
  const diff  = Date.now() - new Date(iso).getTime();
  const mins  = Math.floor(diff / 60000);
  const hours = Math.floor(diff / 3600000);
  const days  = Math.floor(diff / 86400000);
  if (mins < 1)   return "just now";
  if (mins < 60)  return `${mins}m`;
  if (hours < 24) return `${hours}h`;
  if (days < 7)   return `${days}d`;
  return new Date(iso).toLocaleDateString("en-IN", { day: "numeric", month: "short" });
}

/** Message status icon */
export function msgStatusIcon(status: ChatMessage["status"]): string {
  switch (status) {
    case "sending":   return "○";
    case "sent":      return "✓";
    case "delivered": return "✓✓";
    case "read":      return "✓✓";
    default:          return "";
  }
}

/** Format last-seen string */
export function lastSeenText(iso: string): string {
  const diff  = Date.now() - new Date(iso).getTime();
  const mins  = Math.floor(diff / 60000);
  const hours = Math.floor(diff / 3600000);
  if (mins < 2)   return "Online";
  if (mins < 60)  return `Last seen ${mins}m ago`;
  if (hours < 24) return `Last seen ${hours}h ago`;
  return `Last seen ${Math.floor(diff / 86400000)}d ago`;
}
