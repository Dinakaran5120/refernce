# Lovrhub — Full Stack Dating App Frontend

## Stack
| Layer | Library | Version |
|---|---|---|
| Framework | Expo SDK | ~54.0.0 |
| React Native | react-native | 0.81.4 |
| React | react | 19.1.0 |
| Navigation | expo-router | ~4.0.0 |
| Styling | NativeWind v4 + Tailwind CSS | ^4.1.23 |
| Animation | react-native-reanimated | ~3.17.0 |
| State | Zustand | ^4.5.2 |
| Architecture | New Architecture | ✅ |

---

## Quick Start

```bash
# 1. Install dependencies
npm install

# 2. Start Expo dev server (clear cache)
npx expo start --clear

# 3. Scan QR with Expo Go v54 on your phone
#    OR press 'i' for iOS simulator / 'a' for Android emulator
```

**Dev OTP code:** `1234`

---

## Project Structure

```
lovrhub/
├── app/
│   ├── _layout.tsx              # Root: Splash → AuthGate → Stack
│   ├── splash.tsx               # Animated splash screen (1.8s)
│   ├── auth/
│   │   ├── _layout.tsx          # Auth stack (slide_from_right)
│   │   ├── welcome.tsx          # Landing — Phone / Google / Email
│   │   ├── phone.tsx            # Phone + country code picker
│   │   ├── otp.tsx              # 4-digit OTP (dev: 1234)
│   │   ├── email.tsx            # Email + Google OAuth UI
│   │   └── setup.tsx            # 9-step profile wizard
│   └── (tabs)/
│       ├── _layout.tsx          # Tab bar + DynamicHeader
│       ├── index.tsx            # Discover
│       ├── explore.tsx          # Explore feed + FAB
│       ├── post.tsx             # Redirects to Explore CreatePost
│       ├── connections.tsx      # Chats list
│       ├── communities.tsx      # Communities
│       └── profile/
│           ├── _layout.tsx      # Profile nested stack
│           ├── index.tsx        # Profile main screen
│           ├── edit.tsx         # Edit profile
│           ├── settings.tsx     # Full settings (account/privacy/notifs)
│           └── notifications.tsx # Notification preferences
│
├── components/
│   ├── TopNavBar.tsx            # Shared top bar (functional back btn)
│   ├── auth/AuthUI.tsx          # Shared auth primitives
│   ├── discover/
│   │   ├── DiscoverCard.tsx     # Profile card + actions + ProfileModal
│   │   ├── FilterSheet.tsx      # Age/distance/orientation filter
│   │   ├── SpotlightBanner.tsx  # Stats banner
│   │   └── EmptyDiscover.tsx    # Empty state
│   ├── explore/
│   │   ├── PostCards.tsx        # text/image/video/thought/mood cards
│   │   ├── PostHeader.tsx       # Author row
│   │   ├── VibeBar.tsx          # Emoji reactions + comment + share
│   │   ├── CommentsSheet.tsx    # Bottom sheet comments
│   │   ├── ReelsViewer.tsx      # Fullscreen vertical reel player
│   │   └── ShareMoodCard.tsx    # Inline prompt + CreatePostModal
│   ├── communities/
│   │   ├── CommunityCard.tsx    # Card (full + compact)
│   │   ├── CommunityDetailScreen.tsx  # Feed/Members/About/Requests
│   │   ├── CommunityPostCard.tsx      # text/image/poll/announcement
│   │   ├── CreateCommunityModal.tsx   # 3-step creation wizard
│   │   └── JoinRequestModal.tsx       # Private community request
│   ├── connections/
│   │   ├── ChatScreen.tsx       # Full chat with reactions, audio
│   │   ├── CallScreen.tsx       # Audio/video + 5-min timer
│   │   └── CreateGroupModal.tsx # Group chat creation
│   └── notifications/
│       ├── NotificationCenter.tsx  # Bell + full modal + prefs
│       └── NotificationRow.tsx     # Swipe-to-delete row
│
├── store/
│   ├── authStore.ts             # Auth + profile state
│   ├── discoverStore.ts         # Nearby users + filters + actions
│   ├── exploreStore.ts          # Feed posts + vibes + comments
│   ├── communityStore.ts        # Communities + join + posts + requests
│   ├── connectionsStore.ts      # Chats + calls + 5-min timer
│   └── notificationStore.ts    # Notifications + preferences
│
├── hooks/
│   ├── useDiscoverFilters.ts    # useMemo filter pipeline
│   ├── useExploreFeed.ts        # Tab-based feed filter
│   ├── useCommunity.ts          # Community helpers
│   ├── useConnections.ts        # Chat/call helpers
│   └── useNotifications.ts     # Notif config + filters
│
├── types/
│   ├── discover.ts
│   ├── explore.ts
│   ├── community.ts
│   ├── connections.ts
│   └── notification.ts
│
├── data/                        # Mock data (replace with API)
│   ├── mockUsers.ts
│   ├── mockExplorePosts.ts
│   ├── mockCommunities.ts
│   ├── mockConversations.ts
│   └── mockNotifications.ts
│
├── constants/theme.ts           # Colors, spacing, typography
├── package.json                 # SDK 54 deps
├── app.json                     # newArchEnabled: true
├── babel.config.js
├── metro.config.js
├── tailwind.config.js
└── global.css
```

---

## Navigation Flow

```
App Launch
  └── Splash (1.8s animated)
        └── AuthGate
              ├── Not authenticated → /auth/welcome
              │     ├── Phone → OTP (1234) → Email → Setup (9 steps) → /(tabs)
              │     ├── Google → Email → Setup → /(tabs)
              │     └── Email → Setup → /(tabs)
              └── Authenticated → /(tabs)
                    ├── Discover (index)
                    │     ├── FilterSheet (modal)
                    │     ├── ProfileModal (per card)
                    │     └── JoinRequestModal (private profile)
                    ├── Explore
                    │     ├── CreatePostModal (FAB + Post tab redirect)
                    │     ├── CommentsSheet (per post)
                    │     └── ReelsViewer (fullscreen)
                    ├── Post → redirects to Explore + opens CreatePostModal
                    ├── Connections
                    │     ├── ChatScreen (replaces tab content)
                    │     │     └── CallScreen (modal over chat)
                    │     └── CreateGroupModal
                    ├── Communities
                    │     ├── CommunityDetailScreen (replaces tab content)
                    │     │     ├── Feed tab + CreatePostSheet
                    │     │     ├── Members tab
                    │     │     ├── About tab
                    │     │     └── Requests tab (owner/admin)
                    │     ├── JoinRequestModal
                    │     └── CreateCommunityModal
                    └── Profile
                          ├── /profile/edit
                          ├── /profile/settings
                          └── /profile/notifications
```

---

## Features Implemented

| Feature | Status |
|---|---|
| Splash screen | ✅ |
| Auth flow (Phone/OTP/Email/Google UI/Setup) | ✅ |
| Discover with location-based cards | ✅ |
| Filters (age, distance, orientation, online, favourites) | ✅ |
| Like / Super Like / Favourite / Pass | ✅ |
| Private profile request | ✅ |
| Explore feed (text/image/video/thought/mood) | ✅ |
| Vibe reactions (❤️😂🔥😮💔✨) | ✅ |
| Comments sheet | ✅ |
| Reels viewer (fullscreen vertical) | ✅ |
| Create post (mood/thought/text) with anonymous toggle | ✅ |
| Communities (public/private) | ✅ |
| Join request + owner approval/rejection | ✅ |
| Community posts (text/image/poll/announcement) | ✅ |
| Poll voting | ✅ |
| Real-time chat (simulated) | ✅ |
| Message reactions (long-press) | ✅ |
| Voice messages | ✅ |
| Group chat creation | ✅ |
| Audio call + Video call | ✅ |
| 5-minute call timer with auto-end | ✅ |
| Notifications center (all types) | ✅ |
| Notification preferences | ✅ |
| Swipe-to-delete notifications | ✅ |
| Profile with grid, highlights, stats | ✅ |
| Edit profile | ✅ |
| Settings (account/privacy/notifs/logout) | ✅ |
| Tab bar hides during chat/call/community detail | ✅ |
| TopNavBar back button functional | ✅ |

---

## SDK 54 Notes

- `newArchEnabled: true` in app.json
- `react-native-reanimated` stays on v3 — NativeWind not yet compatible with v4
- `reanimated/plugin` must be last in babel.config.js
- `unstable_enablePackageExports: true` in metro.config.js for metro 0.83
