import {
  View, Text, ScrollView, Pressable, Switch,
} from "react-native";
import { useRouter } from "expo-router";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import { LinearGradient } from "expo-linear-gradient";
import { Ionicons } from "@expo/vector-icons";
import { useTheme } from "@/context/ThemeContext";
import { useAuthStore } from "@/store/authStore";
import { useNotificationStore } from "@/store/notificationStore";
import { useState } from "react";

type IoniconsName = React.ComponentProps<typeof Ionicons>["name"];

// ── Row ────────────────────────────────────────────────────────────────────────
function SettingsRow({
  icon, label, subtitle, value, onToggle, onPress, danger = false, chevron = false, badge,
}: {
  icon: IoniconsName;
  label: string;
  subtitle?: string;
  value?: boolean;
  onToggle?: () => void;
  onPress?: () => void;
  danger?: boolean;
  chevron?: boolean;
  badge?: string;
}) {
  const { colors } = useTheme();

  return (
    <Pressable
      onPress={onPress}
      disabled={!onPress && !onToggle}
      style={({ pressed }) => ({
        flexDirection: "row",
        alignItems: "center",
        paddingHorizontal: 16,
        paddingVertical: 14,
        backgroundColor: pressed && onPress ? colors.card : "transparent",
        gap: 13,
      })}
    >
      {/* Icon box */}
      <View
        style={{
          width: 38,
          height: 38,
          borderRadius: 11,
          backgroundColor: danger ? colors.primary + "18" : colors.card,
          alignItems: "center",
          justifyContent: "center",
          borderWidth: 1,
          borderColor: danger ? colors.primary + "33" : colors.border,
        }}
      >
        <Ionicons
          name={icon}
          size={18}
          color={danger ? colors.primary : colors.textSecondary}
        />
      </View>

      {/* Label */}
      <View style={{ flex: 1, gap: 2 }}>
        <Text style={{ fontSize: 14, fontWeight: "600", color: danger ? colors.primary : colors.text }}>
          {label}
        </Text>
        {subtitle && (
          <Text style={{ fontSize: 12, color: colors.textMuted }}>{subtitle}</Text>
        )}
      </View>

      {/* Badge */}
      {badge && (
        <View
          style={{
            backgroundColor: colors.primary,
            paddingHorizontal: 8,
            paddingVertical: 3,
            borderRadius: 10,
          }}
        >
          <Text style={{ color: "#fff", fontSize: 11, fontWeight: "700" }}>{badge}</Text>
        </View>
      )}

      {/* Toggle or chevron */}
      {onToggle !== undefined && value !== undefined ? (
        <Switch
          value={value}
          onValueChange={onToggle}
          trackColor={{ false: colors.border, true: colors.primary }}
          thumbColor="#fff"
        />
      ) : chevron ? (
        <Ionicons name="chevron-forward" size={16} color={colors.textMuted} />
      ) : null}
    </Pressable>
  );
}

// ── Section ────────────────────────────────────────────────────────────────────
function Section({ title, children }: { title: string; children: React.ReactNode }) {
  const { colors } = useTheme();
  return (
    <View style={{ marginBottom: 24 }}>
      <Text
        style={{
          fontSize: 11,
          fontWeight: "800",
          color: colors.textMuted,
          letterSpacing: 0.8,
          paddingHorizontal: 16,
          paddingBottom: 8,
        }}
      >
        {title}
      </Text>
      <View
        style={{
          backgroundColor: colors.surface,
          borderTopWidth: 1,
          borderBottomWidth: 1,
          borderColor: colors.border,
        }}
      >
        {children}
      </View>
    </View>
  );
}

function Divider() {
  const { colors } = useTheme();
  return <View style={{ height: 1, backgroundColor: colors.border, marginLeft: 67 }} />;
}

// ── Main Screen ────────────────────────────────────────────────────────────────
export default function SettingsScreen() {
  const router   = useRouter();
  const insets   = useSafeAreaInsets();
  const { colors, isDark, toggleTheme } = useTheme();
  const reset    = useAuthStore((s) => s.reset);
  const prefs    = useNotificationStore((s) => s.preferences);
  const updatePref = useNotificationStore((s) => s.updatePreference);

  const [locationEnabled, setLocation] = useState(true);
  const [showDistance, setShowDist]    = useState(true);
  const [showOnline, setShowOnline]    = useState(true);

  const handleLogout = () => {
    reset();
    router.replace("/auth/welcome");
  };

  return (
    <View style={{ flex: 1, backgroundColor: colors.background }}>
      {/* ── Header ── */}
      <View
        style={{
          paddingTop: insets.top,
          backgroundColor: colors.surface,
          borderBottomWidth: 1,
          borderBottomColor: colors.border,
        }}
      >
        <View
          style={{
            height: 56,
            flexDirection: "row",
            alignItems: "center",
            paddingHorizontal: 16,
            gap: 12,
          }}
        >
          <Pressable
            onPress={() => router.back()}
            hitSlop={10}
            style={({ pressed }) => ({
              opacity: pressed ? 0.6 : 1,
              width: 34,
              height: 34,
              borderRadius: 10,
              backgroundColor: colors.card,
              alignItems: "center",
              justifyContent: "center",
              borderWidth: 1,
              borderColor: colors.border,
            })}
          >
            <Ionicons name="chevron-back" size={20} color={colors.text} />
          </Pressable>
          <Text style={{ fontSize: 17, fontWeight: "800", color: colors.text }}>Settings</Text>
        </View>
      </View>

      <ScrollView
        showsVerticalScrollIndicator={false}
        contentContainerStyle={{ paddingTop: 20, paddingBottom: 48 }}
      >

        {/* ── Theme toggle card ── */}
        <View style={{ paddingHorizontal: 16, marginBottom: 24 }}>
          <LinearGradient
            colors={isDark ? ["#1C1C1C","#2A2A2A"] : [colors.primary + "12", colors.accent + "08"]}
            start={{ x: 0, y: 0 }}
            end={{ x: 1, y: 1 }}
            style={{
              borderRadius: 20,
              padding: 18,
              borderWidth: 1,
              borderColor: isDark ? "#333" : colors.border,
            }}
          >
            <View style={{ flexDirection: "row", alignItems: "center", gap: 14 }}>
              <View
                style={{
                  width: 48,
                  height: 48,
                  borderRadius: 16,
                  backgroundColor: isDark ? "#2A2A2A" : colors.card,
                  alignItems: "center",
                  justifyContent: "center",
                  borderWidth: 1,
                  borderColor: colors.border,
                }}
              >
                <Ionicons
                  name={isDark ? "moon" : "sunny"}
                  size={24}
                  color={isDark ? "#6BD4FF" : colors.gold}
                />
              </View>
              <View style={{ flex: 1 }}>
                <Text style={{ fontSize: 15, fontWeight: "800", color: colors.text }}>
                  {isDark ? "Dark Mode" : "Light Mode"}
                </Text>
                <Text style={{ fontSize: 12, color: colors.textMuted, marginTop: 2 }}>
                  {isDark ? "Easy on the eyes at night" : "Bright and crisp during day"}
                </Text>
              </View>
              <Switch
                value={isDark}
                onValueChange={toggleTheme}
                trackColor={{ false: colors.border, true: colors.primary }}
                thumbColor="#fff"
              />
            </View>
          </LinearGradient>
        </View>

        {/* ── Account ── */}
        <Section title="ACCOUNT">
          <SettingsRow icon="pencil-outline"     label="Edit Profile"       subtitle="Name, photo, bio, interests" onPress={() => router.push("/(tabs)/profile/edit")} chevron />
          <Divider />
          <SettingsRow icon="phone-portrait-outline" label="Phone Number"   subtitle={useAuthStore.getState().profile.phone || "Not set"} onPress={() => {}} chevron />
          <Divider />
          <SettingsRow icon="mail-outline"       label="Email Address"      subtitle={useAuthStore.getState().profile.email || "Not set"} onPress={() => {}} chevron />
          <Divider />
          <SettingsRow icon="lock-closed-outline" label="Change Password"   onPress={() => {}} chevron />
        </Section>

        {/* ── Privacy & Location ── */}
        <Section title="PRIVACY & LOCATION">
          <SettingsRow icon="location-outline"   label="Location Services"  subtitle="Required for discovery" value={locationEnabled} onToggle={() => setLocation((v) => !v)} />
          <Divider />
          <SettingsRow icon="resize-outline"     label="Show Distance"      subtitle="Show how far you are from others" value={showDistance} onToggle={() => setShowDist((v) => !v)} />
          <Divider />
          <SettingsRow icon="radio-button-on-outline" label="Show Online Status" subtitle="Let others see when you're active" value={showOnline} onToggle={() => setShowOnline((v) => !v)} />
          <Divider />
          <SettingsRow icon="eye-off-outline"    label="Private Profile"    subtitle="Require request to view full profile" onPress={() => {}} chevron />
          <Divider />
          <SettingsRow icon="ban-outline"        label="Blocked Users"      onPress={() => {}} chevron />
        </Section>

        {/* ── Notifications ── */}
        <Section title="NOTIFICATIONS">
          <SettingsRow icon="notifications-outline" label="Push Notifications" value={prefs.pushEnabled} onToggle={() => updatePref("pushEnabled", !prefs.pushEnabled)} />
          <Divider />
          <SettingsRow icon="chatbubble-outline" label="Messages"           value={prefs.messages}    onToggle={() => updatePref("messages", !prefs.messages)} />
          <Divider />
          <SettingsRow icon="heart-outline"      label="Likes & Matches"    value={prefs.likes}       onToggle={() => updatePref("likes", !prefs.likes)} />
          <Divider />
          <SettingsRow icon="people-outline"     label="Community Posts"    value={prefs.communityPosts} onToggle={() => updatePref("communityPosts", !prefs.communityPosts)} />
          <Divider />
          <SettingsRow icon="settings-outline"   label="All Notification Settings" onPress={() => router.push("/(tabs)/profile/notifications")} chevron />
        </Section>

        {/* ── Discovery Preferences ── */}
        <Section title="DISCOVERY PREFERENCES">
          <SettingsRow icon="navigate-circle-outline" label="Intent" subtitle="Dating · Friends · LGBTQ+" onPress={() => {}} chevron />
          <Divider />
          <SettingsRow icon="options-outline"    label="Age Range & Distance" onPress={() => {}} chevron />
          <Divider />
          <SettingsRow icon="rainbow-outline"    label="Orientation"          onPress={() => {}} chevron />
        </Section>

        {/* ── Support ── */}
        <Section title="SUPPORT">
          <SettingsRow
            icon="help-circle-outline"
            label="Help Centre"
            subtitle="FAQs, guides & contact us"
            onPress={() => router.push("/(tabs)/profile/help")}
            chevron
          />
          <Divider />
          <SettingsRow
            icon="shield-checkmark-outline"
            label="Safety Centre"
            subtitle="Reporting, blocking & safety tips"
            onPress={() => router.push("/(tabs)/profile/help")}
            chevron
          />
          <Divider />
          <SettingsRow
            icon="document-text-outline"
            label="Privacy Policy"
            subtitle="How we handle your data"
            onPress={() => router.push("/(tabs)/profile/privacy-policy")}
            chevron
          />
          <Divider />
          <SettingsRow
            icon="reader-outline"
            label="Terms of Service"
            subtitle="Rules and community guidelines"
            onPress={() => router.push("/(tabs)/profile/privacy-policy")}
            chevron
          />
          <Divider />
          <SettingsRow
            icon="chatbox-ellipses-outline"
            label="Send Feedback"
            subtitle="Help us improve Lovrhub"
            onPress={() => {}}
            chevron
          />
        </Section>

        {/* ── Account Actions ── */}
        <Section title="ACCOUNT ACTIONS">
          <SettingsRow
            icon="archive-outline"
            label="Pause Account"
            subtitle="Hide your profile temporarily"
            onPress={() => {}}
            chevron
          />
          <Divider />
          <SettingsRow
            icon="trash-outline"
            label="Delete Account"
            subtitle="Permanently remove your account"
            danger
            onPress={() => {}}
            chevron
          />
          <Divider />
          <SettingsRow
            icon="log-out-outline"
            label="Log Out"
            danger
            onPress={handleLogout}
            chevron
          />
        </Section>

        {/* Version */}
        <View style={{ alignItems: "center", paddingBottom: 16, gap: 4 }}>
          <LinearGradient
            colors={[colors.primary, colors.accent]}
            start={{ x: 0, y: 0 }}
            end={{ x: 1, y: 0 }}
            style={{ borderRadius: 12, paddingHorizontal: 16, paddingVertical: 6 }}
          >
            <Text style={{ color: "#fff", fontSize: 12, fontWeight: "800" }}>lovrhub v1.0.0</Text>
          </LinearGradient>
          <Text style={{ fontSize: 12, color: colors.textMuted }}>Made with ❤️ in Mumbai</Text>
        </View>
      </ScrollView>
    </View>
  );
}
