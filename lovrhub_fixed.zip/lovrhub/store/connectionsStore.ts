import { create } from "zustand";
import type {
  Conversation, ChatMessage, ActiveCall,
  CallType, CallStatus, MessageType, ReactionEmoji,
} from "@/types/connections";
import { MOCK_CONVERSATIONS, MOCK_MESSAGES, PARTICIPANTS, ME_ID } from "@/data/mockConversations";
import { Colors } from "@constants/theme";

const CALL_TIME_LIMIT = 5 * 60; // 5 minutes in seconds

interface ConnectionsState {
  conversations: Conversation[];
  messages: Record<string, ChatMessage[]>;
  activeConversationId: string | null;
  call: ActiveCall | null;
  callTimer: number;                      // interval handle
  typingTimers: Record<string, any>;      // timeout handles per conv

  // Navigation
  setActiveConversation: (id: string | null) => void;

  // Messaging
  sendMessage: (convId: string, text: string, type?: MessageType) => void;
  deleteMessage: (convId: string, msgId: string) => void;
  reactToMessage: (convId: string, msgId: string, emoji: ReactionEmoji) => void;
  markConversationRead: (convId: string) => void;
  togglePin: (convId: string) => void;
  toggleMute: (convId: string) => void;

  // Typing indicator (simulated bot reply)
  simulateReply: (convId: string) => void;

  // Group chat
  createGroupChat: (name: string, emoji: string, participantIds: string[]) => void;

  // Calls
  initiateCall: (convId: string, type: CallType) => void;
  acceptCall: () => void;
  declineCall: () => void;
  endCall: () => void;
  toggleMic: () => void;
  toggleCamera: () => void;
  toggleSpeaker: () => void;
  tickCallTimer: () => void;
}

const REPLY_POOL = [
  "Haha yes exactly! 😂",
  "That's so true 🙌",
  "Okay wait this is actually really good 👏",
  "I was literally just thinking the same thing!",
  "Omg really?? Tell me more 👀",
  "No way 😮",
  "Lol I had a feeling you'd say that",
  "Okay so I have a confession... 🙈",
  "Yes!! Finally someone who gets it ✨",
  "Wait what time is it there?",
  "That makes me like you even more 💕",
  "Okay but hear me out... 🤔",
];

let timerInterval: ReturnType<typeof setInterval> | null = null;

export const useConnectionsStore = create<ConnectionsState>((set, get) => ({
  conversations: MOCK_CONVERSATIONS,
  messages: MOCK_MESSAGES,
  activeConversationId: null,
  call: null,
  callTimer: 0,
  typingTimers: {},

  setActiveConversation: (id) => {
    set({ activeConversationId: id });
    if (id) get().markConversationRead(id);
  },

  // ── Messaging ──────────────────────────────────────────────────────────
  sendMessage: (convId, text, type = "text") => {
    if (!text.trim() && type === "text") return;
    const newMsg: ChatMessage = {
      id: `msg_${Date.now()}`,
      conversationId: convId,
      senderId: ME_ID,
      type,
      text: text.trim(),
      reactions: [],
      status: "sending",
      createdAt: new Date().toISOString(),
      deletedForMe: false,
    };

    // Add message
    set((s) => ({
      messages: {
        ...s.messages,
        [convId]: [...(s.messages[convId] ?? []), newMsg],
      },
      conversations: s.conversations.map((c) =>
        c.id !== convId ? c : {
          ...c,
          lastMessage: type === "text" ? text.trim() : type === "audio" ? "🎤 Voice note" : "📎 Media",
          lastMessageTime: new Date().toISOString(),
          lastSenderId: ME_ID,
          unreadCount: 0,
        }
      ),
    }));

    // Simulate "sent" → "delivered"
    setTimeout(() => {
      set((s) => ({
        messages: {
          ...s.messages,
          [convId]: (s.messages[convId] ?? []).map((m) =>
            m.id === newMsg.id ? { ...m, status: "delivered" } : m
          ),
        },
      }));
    }, 600);

    // Simulate "read" + typing reply (only for direct convs)
    const conv = get().conversations.find((c) => c.id === convId);
    if (conv?.type === "direct") {
      setTimeout(() => {
        set((s) => ({
          messages: {
            ...s.messages,
            [convId]: (s.messages[convId] ?? []).map((m) =>
              m.id === newMsg.id ? { ...m, status: "read" } : m
            ),
          },
        }));
        get().simulateReply(convId);
      }, 1200);
    }
  },

  deleteMessage: (convId, msgId) =>
    set((s) => ({
      messages: {
        ...s.messages,
        [convId]: (s.messages[convId] ?? []).map((m) =>
          m.id === msgId ? { ...m, deletedForMe: true, text: "Message deleted" } : m
        ),
      },
    })),

  reactToMessage: (convId, msgId, emoji) =>
    set((s) => ({
      messages: {
        ...s.messages,
        [convId]: (s.messages[convId] ?? []).map((m) => {
          if (m.id !== msgId) return m;
          const existing = m.reactions.find((r) => r.emoji === emoji);
          const reactions = existing
            ? m.reactions.map((r) =>
                r.emoji === emoji
                  ? r.reactedByMe
                    ? { ...r, count: Math.max(0, r.count - 1), reactedByMe: false }
                    : { ...r, count: r.count + 1, reactedByMe: true }
                  : r
              )
            : [...m.reactions, { emoji, count: 1, reactedByMe: true }];
          return { ...m, reactions };
        }),
      },
    })),

  markConversationRead: (convId) =>
    set((s) => ({
      conversations: s.conversations.map((c) =>
        c.id !== convId ? c : { ...c, unreadCount: 0 }
      ),
      messages: {
        ...s.messages,
        [convId]: (s.messages[convId] ?? []).map((m) =>
          m.senderId !== ME_ID && m.status !== "read" ? { ...m, status: "read" } : m
        ),
      },
    })),

  togglePin: (convId) =>
    set((s) => ({
      conversations: s.conversations.map((c) =>
        c.id !== convId ? c : { ...c, isPinned: !c.isPinned }
      ),
    })),

  toggleMute: (convId) =>
    set((s) => ({
      conversations: s.conversations.map((c) =>
        c.id !== convId ? c : { ...c, isMuted: !c.isMuted }
      ),
    })),

  // ── Simulated reply ────────────────────────────────────────────────────
  simulateReply: (convId) => {
    const delay = 1800 + Math.random() * 2000;
    const conv = get().conversations.find((c) => c.id === convId);
    if (!conv || conv.type !== "direct") return;
    const participant = conv.participants[0];

    // Show typing
    const typingTimer = setTimeout(() => {
      set((s) => ({
        conversations: s.conversations.map((c) =>
          c.id !== convId ? c : { ...c, isTyping: true }
        ),
      }));

      // Send reply
      const replyTimer = setTimeout(() => {
        const replyText = REPLY_POOL[Math.floor(Math.random() * REPLY_POOL.length)];
        const reply: ChatMessage = {
          id: `msg_reply_${Date.now()}`,
          conversationId: convId,
          senderId: participant.id,
          type: "text",
          text: replyText,
          reactions: [],
          status: "delivered",
          createdAt: new Date().toISOString(),
          deletedForMe: false,
        };

        set((s) => ({
          messages: {
            ...s.messages,
            [convId]: [...(s.messages[convId] ?? []), reply],
          },
          conversations: s.conversations.map((c) =>
            c.id !== convId ? c : {
              ...c,
              isTyping: false,
              lastMessage: replyText,
              lastMessageTime: new Date().toISOString(),
              lastSenderId: participant.id,
              unreadCount: s.activeConversationId === convId ? 0 : c.unreadCount + 1,
            }
          ),
        }));
      }, 1200);
    }, delay);
  },

  // ── Group chat ──────────────────────────────────────────────────────────
  createGroupChat: (name, emoji, participantIds) => {
    const participants = participantIds
      .map((id) => Object.values(PARTICIPANTS).find((p) => p.id === id))
      .filter(Boolean) as typeof PARTICIPANTS[keyof typeof PARTICIPANTS][];

    const newConv: Conversation = {
      id: `conv_g_${Date.now()}`,
      type: "group",
      participants,
      groupName: name,
      groupEmoji: emoji,
      groupGradient: [Colors.primary, Colors.accent],
      groupAdminId: ME_ID,
      lastMessage: `${emoji} Group created`,
      lastMessageTime: new Date().toISOString(),
      lastSenderId: ME_ID,
      unreadCount: 0,
      isTyping: false,
      isPinned: false,
      isMuted: false,
    };

    const sysMsg: ChatMessage = {
      id: `msg_sys_${Date.now()}`,
      conversationId: newConv.id,
      senderId: ME_ID,
      type: "system",
      text: `You created the group "${name}" ${emoji}`,
      reactions: [],
      status: "read",
      createdAt: new Date().toISOString(),
      deletedForMe: false,
    };

    set((s) => ({
      conversations: [newConv, ...s.conversations],
      messages: { ...s.messages, [newConv.id]: [sysMsg] },
      activeConversationId: newConv.id,
    }));
  },

  // ── Calls ───────────────────────────────────────────────────────────────
  initiateCall: (convId, type) => {
    const conv = get().conversations.find((c) => c.id === convId);
    if (!conv) return;

    const newCall: ActiveCall = {
      id: `call_${Date.now()}`,
      conversationId: convId,
      type,
      status: "ringing",
      participants: conv.participants,
      startedAt: null,
      duration: 0,
      isMicMuted: false,
      isCameraOff: false,
      isSpeakerOn: false,
    };
    set({ call: newCall });

    // Auto-accept after 2.5s (simulating other side picking up)
    setTimeout(() => {
      const current = get().call;
      if (current && current.status === "ringing") {
        get().acceptCall();
      }
    }, 2500);
  },

  acceptCall: () => {
    const call = get().call;
    if (!call) return;

    set({
      call: {
        ...call,
        status: "active",
        startedAt: new Date().toISOString(),
        duration: 0,
      },
    });

    // Start 1-second tick timer
    if (timerInterval) clearInterval(timerInterval);
    timerInterval = setInterval(() => {
      get().tickCallTimer();
    }, 1000);
  },

  declineCall: () => {
    if (timerInterval) clearInterval(timerInterval);
    timerInterval = null;
    set({ call: null });
  },

  endCall: () => {
    if (timerInterval) clearInterval(timerInterval);
    timerInterval = null;
    const call = get().call;
    if (!call) return;
    set({
      call: { ...call, status: "ended" },
    });
    // Clear after 2 seconds
    setTimeout(() => set({ call: null }), 2000);
  },

  toggleMic: () =>
    set((s) =>
      s.call ? { call: { ...s.call, isMicMuted: !s.call.isMicMuted } } : {}
    ),

  toggleCamera: () =>
    set((s) =>
      s.call ? { call: { ...s.call, isCameraOff: !s.call.isCameraOff } } : {}
    ),

  toggleSpeaker: () =>
    set((s) =>
      s.call ? { call: { ...s.call, isSpeakerOn: !s.call.isSpeakerOn } } : {}
    ),

  tickCallTimer: () => {
    const call = get().call;
    if (!call || call.status !== "active") return;

    const newDuration = call.duration + 1;

    if (newDuration >= CALL_TIME_LIMIT) {
      // Hit 5-minute limit — end automatically
      if (timerInterval) clearInterval(timerInterval);
      timerInterval = null;
      set({
        call: {
          ...call,
          duration: CALL_TIME_LIMIT,
          status: "ended",
        },
      });
      setTimeout(() => set({ call: null }), 2000);
    } else {
      set({ call: { ...call, duration: newDuration } });
    }
  },
}));
