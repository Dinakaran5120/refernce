import { View, Text, Pressable } from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import { LinearGradient } from "expo-linear-gradient";
import { usePathname, useRouter } from "expo-router";
import { Colors, Typography } from "@constants/theme";
import { NotificationBell, NotificationCenter } from "@components/notifications/NotificationCenter";

const SCREEN_TITLES: Record<string, string> = {
  "/":            "Discover",
  "/explore":     "Explore",
  "/post":        "New Post",
  "/connections": "Messages",
  "/profile":     "Profile",
};

export default function TopNavBar() {
  const insets = useSafeAreaInsets();
  const pathname = usePathname();
  const router = useRouter();
  const screenTitle = SCREEN_TITLES[pathname] ?? "lovrhub";
  const isHome = pathname === "/";

  return (
    <View
      style={{
        paddingTop: insets.top,
        backgroundColor: Colors.surface,
        borderBottomWidth: 1,
        borderBottomColor: Colors.border,
      }}
    >
      <View
        style={{
          height: 56,
          flexDirection: "row",
          alignItems: "center",
          paddingHorizontal: 16,
          justifyContent: "space-between",
        }}
      >
        {/* Left */}
        <View style={{ width: 72, alignItems: "flex-start" }}>
          {isHome ? (
            <LinearGradient
              colors={[Colors.primary, Colors.accent]}
              start={{ x: 0, y: 0 }}
              end={{ x: 1, y: 1 }}
              style={{
                width: 32,
                height: 32,
                borderRadius: 10,
                alignItems: "center",
                justifyContent: "center",
              }}
            >
              <Text style={{ fontSize: 17 }}>🔥</Text>
            </LinearGradient>
          ) : (
            <Pressable
              hitSlop={10}
              onPress={() => router.back()}
              style={({ pressed }) => ({ opacity: pressed ? 0.6 : 1 })}
            >
              <Text style={{ fontSize: 22, color: Colors.text }}>←</Text>
            </Pressable>
          )}
        </View>

        {/* Center */}
        <View style={{ flex: 1, alignItems: "center" }}>
          {isHome ? (
            <View style={{ flexDirection: "row", alignItems: "center" }}>
              <Text
                style={{
                  fontSize: 22,
                  fontWeight: "800",
                  letterSpacing: -0.5,
                  color: Colors.text,
                }}
              >
                lovr
              </Text>
              <LinearGradient
                colors={[Colors.primary, Colors.accent]}
                start={{ x: 0, y: 0 }}
                end={{ x: 1, y: 0 }}
                style={{ borderRadius: 5, paddingHorizontal: 4, paddingVertical: 1 }}
              >
                <Text style={{ fontSize: 22, fontWeight: "800", letterSpacing: -0.5, color: "#fff" }}>
                  hub
                </Text>
              </LinearGradient>
            </View>
          ) : (
            <Text
              style={{
                fontSize: 16,
                fontWeight: "700",
                letterSpacing: 0.6,
                textTransform: "uppercase",
                color: Colors.text,
              }}
            >
              {screenTitle}
            </Text>
          )}
        </View>

        {/* Right */}
        <View
          style={{
            width: 72,
            flexDirection: "row",
            alignItems: "center",
            justifyContent: "flex-end",
            gap: 8,
          }}
        >
          {isHome && (
            <Pressable
              hitSlop={8}
              style={({ pressed }) => ({
                opacity: pressed ? 0.6 : 1,
                width: 36,
                height: 36,
                borderRadius: 18,
                backgroundColor: Colors.card,
                alignItems: "center",
                justifyContent: "center",
              })}
            >
              <Text style={{ fontSize: 16 }}>⚙</Text>
            </Pressable>
          )}

          {pathname === "/connections" && (
            <Pressable
              hitSlop={8}
              style={({ pressed }) => ({
                opacity: pressed ? 0.6 : 1,
                width: 36,
                height: 36,
                borderRadius: 18,
                backgroundColor: Colors.card,
                alignItems: "center",
                justifyContent: "center",
              })}
            >
              <Text style={{ fontSize: 18 }}>✏️</Text>
            </Pressable>
          )}

          <NotificationBell />
        </View>
      </View>

      <NotificationCenter />
    </View>
  );
}
