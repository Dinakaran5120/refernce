import { View, Text, Pressable } from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import { LinearGradient } from "expo-linear-gradient";
import { usePathname, useRouter } from "expo-router";
import { Ionicons } from "@expo/vector-icons";
import { useTheme } from "@/context/ThemeContext";
import { NotificationBell, NotificationCenter } from "@components/notifications/NotificationCenter";

const SCREEN_TITLES: Record<string, string> = {
  "/":            "Discover",
  "/explore":     "Explore",
  "/post":        "New Post",
  "/connections": "Messages",
  "/communities": "Groups",
  "/profile":     "Profile",
};

export default function TopNavBar() {
  const insets    = useSafeAreaInsets();
  const pathname  = usePathname();
  const router    = useRouter();
  const { colors, isDark } = useTheme();

  const screenTitle = SCREEN_TITLES[pathname] ?? "lovrhub";
  const isHome      = pathname === "/";

  return (
    <View
      style={{
        paddingTop: insets.top,
        backgroundColor: colors.headerBg,
        borderBottomWidth: 1,
        borderBottomColor: colors.border,
        shadowColor: "#000",
        shadowOffset: { width: 0, height: 1 },
        shadowOpacity: isDark ? 0.3 : 0.06,
        shadowRadius: 8,
        elevation: 4,
      }}
    >
      <View
        style={{
          height: 56,
          flexDirection: "row",
          alignItems: "center",
          paddingHorizontal: 16,
          justifyContent: "space-between",
        }}
      >
        {/* ── Left ── */}
        <View style={{ width: 80, alignItems: "flex-start" }}>
          {isHome ? (
            <LinearGradient
              colors={[colors.primary, colors.accent]}
              start={{ x: 0, y: 0 }}
              end={{ x: 1, y: 1 }}
              style={{
                width: 34,
                height: 34,
                borderRadius: 11,
                alignItems: "center",
                justifyContent: "center",
              }}
            >
              <Ionicons name="flame" size={20} color="#fff" />
            </LinearGradient>
          ) : (
            <Pressable
              hitSlop={10}
              onPress={() => router.back()}
              style={({ pressed }) => ({
                opacity: pressed ? 0.6 : 1,
                width: 34,
                height: 34,
                borderRadius: 10,
                backgroundColor: colors.card,
                alignItems: "center",
                justifyContent: "center",
                borderWidth: 1,
                borderColor: colors.border,
              })}
            >
              <Ionicons name="chevron-back" size={20} color={colors.text} />
            </Pressable>
          )}
        </View>

        {/* ── Center ── */}
        <View style={{ flex: 1, alignItems: "center" }}>
          {isHome ? (
            <View style={{ flexDirection: "row", alignItems: "center", gap: 2 }}>
              <Text
                style={{
                  fontSize: 24,
                  fontWeight: "900",
                  letterSpacing: -0.8,
                  color: colors.text,
                }}
              >
                lovr
              </Text>
              <LinearGradient
                colors={[colors.primary, colors.accent]}
                start={{ x: 0, y: 0 }}
                end={{ x: 1, y: 0 }}
                style={{ borderRadius: 6, paddingHorizontal: 5, paddingVertical: 1 }}
              >
                <Text
                  style={{
                    fontSize: 24,
                    fontWeight: "900",
                    letterSpacing: -0.8,
                    color: "#fff",
                  }}
                >
                  hub
                </Text>
              </LinearGradient>
            </View>
          ) : (
            <Text
              style={{
                fontSize: 16,
                fontWeight: "800",
                letterSpacing: 0.4,
                color: colors.text,
              }}
            >
              {screenTitle}
            </Text>
          )}
        </View>

        {/* ── Right ── */}
        <View
          style={{
            width: 80,
            flexDirection: "row",
            alignItems: "center",
            justifyContent: "flex-end",
            gap: 8,
          }}
        >
          {isHome && (
            <Pressable
              hitSlop={8}
              style={({ pressed }) => ({
                opacity: pressed ? 0.6 : 1,
                width: 34,
                height: 34,
                borderRadius: 10,
                backgroundColor: colors.card,
                alignItems: "center",
                justifyContent: "center",
                borderWidth: 1,
                borderColor: colors.border,
              })}
            >
              <Ionicons name="options-outline" size={18} color={colors.text} />
            </Pressable>
          )}

          {pathname === "/connections" && (
            <Pressable
              hitSlop={8}
              style={({ pressed }) => ({
                opacity: pressed ? 0.6 : 1,
                width: 34,
                height: 34,
                borderRadius: 10,
                backgroundColor: colors.card,
                alignItems: "center",
                justifyContent: "center",
                borderWidth: 1,
                borderColor: colors.border,
              })}
            >
              <Ionicons name="create-outline" size={18} color={colors.text} />
            </Pressable>
          )}

          <NotificationBell />
        </View>
      </View>

      <NotificationCenter />
    </View>
  );
}
