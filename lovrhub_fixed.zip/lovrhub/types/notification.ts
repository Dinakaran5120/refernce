export type NotificationType =
  | "follow"
  | "message"
  | "match"
  | "like_post"
  | "like_profile"
  | "comment"
  | "community_post"
  | "community_join_request"
  | "community_join_approved"
  | "community_join_rejected"
  | "profile_view"
  | "super_like"
  | "mention"
  | "system";

export type NotificationGroup =
  | "social"      // follows, likes, profile views
  | "messages"    // DMs, matches
  | "activity"    // comments, mentions
  | "communities" // community events
  | "system";     // system/product

export interface NotificationActor {
  id: string;
  name: string;
  avatarEmoji: string;
  gradient: [string, string];
  verified: boolean;
}

export interface Notification {
  id: string;
  type: NotificationType;
  group: NotificationGroup;
  actor: NotificationActor | null;   // null for system notifications
  targetId?: string;                  // post/community/message id
  targetPreview?: string;             // preview text of the target
  read: boolean;
  createdAt: string;
  // Extra metadata
  communityName?: string;
  communityEmoji?: string;
}
