import { useMemo } from "react";
import { useDiscoverStore } from "@/store/discoverStore";
import type { NearbyUser } from "@/types/discover";

/**
 * Returns the filtered + sorted list of nearby users.
 * All filtering is memoised — only re-runs when users, filters,
 * or the active intent tab changes.
 */
export function useDiscoverFilters(): NearbyUser[] {
  const users              = useDiscoverStore((s) => s.users);
  const filters            = useDiscoverStore((s) => s.filters);
  const activeIntentFilter = useDiscoverStore((s) => s.activeIntentFilter);

  return useMemo(() => {
    let result = [...users];

    // ── 1. Intent tab (top pill filter) ──────────────────────────────────
    if (activeIntentFilter !== "All") {
      result = result.filter((u) =>
        u.intent.includes(activeIntentFilter as any)
      );
    }

    // ── 2. Age range ──────────────────────────────────────────────────────
    result = result.filter(
      (u) => u.age >= filters.ageMin && u.age <= filters.ageMax
    );

    // ── 3. Distance ───────────────────────────────────────────────────────
    result = result.filter((u) => u.distanceKm <= filters.maxDistanceKm);

    // ── 4. Orientation (multi-select; empty = all) ─────────────────────────
    if (filters.orientations.length > 0) {
      result = result.filter((u) =>
        filters.orientations.includes(u.orientation)
      );
    }

    // ── 5. Intent (multi-select from filter sheet; empty = all) ──────────
    if (filters.intents.length > 0) {
      result = result.filter((u) =>
        filters.intents.some((i) => u.intent.includes(i))
      );
    }

    // ── 6. Online only ────────────────────────────────────────────────────
    if (filters.onlineOnly) {
      result = result.filter((u) => u.online);
    }

    // ── 7. Favourites only ────────────────────────────────────────────────
    if (filters.favouritesOnly) {
      result = result.filter((u) => u.favourited);
    }

    // ── 8. Sort: online first, then by distance ───────────────────────────
    result.sort((a, b) => {
      if (a.online !== b.online) return a.online ? -1 : 1;
      return a.distanceKm - b.distanceKm;
    });

    return result;
  }, [users, filters, activeIntentFilter]);
}

/** Active filter count — used to show badge on filter button */
export function useActiveFilterCount(): number {
  const filters = useDiscoverStore((s) => s.filters);

  return useMemo(() => {
    let count = 0;
    if (filters.ageMin !== 18 || filters.ageMax !== 50) count++;
    if (filters.maxDistanceKm !== 50) count++;
    if (filters.orientations.length > 0) count++;
    if (filters.intents.length > 0) count++;
    if (filters.onlineOnly) count++;
    if (filters.favouritesOnly) count++;
    return count;
  }, [filters]);
}

/** Formats last seen time relative to now */
export function useLastSeen(isoString: string): string {
  return useMemo(() => {
    const diff = Date.now() - new Date(isoString).getTime();
    const mins  = Math.floor(diff / 60000);
    const hours = Math.floor(diff / 3600000);
    const days  = Math.floor(diff / 86400000);

    if (mins < 2)   return "Just now";
    if (mins < 60)  return `${mins}m ago`;
    if (hours < 24) return `${hours}h ago`;
    return `${days}d ago`;
  }, [isoString]);
}
