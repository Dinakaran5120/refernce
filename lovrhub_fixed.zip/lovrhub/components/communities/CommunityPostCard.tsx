import { View, Text, Pressable } from "react-native";
import { LinearGradient } from "expo-linear-gradient";
import { Colors } from "@constants/theme";
import { useCommunityStore } from "@/store/communityStore";
import { timeAgo, fmtNum, totalPollVotes } from "@/hooks/useCommunity";
import type { CommunityPost } from "@/types/community";

// ── Author header ──────────────────────────────────────────────────────────────
function PostAuthorRow({ post }: { post: CommunityPost }) {
  return (
    <View style={{ flexDirection: "row", alignItems: "center", paddingHorizontal: 16, paddingTop: 14, paddingBottom: 10, gap: 10 }}>
      <LinearGradient
        colors={post.author.gradient}
        start={{ x: 0, y: 0 }} end={{ x: 1, y: 1 }}
        style={{ width: 38, height: 38, borderRadius: 19, alignItems: "center", justifyContent: "center" }}
      >
        <Text style={{ fontSize: 18 }}>{post.author.avatarEmoji}</Text>
      </LinearGradient>
      <View style={{ flex: 1, gap: 2 }}>
        <View style={{ flexDirection: "row", alignItems: "center", gap: 6 }}>
          <Text style={{ fontSize: 13, fontWeight: "700", color: Colors.text }}>{post.author.name}</Text>
          {post.author.role === "owner" && (
            <View style={{ paddingHorizontal: 6, paddingVertical: 2, borderRadius: 6, backgroundColor: Colors.gold + "22", borderWidth: 1, borderColor: Colors.gold + "44" }}>
              <Text style={{ fontSize: 12, color: Colors.gold, fontWeight: "700" }}>Owner</Text>
            </View>
          )}
          {post.author.role === "admin" && (
            <View style={{ paddingHorizontal: 6, paddingVertical: 2, borderRadius: 6, backgroundColor: Colors.violet + "18", borderWidth: 1, borderColor: Colors.violet + "33" }}>
              <Text style={{ fontSize: 12, color: Colors.violet, fontWeight: "700" }}>Admin</Text>
            </View>
          )}
        </View>
        <Text style={{ fontSize: 11, color: Colors.textMuted }}>{timeAgo(post.createdAt)}</Text>
      </View>
      {post.isPinned && <Text style={{ fontSize: 16 }}>📌</Text>}
      <Pressable style={({ pressed }) => ({ opacity: pressed ? 0.6 : 1, width: 28, height: 28, borderRadius: 14, backgroundColor: Colors.card, alignItems: "center", justifyContent: "center" })}>
        <Text style={{ fontSize: 13, color: Colors.textMuted }}>•••</Text>
      </Pressable>
    </View>
  );
}

// ── Like + comment bar ─────────────────────────────────────────────────────────
function PostActionBar({ post, communityId }: { post: CommunityPost; communityId: string }) {
  const likePost = useCommunityStore((s) => s.likePost);
  return (
    <View
      style={{
        flexDirection: "row", alignItems: "center", gap: 12,
        paddingHorizontal: 16, paddingVertical: 12,
        borderTopWidth: 1, borderTopColor: Colors.border,
      }}
    >
      <Pressable
        onPress={() => likePost(communityId, post.id)}
        style={({ pressed }) => ({
          flexDirection: "row", alignItems: "center", gap: 6,
          paddingHorizontal: 14, paddingVertical: 8, borderRadius: 14,
          backgroundColor: post.liked ? Colors.primary + "18" : Colors.card,
          borderWidth: 1.5, borderColor: post.liked ? Colors.primary : Colors.border,
          opacity: pressed ? 0.7 : 1,
        })}
      >
        <Text style={{ fontSize: 15 }}>{post.liked ? "❤️" : "🤍"}</Text>
        {post.likes > 0 && (
          <Text style={{ fontSize: 13, fontWeight: "700", color: post.liked ? Colors.primary : Colors.textMuted }}>
            {fmtNum(post.likes)}
          </Text>
        )}
      </Pressable>

      <Pressable
        style={({ pressed }) => ({
          flexDirection: "row", alignItems: "center", gap: 6,
          paddingHorizontal: 14, paddingVertical: 8, borderRadius: 14,
          backgroundColor: Colors.card, borderWidth: 1, borderColor: Colors.border,
          opacity: pressed ? 0.7 : 1,
        })}
      >
        <Text style={{ fontSize: 15 }}>💬</Text>
        {post.commentCount > 0 && (
          <Text style={{ fontSize: 13, fontWeight: "700", color: Colors.textMuted }}>
            {fmtNum(post.commentCount)}
          </Text>
        )}
      </Pressable>

      <Pressable
        style={({ pressed }) => ({
          flexDirection: "row", alignItems: "center", gap: 6,
          paddingHorizontal: 14, paddingVertical: 8, borderRadius: 14,
          backgroundColor: Colors.card, borderWidth: 1, borderColor: Colors.border,
          opacity: pressed ? 0.7 : 1,
        })}
      >
        <Text style={{ fontSize: 15 }}>↗️</Text>
      </Pressable>
    </View>
  );
}

// ── Poll component ─────────────────────────────────────────────────────────────
function PollBlock({ post, communityId }: { post: CommunityPost; communityId: string }) {
  const voteOnPoll = useCommunityStore((s) => s.voteOnPoll);
  const options    = post.pollOptions ?? [];
  const total      = totalPollVotes(options);
  const hasVoted   = options.some((o) => o.votedByMe);

  return (
    <View style={{ paddingHorizontal: 16, paddingBottom: 14, gap: 8 }}>
      {options.map((option) => {
        const pct = total > 0 ? Math.round((option.votes / total) * 100) : 0;
        return (
          <Pressable
            key={option.id}
            onPress={() => voteOnPoll(communityId, post.id, option.id)}
            style={({ pressed }) => ({
              borderRadius: 14, overflow: "hidden",
              borderWidth: 1.5,
              borderColor: option.votedByMe ? Colors.primary : Colors.border,
              opacity: pressed ? 0.8 : 1,
            })}
          >
            {/* Fill bar */}
            {hasVoted && (
              <View
                style={{
                  position: "absolute", top: 0, left: 0, bottom: 0,
                  width: `${pct}%`,
                  backgroundColor: option.votedByMe ? Colors.primary + "22" : Colors.card,
                  borderRadius: 12,
                }}
              />
            )}
            <View style={{ flexDirection: "row", alignItems: "center", justifyContent: "space-between", padding: 13 }}>
              <Text style={{ fontSize: 14, fontWeight: option.votedByMe ? "700" : "500", color: option.votedByMe ? Colors.primary : Colors.text }}>
                {option.text}
              </Text>
              {hasVoted && (
                <View style={{ flexDirection: "row", alignItems: "center", gap: 4 }}>
                  {option.votedByMe && <Text style={{ fontSize: 12 }}>✓</Text>}
                  <Text style={{ fontSize: 13, fontWeight: "700", color: option.votedByMe ? Colors.primary : Colors.textMuted }}>
                    {pct}%
                  </Text>
                </View>
              )}
            </View>
          </Pressable>
        );
      })}
      <Text style={{ fontSize: 12, color: Colors.textMuted }}>
        {fmtNum(total)} votes
        {post.pollEndsAt && ` · Ends ${timeAgo(post.pollEndsAt)}`}
      </Text>
    </View>
  );
}

// ── Announcement banner ────────────────────────────────────────────────────────
function AnnouncementBanner({ post }: { post: CommunityPost }) {
  return (
    <LinearGradient
      colors={[Colors.primary + "18", Colors.accent + "0a"]}
      start={{ x: 0, y: 0 }} end={{ x: 1, y: 1 }}
      style={{
        marginHorizontal: 16, marginBottom: 12,
        borderRadius: 14, padding: 14, gap: 6,
        borderLeftWidth: 4, borderLeftColor: Colors.primary,
        borderTopWidth: 1, borderTopColor: Colors.primary + "33",
        borderRightWidth: 1, borderRightColor: Colors.border,
        borderBottomWidth: 1, borderBottomColor: Colors.border,
      }}
    >
      <View style={{ flexDirection: "row", alignItems: "center", gap: 6, marginBottom: 2 }}>
        <Text style={{ fontSize: 14 }}>📢</Text>
        <Text style={{ fontSize: 12, fontWeight: "800", color: Colors.primary, letterSpacing: 0.5 }}>ANNOUNCEMENT</Text>
      </View>
      {post.title && (
        <Text style={{ fontSize: 15, fontWeight: "800", color: Colors.text, lineHeight: 21 }}>{post.title}</Text>
      )}
      <Text style={{ fontSize: 14, color: Colors.textSecondary, lineHeight: 21 }}>{post.content}</Text>
    </LinearGradient>
  );
}

// ── Main post card router ──────────────────────────────────────────────────────
export function CommunityPostCard({ post, communityId }: { post: CommunityPost; communityId: string }) {
  return (
    <View
      style={{
        backgroundColor: Colors.surface,
        borderRadius: 20, overflow: "hidden",
        borderWidth: 1, borderColor: Colors.border,
        marginBottom: 12,
        shadowColor: "#000", shadowOffset: { width: 0, height: 2 },
        shadowOpacity: 0.05, shadowRadius: 6, elevation: 2,
      }}
    >
      <PostAuthorRow post={post} />

      {/* Announcement */}
      {post.isAnnouncement ? (
        <AnnouncementBanner post={post} />
      ) : (
        <>
          {/* Title (for events/announcements) */}
          {post.title && (
            <Text style={{ fontSize: 16, fontWeight: "800", color: Colors.text, paddingHorizontal: 16, marginBottom: 6, lineHeight: 22 }}>
              {post.title}
            </Text>
          )}

          {/* Text content */}
          <Text style={{ fontSize: 15, color: Colors.text, lineHeight: 23, paddingHorizontal: 16, paddingBottom: post.type === "poll" || post.mediaEmoji ? 12 : 16 }}>
            {post.content}
          </Text>

          {/* Image */}
          {post.mediaEmoji && post.mediaGradient && (
            <LinearGradient
              colors={post.mediaGradient}
              start={{ x: 0, y: 0 }} end={{ x: 1, y: 1 }}
              style={{ height: 180, alignItems: "center", justifyContent: "center", marginBottom: 4 }}
            >
              <Text style={{ fontSize: 64 }}>{post.mediaEmoji}</Text>
            </LinearGradient>
          )}

          {/* Poll */}
          {post.type === "poll" && post.pollOptions && (
            <PollBlock post={post} communityId={communityId} />
          )}
        </>
      )}

      {/* Tags */}
      {post.tags.length > 0 && (
        <View style={{ flexDirection: "row", flexWrap: "wrap", gap: 6, paddingHorizontal: 16, paddingBottom: 10 }}>
          {post.tags.map((tag) => (
            <Text key={tag} style={{ fontSize: 12, color: Colors.primary, fontWeight: "600" }}>#{tag}</Text>
          ))}
        </View>
      )}

      <PostActionBar post={post} communityId={communityId} />
    </View>
  );
}
