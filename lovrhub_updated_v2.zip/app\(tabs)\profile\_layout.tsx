import { Stack } from "expo-router";

export default function ProfileLayout() {
  return (
    <Stack screenOptions={{ headerShown: false, animation: "slide_from_right" }}>
      <Stack.Screen name="index"          options={{ animation: "none" }} />
      <Stack.Screen name="edit"           />
      <Stack.Screen name="settings"       />
      <Stack.Screen name="notifications"  />
      <Stack.Screen name="privacy-policy" />
      <Stack.Screen name="help"           />
    </Stack>
  );
}
