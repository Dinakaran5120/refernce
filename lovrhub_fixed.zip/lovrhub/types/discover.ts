export type Intent = "Dating" | "Friends" | "Hookup" | "LGBTQ+" | "Open to all";
export type Orientation =
  | "Straight"
  | "Gay"
  | "Lesbian"
  | "Bisexual"
  | "Pansexual"
  | "Queer"
  | "Asexual"
  | "Questioning"
  | "Any";
export type ProfilePrivacy = "public" | "private";
export type ProfileRequestStatus =
  | "none"
  | "pending"
  | "accepted"
  | "rejected";

export interface Coordinates {
  latitude: number;
  longitude: number;
}

export interface NearbyUser {
  id: string;
  name: string;
  age: number;
  avatarEmoji: string;
  gradient: [string, string];
  bio: string;
  tags: string[];
  intent: Intent[];
  orientation: Orientation;
  online: boolean;
  lastSeen: string; // ISO string
  verified: boolean;
  privacy: ProfilePrivacy;
  location: Coordinates;
  distanceKm: number;         // computed from user coords
  liked: boolean;
  superLiked: boolean;
  favourited: boolean;
  requestStatus: ProfileRequestStatus;
  photos: string[];           // emoji placeholders
  languages: string[];
  lookingFor: string[];
  mutualFriends: number;
}

export interface DiscoverFilters {
  ageMin: number;
  ageMax: number;
  maxDistanceKm: number;
  orientations: Orientation[];
  intents: Intent[];
  onlineOnly: boolean;
  favouritesOnly: boolean;
}

export const DEFAULT_FILTERS: DiscoverFilters = {
  ageMin: 18,
  ageMax: 50,
  maxDistanceKm: 50,
  orientations: [],
  intents: [],
  onlineOnly: false,
  favouritesOnly: false,
};
