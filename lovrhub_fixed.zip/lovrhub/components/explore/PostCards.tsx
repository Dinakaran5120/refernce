import { useState } from "react";
import {
  View, Text, Pressable, Dimensions,
} from "react-native";
import { LinearGradient } from "expo-linear-gradient";
import { Colors } from "@constants/theme";
import { PostHeader } from "@components/explore/PostHeader";
import { VibeBar } from "@components/explore/VibeBar";
import type { ExplorePost } from "@/types/explore";

const { width: W } = Dimensions.get("window");

// ── Shared card shell ──────────────────────────────────────────────────────────
function CardShell({ children }: { children: React.ReactNode }) {
  return (
    <View
      style={{
        backgroundColor: Colors.surface,
        borderRadius: 20,
        overflow: "hidden",
        marginBottom: 12,
        borderWidth: 1,
        borderColor: Colors.border,
        shadowColor: "#000",
        shadowOffset: { width: 0, height: 2 },
        shadowOpacity: 0.05,
        shadowRadius: 8,
        elevation: 2,
      }}
    >
      {children}
    </View>
  );
}

// ── Tags row ───────────────────────────────────────────────────────────────────
function TagsRow({ tags }: { tags: string[] }) {
  if (!tags.length) return null;
  return (
    <View
      style={{
        flexDirection: "row",
        flexWrap: "wrap",
        gap: 6,
        paddingHorizontal: 16,
        paddingBottom: 10,
      }}
    >
      {tags.map((tag) => (
        <Text key={tag} style={{ fontSize: 12, color: Colors.primary, fontWeight: "600" }}>
          {tag}
        </Text>
      ))}
    </View>
  );
}

// ─────────────────────────────────────────────────────────────────────────────
// 1. TEXT POST
// ─────────────────────────────────────────────────────────────────────────────
export function TextPostCard({ post }: { post: ExplorePost }) {
  return (
    <CardShell>
      <PostHeader post={post} />
      <Text
        style={{
          fontSize: 15,
          color: Colors.text,
          lineHeight: 23,
          paddingHorizontal: 16,
          paddingBottom: 12,
        }}
      >
        {post.caption}
      </Text>
      <TagsRow tags={post.tags} />
      <VibeBar post={post} />
    </CardShell>
  );
}

// ─────────────────────────────────────────────────────────────────────────────
// 2. IMAGE POST
// ─────────────────────────────────────────────────────────────────────────────
export function ImagePostCard({ post }: { post: ExplorePost }) {
  return (
    <CardShell>
      <PostHeader post={post} />

      {/* Image placeholder */}
      <LinearGradient
        colors={post.mediaGradient ?? [Colors.card, Colors.border]}
        start={{ x: 0, y: 0 }} end={{ x: 1, y: 1 }}
        style={{
          width: "100%",
          height: W * 0.78,
          alignItems: "center",
          justifyContent: "center",
        }}
      >
        <Text style={{ fontSize: 72 }}>{post.mediaEmoji}</Text>
        {/* Gradient overlay at bottom */}
        <LinearGradient
          colors={["transparent", "rgba(0,0,0,0.45)"]}
          style={{
            position: "absolute",
            bottom: 0, left: 0, right: 0,
            height: 80,
          }}
          pointerEvents="none"
        />
      </LinearGradient>

      {/* Caption */}
      <Text
        style={{
          fontSize: 14,
          color: Colors.text,
          lineHeight: 21,
          paddingHorizontal: 16,
          paddingTop: 12,
          paddingBottom: 8,
        }}
      >
        {post.caption}
      </Text>
      <TagsRow tags={post.tags} />
      <VibeBar post={post} />
    </CardShell>
  );
}

// ─────────────────────────────────────────────────────────────────────────────
// 3. VIDEO (PREVIEW) POST  — full Reels viewer is separate
// ─────────────────────────────────────────────────────────────────────────────
export function VideoPostCard({
  post,
  onOpenReel,
}: {
  post: ExplorePost;
  onOpenReel: () => void;
}) {
  return (
    <CardShell>
      <PostHeader post={post} />

      {/* Video thumbnail */}
      <Pressable onPress={onOpenReel}>
        <LinearGradient
          colors={post.mediaGradient ?? [Colors.card, Colors.border]}
          start={{ x: 0, y: 0 }} end={{ x: 1, y: 1 }}
          style={{
            width: "100%",
            height: W * 0.65,
            alignItems: "center",
            justifyContent: "center",
          }}
        >
          <Text style={{ fontSize: 72 }}>{post.mediaEmoji}</Text>

          {/* Play button */}
          <View
            style={{
              position: "absolute",
              width: 60,
              height: 60,
              borderRadius: 30,
              backgroundColor: "rgba(0,0,0,0.5)",
              alignItems: "center",
              justifyContent: "center",
              borderWidth: 2,
              borderColor: "rgba(255,255,255,0.7)",
            }}
          >
            <Text style={{ fontSize: 22, color: "#fff", marginLeft: 4 }}>▶</Text>
          </View>

          {/* Duration badge */}
          <View
            style={{
              position: "absolute",
              bottom: 10,
              right: 10,
              backgroundColor: "rgba(0,0,0,0.6)",
              paddingHorizontal: 8,
              paddingVertical: 3,
              borderRadius: 8,
            }}
          >
            <Text style={{ color: "#fff", fontSize: 12, fontWeight: "700" }}>
              {post.videoDuration}
            </Text>
          </View>

          {/* Reels badge */}
          <View
            style={{
              position: "absolute",
              top: 10,
              left: 10,
              flexDirection: "row",
              alignItems: "center",
              gap: 5,
              backgroundColor: "rgba(0,0,0,0.5)",
              paddingHorizontal: 10,
              paddingVertical: 4,
              borderRadius: 10,
            }}
          >
            <Text style={{ color: "#fff", fontSize: 11 }}>▶</Text>
            <Text style={{ color: "#fff", fontSize: 11, fontWeight: "700" }}>Reel</Text>
          </View>
        </LinearGradient>
      </Pressable>

      <Text
        style={{
          fontSize: 14, color: Colors.text, lineHeight: 21,
          paddingHorizontal: 16, paddingTop: 12, paddingBottom: 8,
        }}
      >
        {post.caption}
      </Text>
      <TagsRow tags={post.tags} />
      <VibeBar post={post} />
    </CardShell>
  );
}

// ─────────────────────────────────────────────────────────────────────────────
// 4. THOUGHT POST
// ─────────────────────────────────────────────────────────────────────────────
export function ThoughtPostCard({ post }: { post: ExplorePost }) {
  return (
    <CardShell>
      <PostHeader post={post} />

      {/* Thought bubble */}
      <LinearGradient
        colors={[Colors.card, Colors.background]}
        start={{ x: 0, y: 0 }} end={{ x: 1, y: 1 }}
        style={{
          marginHorizontal: 16,
          marginBottom: 12,
          borderRadius: 16,
          padding: 18,
          borderWidth: 1,
          borderColor: Colors.border,
          borderLeftWidth: 4,
          borderLeftColor: Colors.primary,
        }}
      >
        <Text style={{ fontSize: 17, color: Colors.text, lineHeight: 26, fontWeight: "500", fontStyle: "italic" }}>
          "{post.caption}"
        </Text>
      </LinearGradient>

      <TagsRow tags={post.tags} />
      <VibeBar post={post} />
    </CardShell>
  );
}

// ─────────────────────────────────────────────────────────────────────────────
// 5. MOOD POST  (anonymous or named)
// ─────────────────────────────────────────────────────────────────────────────
export function MoodPostCard({ post }: { post: ExplorePost }) {
  return (
    <CardShell>
      <PostHeader post={post} />

      {/* Mood gradient block */}
      <LinearGradient
        colors={post.moodGradient ?? [Colors.secondary, Colors.rose]}
        start={{ x: 0, y: 0 }} end={{ x: 1, y: 1 }}
        style={{
          marginHorizontal: 16,
          marginBottom: 12,
          borderRadius: 18,
          padding: 20,
          gap: 10,
        }}
      >
        {post.mood && (
          <View
            style={{
              alignSelf: "flex-start",
              backgroundColor: "rgba(255,255,255,0.25)",
              paddingHorizontal: 12,
              paddingVertical: 4,
              borderRadius: 12,
            }}
          >
            <Text style={{ color: "#fff", fontSize: 11, fontWeight: "800", letterSpacing: 0.5 }}>
              {post.mood.toUpperCase()}
            </Text>
          </View>
        )}
        <Text
          style={{
            color: "#fff",
            fontSize: 17,
            lineHeight: 26,
            fontWeight: "600",
          }}
        >
          {post.caption}
        </Text>
        {post.author.isAnonymous && (
          <Text style={{ color: "rgba(255,255,255,0.7)", fontSize: 12, fontWeight: "600" }}>
            — shared anonymously
          </Text>
        )}
      </LinearGradient>

      <TagsRow tags={post.tags} />
      <VibeBar post={post} />
    </CardShell>
  );
}

// ─────────────────────────────────────────────────────────────────────────────
// 6. POST CARD ROUTER
// ─────────────────────────────────────────────────────────────────────────────
export function PostCard({
  post,
  onOpenReel,
}: {
  post: ExplorePost;
  onOpenReel: () => void;
}) {
  switch (post.type) {
    case "image":   return <ImagePostCard post={post} />;
    case "video":   return <VideoPostCard post={post} onOpenReel={onOpenReel} />;
    case "thought": return <ThoughtPostCard post={post} />;
    case "mood":    return <MoodPostCard post={post} />;
    case "text":
    default:        return <TextPostCard post={post} />;
  }
}
