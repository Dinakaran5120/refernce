import { View, Text, Pressable } from "react-native";
import { LinearGradient } from "expo-linear-gradient";
import { Colors } from "@constants/theme";
import { useDiscoverStore } from "@/store/discoverStore";

export function EmptyDiscover() {
  const resetFilters   = useDiscoverStore((s) => s.resetFilters);
  const setShowSheet   = useDiscoverStore((s) => s.setShowFilterSheet);

  return (
    <View
      style={{
        alignItems: "center",
        paddingVertical: 60,
        paddingHorizontal: 32,
        gap: 16,
      }}
    >
      <View
        style={{
          width: 100,
          height: 100,
          borderRadius: 50,
          backgroundColor: Colors.card,
          alignItems: "center",
          justifyContent: "center",
          borderWidth: 2,
          borderColor: Colors.border,
          borderStyle: "dashed",
          marginBottom: 8,
        }}
      >
        <Text style={{ fontSize: 44 }}>🔍</Text>
      </View>
      <Text
        style={{
          fontSize: 22,
          fontWeight: "800",
          color: Colors.text,
          textAlign: "center",
          letterSpacing: -0.3,
        }}
      >
        No matches found
      </Text>
      <Text
        style={{
          fontSize: 15,
          color: Colors.textMuted,
          textAlign: "center",
          lineHeight: 22,
        }}
      >
        Try adjusting your filters or expanding your search distance.
      </Text>

      <Pressable
        onPress={() => setShowSheet(true)}
        style={({ pressed }) => ({
          opacity: pressed ? 0.85 : 1,
          transform: [{ scale: pressed ? 0.97 : 1 }],
          width: "100%",
        })}
      >
        <LinearGradient
          colors={[Colors.primary, Colors.accent]}
          start={{ x: 0, y: 0 }}
          end={{ x: 1, y: 0 }}
          style={{ borderRadius: 16, paddingVertical: 16, alignItems: "center" }}
        >
          <Text style={{ color: "#fff", fontSize: 15, fontWeight: "800" }}>
            Adjust Filters ⚙
          </Text>
        </LinearGradient>
      </Pressable>

      <Pressable
        onPress={resetFilters}
        style={({ pressed }) => ({
          opacity: pressed ? 0.7 : 1,
          paddingVertical: 12,
        })}
      >
        <Text style={{ color: Colors.primary, fontSize: 14, fontWeight: "700" }}>
          Reset all filters
        </Text>
      </Pressable>
    </View>
  );
}
