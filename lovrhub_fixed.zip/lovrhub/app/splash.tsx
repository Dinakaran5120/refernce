import { useEffect, useRef } from "react";
import { View, Text, Animated, Dimensions } from "react-native";
import { LinearGradient } from "expo-linear-gradient";
import { Colors } from "@constants/theme";

const { width: W, height: H } = Dimensions.get("window");

export default function SplashScreen() {
  const scale   = useRef(new Animated.Value(0.7)).current;
  const opacity = useRef(new Animated.Value(0)).current;
  const tagLine = useRef(new Animated.Value(0)).current;

  useEffect(() => {
    Animated.sequence([
      Animated.parallel([
        Animated.spring(scale,   { toValue: 1, useNativeDriver: true, stiffness: 200, damping: 15 }),
        Animated.timing(opacity, { toValue: 1, duration: 400,         useNativeDriver: true }),
      ]),
      Animated.delay(200),
      Animated.timing(tagLine, { toValue: 1, duration: 500, useNativeDriver: true }),
    ]).start();
  }, []);

  return (
    <LinearGradient
      colors={[Colors.primary, Colors.secondary, Colors.accent]}
      start={{ x: 0, y: 0 }} end={{ x: 1, y: 1 }}
      style={{ flex: 1, alignItems: "center", justifyContent: "center", gap: 20 }}
    >
      {/* Logo */}
      <Animated.View style={{ transform: [{ scale }], opacity, alignItems: "center", gap: 12 }}>
        <View
          style={{
            width: 100, height: 100, borderRadius: 28,
            backgroundColor: "rgba(255,255,255,0.2)",
            alignItems: "center", justifyContent: "center",
            borderWidth: 2, borderColor: "rgba(255,255,255,0.4)",
          }}
        >
          <Text style={{ fontSize: 56 }}>🔥</Text>
        </View>
        <Text
          style={{
            fontSize: 42, fontWeight: "900", color: "#fff",
            letterSpacing: -1,
          }}
        >
          lovrhub
        </Text>
      </Animated.View>

      {/* Tagline */}
      <Animated.Text
        style={{
          fontSize: 16, color: "rgba(255,255,255,0.85)",
          fontWeight: "500", letterSpacing: 0.3,
          opacity: tagLine,
          transform: [{ translateY: tagLine.interpolate({ inputRange: [0, 1], outputRange: [10, 0] }) }],
        }}
      >
        Find your people. Be yourself. 🌈
      </Animated.Text>

      {/* Pride strip */}
      <Animated.View
        style={{
          flexDirection: "row", height: 4, width: W * 0.5, borderRadius: 2,
          overflow: "hidden", opacity: tagLine,
        }}
      >
        {Colors.pride.map((c, i) => (
          <View key={i} style={{ flex: 1, backgroundColor: c }} />
        ))}
      </Animated.View>
    </LinearGradient>
  );
}
