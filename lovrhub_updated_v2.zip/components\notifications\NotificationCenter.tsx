import { useState, useMemo } from "react";
import {
  View, Text, Modal, Pressable, ScrollView,
  SectionList, Switch,
} from "react-native";
import { LinearGradient } from "expo-linear-gradient";
import { Ionicons } from "@expo/vector-icons";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import { useTheme } from "@/context/ThemeContext";
import { useNotificationStore } from "@/store/notificationStore";
import {
  useFilteredNotifications,
  useGroupUnreadCounts,
  useTotalUnread,
  groupByDate,
  GROUP_CONFIG,
} from "@/hooks/useNotifications";
import { NotificationRow } from "@components/notifications/NotificationRow";
import type { NotificationGroup } from "@/types/notification";

const GROUPS: (NotificationGroup | "all")[] = [
  "all", "social", "messages", "activity", "communities", "system",
];

// ── Group tab pill ─────────────────────────────────────────────────────────────
function GroupPill({
  group, active, unread, onPress,
}: {
  group: NotificationGroup | "all";
  active: boolean;
  unread: number;
  onPress: () => void;
}) {
  const { colors } = useTheme();
  const cfg = GROUP_CONFIG[group];

  return (
    <Pressable onPress={onPress} style={({ pressed }) => ({ opacity: pressed ? 0.75 : 1 })}>
      {active ? (
        <LinearGradient
          colors={[cfg.color, cfg.color + "cc"]}
          start={{ x: 0, y: 0 }} end={{ x: 1, y: 0 }}
          style={{ flexDirection: "row", alignItems: "center", gap: 5, paddingHorizontal: 14, paddingVertical: 8, borderRadius: 20 }}
        >
          <Text style={{ fontSize: 13 }}>{cfg.emoji}</Text>
          <Text style={{ color: "#fff", fontSize: 13, fontWeight: "700" }}>{cfg.label}</Text>
          {unread > 0 && (
            <View style={{ backgroundColor: "rgba(255,255,255,0.3)", paddingHorizontal: 6, paddingVertical: 1, borderRadius: 8 }}>
              <Text style={{ color: "#fff", fontSize: 10, fontWeight: "800" }}>{unread}</Text>
            </View>
          )}
        </LinearGradient>
      ) : (
        <View style={{ flexDirection: "row", alignItems: "center", gap: 5, paddingHorizontal: 14, paddingVertical: 8, borderRadius: 20, backgroundColor: colors.card, borderWidth: 1, borderColor: colors.border }}>
          <Text style={{ fontSize: 13 }}>{cfg.emoji}</Text>
          <Text style={{ color: colors.textSecondary, fontSize: 13, fontWeight: "600" }}>{cfg.label}</Text>
          {unread > 0 && (
            <View style={{ backgroundColor: colors.primary, paddingHorizontal: 6, paddingVertical: 1, borderRadius: 8 }}>
              <Text style={{ color: "#fff", fontSize: 10, fontWeight: "800" }}>{unread}</Text>
            </View>
          )}
        </View>
      )}
    </Pressable>
  );
}

// ── Date section header ────────────────────────────────────────────────────────
function SectionHeader({ title }: { title: string }) {
  const { colors } = useTheme();
  return (
    <View style={{ paddingHorizontal: 16, paddingTop: 16, paddingBottom: 6, backgroundColor: colors.background }}>
      <Text style={{ fontSize: 12, fontWeight: "800", color: colors.textMuted, letterSpacing: 0.6 }}>
        {title.toUpperCase()}
      </Text>
    </View>
  );
}

// ── Empty state ────────────────────────────────────────────────────────────────
function EmptyNotifications({ group }: { group: string }) {
  const { colors } = useTheme();
  return (
    <View style={{ alignItems: "center", paddingVertical: 64, gap: 14, paddingHorizontal: 32 }}>
      <View
        style={{
          width: 80, height: 80, borderRadius: 40,
          backgroundColor: colors.card,
          borderWidth: 2, borderColor: colors.border, borderStyle: "dashed",
          alignItems: "center", justifyContent: "center",
        }}
      >
        <Ionicons name="notifications-off-outline" size={36} color={colors.textMuted} />
      </View>
      <Text style={{ fontSize: 17, fontWeight: "800", color: colors.text, textAlign: "center" }}>
        {group === "all" ? "You're all caught up!" : `No ${group} notifications`}
      </Text>
      <Text style={{ fontSize: 14, color: colors.textMuted, textAlign: "center", lineHeight: 21 }}>
        {group === "all"
          ? "New notifications will appear here when someone interacts with you."
          : `When you receive ${group} notifications they'll show up here.`}
      </Text>
    </View>
  );
}

// ── Preferences panel ──────────────────────────────────────────────────────────
function PreferencesPanel() {
  const { colors } = useTheme();
  const prefs      = useNotificationStore((s) => s.preferences);
  const updatePref = useNotificationStore((s) => s.updatePreference);

  type IoniconsName = React.ComponentProps<typeof Ionicons>["name"];

  const SECTIONS: {
    title: string;
    items: { key: keyof typeof prefs; label: string; subtitle?: string; icon: IoniconsName }[];
  }[] = [
    {
      title: "Activity",
      items: [
        { key: "follows",      label: "Follows",       subtitle: "When someone follows you",          icon: "person-add-outline" },
        { key: "likes",        label: "Likes",         subtitle: "Likes on your posts and profile",   icon: "heart-outline" },
        { key: "comments",     label: "Comments",      subtitle: "Comments and mentions",             icon: "chatbubble-outline" },
        { key: "profileViews", label: "Profile views", subtitle: "When someone views your profile",   icon: "eye-outline" },
      ],
    },
    {
      title: "Dating",
      items: [
        { key: "messages", label: "Messages", subtitle: "New direct messages",  icon: "mail-outline" },
        { key: "matches",  label: "Matches",  subtitle: "New mutual matches",   icon: "flame-outline" },
      ],
    },
    {
      title: "Communities",
      items: [
        { key: "communityPosts", label: "New posts",     subtitle: "Posts in communities you've joined", icon: "newspaper-outline" },
        { key: "joinRequests",   label: "Join requests", subtitle: "Requests to join your communities",  icon: "notifications-outline" },
      ],
    },
    {
      title: "Other",
      items: [
        { key: "systemUpdates", label: "System updates", subtitle: "Product news and announcements", icon: "megaphone-outline" },
        { key: "emailDigest",   label: "Email digest",   subtitle: "Weekly summary via email",       icon: "mail-open-outline" },
      ],
    },
  ];

  return (
    <ScrollView showsVerticalScrollIndicator={false} contentContainerStyle={{ paddingBottom: 48 }}>
      {/* Push toggle */}
      <View style={{ margin: 16, borderRadius: 18, overflow: "hidden", borderWidth: 1, borderColor: colors.border }}>
        <LinearGradient
          colors={prefs.pushEnabled ? [colors.primary + "18", colors.accent + "0a"] : [colors.card, colors.background]}
          start={{ x: 0, y: 0 }} end={{ x: 1, y: 1 }}
          style={{ padding: 16, gap: 12 }}
        >
          <View style={{ flexDirection: "row", alignItems: "center", justifyContent: "space-between" }}>
            <View style={{ flexDirection: "row", alignItems: "center", gap: 12 }}>
              <View
                style={{
                  width: 44, height: 44, borderRadius: 14,
                  backgroundColor: prefs.pushEnabled ? colors.primary + "22" : colors.card,
                  alignItems: "center", justifyContent: "center",
                  borderWidth: 1, borderColor: prefs.pushEnabled ? colors.primary + "44" : colors.border,
                }}
              >
                <Ionicons name="notifications-outline" size={22} color={prefs.pushEnabled ? colors.primary : colors.textMuted} />
              </View>
              <View>
                <Text style={{ fontSize: 15, fontWeight: "800", color: colors.text }}>Push notifications</Text>
                <Text style={{ fontSize: 12, color: colors.textMuted, marginTop: 2 }}>
                  {prefs.pushEnabled ? "Enabled — you'll get notified" : "Disabled — turn on to stay updated"}
                </Text>
              </View>
            </View>
            <Switch
              value={prefs.pushEnabled}
              onValueChange={(v) => updatePref("pushEnabled", v)}
              trackColor={{ false: colors.border, true: colors.primary }}
              thumbColor="#fff"
            />
          </View>
        </LinearGradient>
      </View>

      {/* Quiet hours */}
      <View style={{ marginHorizontal: 16, marginBottom: 16, borderRadius: 18, backgroundColor: colors.surface, borderWidth: 1, borderColor: colors.border, overflow: "hidden" }}>
        <View style={{ padding: 16, borderBottomWidth: prefs.quietHoursEnabled ? 1 : 0, borderBottomColor: colors.border }}>
          <View style={{ flexDirection: "row", alignItems: "center", justifyContent: "space-between" }}>
            <View style={{ flexDirection: "row", alignItems: "center", gap: 12 }}>
              <View style={{ width: 44, height: 44, borderRadius: 14, backgroundColor: colors.card, alignItems: "center", justifyContent: "center", borderWidth: 1, borderColor: colors.border }}>
                <Ionicons name="moon-outline" size={22} color={colors.violet} />
              </View>
              <View>
                <Text style={{ fontSize: 15, fontWeight: "700", color: colors.text }}>Quiet hours</Text>
                <Text style={{ fontSize: 12, color: colors.textMuted, marginTop: 2 }}>
                  {prefs.quietHoursEnabled ? `${prefs.quietHoursStart} – ${prefs.quietHoursEnd}` : "Pause notifications at night"}
                </Text>
              </View>
            </View>
            <Switch
              value={prefs.quietHoursEnabled}
              onValueChange={(v) => updatePref("quietHoursEnabled", v)}
              trackColor={{ false: colors.border, true: colors.violet }}
              thumbColor="#fff"
            />
          </View>
        </View>
        {prefs.quietHoursEnabled && (
          <View style={{ flexDirection: "row", padding: 14, gap: 10 }}>
            {(["quietHoursStart", "quietHoursEnd"] as const).map((key, i) => (
              <View key={key} style={{ flex: 1, backgroundColor: colors.card, borderRadius: 12, padding: 12, alignItems: "center", gap: 3, borderWidth: 1, borderColor: colors.border }}>
                <Text style={{ fontSize: 11, color: colors.textMuted, fontWeight: "600" }}>{i === 0 ? "FROM" : "TO"}</Text>
                <Text style={{ fontSize: 18, fontWeight: "800", color: colors.text }}>{prefs[key]}</Text>
              </View>
            ))}
          </View>
        )}
      </View>

      {/* Preference sections */}
      {SECTIONS.map((section) => (
        <View key={section.title} style={{ marginHorizontal: 16, marginBottom: 16, borderRadius: 18, backgroundColor: colors.surface, borderWidth: 1, borderColor: colors.border, overflow: "hidden" }}>
          <View style={{ paddingHorizontal: 16, paddingTop: 14, paddingBottom: 8 }}>
            <Text style={{ fontSize: 12, fontWeight: "800", color: colors.textMuted, letterSpacing: 0.6 }}>{section.title.toUpperCase()}</Text>
          </View>
          {section.items.map((item, idx) => (
            <View
              key={item.key}
              style={{ flexDirection: "row", alignItems: "center", paddingHorizontal: 16, paddingVertical: 12, borderTopWidth: idx > 0 ? 1 : 0, borderTopColor: colors.border, gap: 12 }}
            >
              <View style={{ width: 36, height: 36, borderRadius: 10, backgroundColor: colors.card, alignItems: "center", justifyContent: "center", borderWidth: 1, borderColor: colors.border }}>
                <Ionicons name={item.icon} size={18} color={colors.textSecondary} />
              </View>
              <View style={{ flex: 1, gap: 2 }}>
                <Text style={{ fontSize: 14, fontWeight: "700", color: colors.text }}>{item.label}</Text>
                {item.subtitle && <Text style={{ fontSize: 12, color: colors.textMuted }}>{item.subtitle}</Text>}
              </View>
              <Switch
                value={Boolean(prefs[item.key])}
                onValueChange={(v) => updatePref(item.key, v)}
                trackColor={{ false: colors.border, true: colors.primary }}
                thumbColor="#fff"
              />
            </View>
          ))}
        </View>
      ))}
    </ScrollView>
  );
}

// ── Main NotificationCenter ────────────────────────────────────────────────────
export function NotificationCenter() {
  const insets          = useSafeAreaInsets();
  const { colors }      = useTheme();
  const visible         = useNotificationStore((s) => s.panelVisible);
  const setPanelVisible = useNotificationStore((s) => s.setPanelVisible);
  const activeGroup     = useNotificationStore((s) => s.activeGroup);
  const setActiveGroup  = useNotificationStore((s) => s.setActiveGroup);
  const markAllRead     = useNotificationStore((s) => s.markAllRead);
  const markGroupRead   = useNotificationStore((s) => s.markGroupRead);
  const clearAll        = useNotificationStore((s) => s.clearAll);

  const filteredNotifs = useFilteredNotifications();
  const groupCounts    = useGroupUnreadCounts();
  const totalUnread    = useTotalUnread();
  const [innerTab, setInnerTab] = useState<"notifications" | "preferences">("notifications");

  const sections = useMemo(() => groupByDate(filteredNotifs), [filteredNotifs]);

  return (
    <Modal
      visible={visible}
      animationType="slide"
      presentationStyle="pageSheet"
      onRequestClose={() => setPanelVisible(false)}
    >
      <View style={{ flex: 1, backgroundColor: colors.background }}>
        {/* Header */}
        <View style={{ backgroundColor: colors.surface, paddingTop: insets.top + 12, borderBottomWidth: 1, borderBottomColor: colors.border }}>
          {/* Title row */}
          <View style={{ flexDirection: "row", alignItems: "center", justifyContent: "space-between", paddingHorizontal: 20, paddingBottom: 12 }}>
            <View>
              <Text style={{ fontSize: 22, fontWeight: "900", color: colors.text, letterSpacing: -0.5 }}>
                Notifications
              </Text>
              {totalUnread > 0 && (
                <Text style={{ fontSize: 12, color: colors.primary, fontWeight: "700", marginTop: 2 }}>
                  {totalUnread} unread
                </Text>
              )}
            </View>
            <View style={{ flexDirection: "row", alignItems: "center", gap: 8 }}>
              {totalUnread > 0 && (
                <Pressable
                  onPress={() => markAllRead()}
                  style={({ pressed }) => ({
                    paddingHorizontal: 12, paddingVertical: 7, borderRadius: 12,
                    backgroundColor: colors.card, borderWidth: 1, borderColor: colors.border,
                    opacity: pressed ? 0.7 : 1,
                  })}
                >
                  <Text style={{ fontSize: 12, color: colors.primary, fontWeight: "700" }}>Mark all read</Text>
                </Pressable>
              )}
              <Pressable
                onPress={() => setPanelVisible(false)}
                style={({ pressed }) => ({
                  width: 34, height: 34, borderRadius: 10,
                  backgroundColor: colors.card, borderWidth: 1, borderColor: colors.border,
                  alignItems: "center", justifyContent: "center",
                  opacity: pressed ? 0.6 : 1,
                })}
              >
                <Ionicons name="close" size={18} color={colors.text} />
              </Pressable>
            </View>
          </View>

          {/* Inner tabs */}
          <View style={{ flexDirection: "row", paddingHorizontal: 20, paddingBottom: 12, gap: 8 }}>
            {(["notifications", "preferences"] as const).map((t) => {
              const isActive = innerTab === t;
              return (
                <Pressable key={t} onPress={() => setInnerTab(t)}>
                  {isActive ? (
                    <LinearGradient
                      colors={[colors.primary, colors.accent]}
                      start={{ x: 0, y: 0 }} end={{ x: 1, y: 0 }}
                      style={{ paddingHorizontal: 16, paddingVertical: 8, borderRadius: 18 }}
                    >
                      <Text style={{ color: "#fff", fontSize: 13, fontWeight: "800" }}>
                        {t === "notifications" ? "🔔 Notifications" : "⚙ Preferences"}
                      </Text>
                    </LinearGradient>
                  ) : (
                    <View style={{ paddingHorizontal: 16, paddingVertical: 8, borderRadius: 18, backgroundColor: colors.card, borderWidth: 1, borderColor: colors.border }}>
                      <Text style={{ color: colors.textMuted, fontSize: 13, fontWeight: "600" }}>
                        {t === "notifications" ? "🔔 Notifications" : "⚙ Preferences"}
                      </Text>
                    </View>
                  )}
                </Pressable>
              );
            })}
          </View>

          {/* Group filter pills */}
          {innerTab === "notifications" && (
            <ScrollView
              horizontal
              showsHorizontalScrollIndicator={false}
              contentContainerStyle={{ paddingHorizontal: 20, paddingBottom: 12, gap: 8 }}
            >
              {GROUPS.map((group) => (
                <GroupPill
                  key={group}
                  group={group}
                  active={activeGroup === group}
                  unread={groupCounts[group]}
                  onPress={() => setActiveGroup(group)}
                />
              ))}
            </ScrollView>
          )}
        </View>

        {/* Content */}
        {innerTab === "preferences" ? (
          <PreferencesPanel />
        ) : (
          <>
            {sections.length === 0 ? (
              <EmptyNotifications group={activeGroup} />
            ) : (
              <SectionList
                sections={sections.map((s) => ({ title: s.label, data: s.items }))}
                keyExtractor={(item) => item.id}
                renderItem={({ item }) => <NotificationRow notif={item} />}
                renderSectionHeader={({ section }) => <SectionHeader title={section.title} />}
                showsVerticalScrollIndicator={false}
                contentContainerStyle={{ paddingBottom: insets.bottom + 32 }}
                stickySectionHeadersEnabled
                ListFooterComponent={
                  filteredNotifs.length > 0 ? (
                    <View style={{ padding: 20, alignItems: "center", gap: 12 }}>
                      <Pressable
                        onPress={() => markGroupRead(activeGroup)}
                        style={({ pressed }) => ({
                          paddingHorizontal: 20, paddingVertical: 10, borderRadius: 14,
                          backgroundColor: colors.card, borderWidth: 1, borderColor: colors.border,
                          opacity: pressed ? 0.7 : 1,
                        })}
                      >
                        <Text style={{ fontSize: 13, color: colors.textSecondary, fontWeight: "700" }}>
                          Mark {activeGroup === "all" ? "all" : activeGroup} as read
                        </Text>
                      </Pressable>
                      <Pressable onPress={clearAll} style={({ pressed }) => ({ opacity: pressed ? 0.7 : 1 })}>
                        <Text style={{ fontSize: 12, color: colors.textMuted }}>Clear all notifications</Text>
                      </Pressable>
                    </View>
                  ) : null
                }
              />
            )}
          </>
        )}
      </View>
    </Modal>
  );
}

// ── Bell button ────────────────────────────────────────────────────────────────
export function NotificationBell() {
  const { colors }      = useTheme();
  const setPanelVisible = useNotificationStore((s) => s.setPanelVisible);
  const totalUnread     = useTotalUnread();

  return (
    <Pressable
      onPress={() => setPanelVisible(true)}
      hitSlop={8}
      style={({ pressed }) => ({
        opacity: pressed ? 0.6 : 1,
        width: 34,
        height: 34,
        borderRadius: 10,
        backgroundColor: colors.card,
        alignItems: "center",
        justifyContent: "center",
        borderWidth: 1,
        borderColor: colors.border,
        position: "relative",
      })}
    >
      <Ionicons name="notifications-outline" size={18} color={colors.text} />
      {totalUnread > 0 && (
        <View
          style={{
            position: "absolute",
            top: -3,
            right: -3,
            minWidth: 16,
            height: 16,
            borderRadius: 8,
            backgroundColor: colors.primary,
            borderWidth: 1.5,
            borderColor: colors.surface,
            alignItems: "center",
            justifyContent: "center",
            paddingHorizontal: 3,
          }}
        >
          <Text style={{ color: "#fff", fontSize: 9, fontWeight: "800", lineHeight: 13 }}>
            {totalUnread > 99 ? "99+" : totalUnread}
          </Text>
        </View>
      )}
    </Pressable>
  );
}
