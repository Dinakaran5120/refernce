import { useState } from "react";
import {
  View, Text, TextInput, Pressable, Modal, ScrollView,
  KeyboardAvoidingView, Platform,
} from "react-native";
import { LinearGradient } from "expo-linear-gradient";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import { Colors } from "@constants/theme";
import { useExploreStore } from "@/store/exploreStore";
import type { PostType } from "@/types/explore";

const MOOD_OPTIONS = [
  { label: "Healing",     emoji: "🌸", gradient: [Colors.secondary, Colors.rose]   as [string, string] },
  { label: "Excited",     emoji: "🔥", gradient: [Colors.primary, Colors.accent]   as [string, string] },
  { label: "Vulnerable",  emoji: "🌙", gradient: [Colors.violet, Colors.sky]       as [string, string] },
  { label: "Grateful",    emoji: "✨", gradient: [Colors.gold, Colors.accent]      as [string, string] },
  { label: "Questioning", emoji: "🌧️", gradient: [Colors.sky, Colors.violet]      as [string, string] },
  { label: "Joyful",      emoji: "🌈", gradient: [Colors.rose, Colors.violet]      as [string, string] },
  { label: "Peaceful",    emoji: "🕊️", gradient: [Colors.mint, Colors.sky]        as [string, string] },
  { label: "Heartbroken", emoji: "💔", gradient: [Colors.primary, Colors.violet]   as [string, string] },
];

const POST_TYPES: { type: PostType; label: string; emoji: string }[] = [
  { type: "thought", label: "Thought",   emoji: "💭" },
  { type: "mood",    label: "Mood",      emoji: "🌈" },
  { type: "text",    label: "Text post", emoji: "✍️" },
];

// ── Inline prompt card shown in feed ─────────────────────────────────────────
export function ShareMoodCard() {
  const setShowCreate = useExploreStore((s) => s.setShowCreatePost);

  return (
    <View
      style={{
        backgroundColor: Colors.surface,
        borderRadius: 20,
        padding: 16,
        marginBottom: 12,
        borderWidth: 1,
        borderColor: Colors.border,
        shadowColor: "#000",
        shadowOffset: { width: 0, height: 2 },
        shadowOpacity: 0.04,
        shadowRadius: 6,
        elevation: 1,
        gap: 12,
      }}
    >
      {/* Avatar + prompt input row */}
      <Pressable onPress={() => setShowCreate(true)}>
        <View style={{ flexDirection: "row", alignItems: "center", gap: 12 }}>
          <LinearGradient
            colors={[Colors.primary, Colors.accent]}
            start={{ x: 0, y: 0 }} end={{ x: 1, y: 1 }}
            style={{ width: 42, height: 42, borderRadius: 21, alignItems: "center", justifyContent: "center" }}
          >
            <Text style={{ fontSize: 20 }}>😊</Text>
          </LinearGradient>
          <View
            style={{
              flex: 1, height: 44, backgroundColor: Colors.card,
              borderRadius: 22, justifyContent: "center",
              paddingHorizontal: 16,
              borderWidth: 1, borderColor: Colors.border,
            }}
          >
            <Text style={{ color: Colors.textMuted, fontSize: 14 }}>
              What's on your mind?
            </Text>
          </View>
        </View>
      </Pressable>

      {/* Quick action buttons */}
      <View style={{ flexDirection: "row", gap: 8 }}>
        {POST_TYPES.map(({ type, label, emoji }) => (
          <Pressable
            key={type}
            onPress={() => setShowCreate(true)}
            style={({ pressed }) => ({
              flex: 1, flexDirection: "row", alignItems: "center",
              justifyContent: "center", gap: 5,
              paddingVertical: 9, borderRadius: 14,
              backgroundColor: Colors.card,
              borderWidth: 1, borderColor: Colors.border,
              opacity: pressed ? 0.7 : 1,
            })}
          >
            <Text style={{ fontSize: 14 }}>{emoji}</Text>
            <Text style={{ fontSize: 12, color: Colors.textSecondary, fontWeight: "600" }}>
              {label}
            </Text>
          </Pressable>
        ))}
      </View>
    </View>
  );
}

// ── Full create-post modal ─────────────────────────────────────────────────────
export function CreatePostModal() {
  const insets        = useSafeAreaInsets();
  const addPost       = useExploreStore((s) => s.addPost);
  const showCreate    = useExploreStore((s) => s.showCreatePost);
  const setShowCreate = useExploreStore((s) => s.setShowCreatePost);

  const [postType, setPostType]     = useState<PostType>("thought");
  const [caption, setCaption]       = useState("");
  const [selectedMood, setMood]     = useState(MOOD_OPTIONS[0]);
  const [isAnonymous, setAnon]      = useState(false);
  const [tags, setTagsText]         = useState("");

  const handlePost = () => {
    if (!caption.trim()) return;

    addPost({
      type: postType,
      author: {
        id: "me",
        name: isAnonymous ? "Anon" : "You",
        avatarEmoji: isAnonymous ? "👤" : "😊",
        gradient: isAnonymous
          ? [Colors.muted, Colors.textSecondary]
          : ([Colors.primary, Colors.accent] as [string, string]),
        verified: false,
        isAnonymous,
      },
      caption: caption.trim(),
      tags: tags.trim()
        ? tags.trim().split(/\s+/).filter((t) => t.startsWith("#"))
        : [],
      mood: postType === "mood" ? selectedMood.label : undefined,
      moodColor: postType === "mood" ? Colors.primary : undefined,
      moodGradient: postType === "mood" ? selectedMood.gradient : undefined,
      isPublic: true,
      isTrending: false,
    });

    setCaption("");
    setTagsText("");
    setShowCreate(false);
  };

  return (
    <Modal
      visible={showCreate}
      animationType="slide"
      presentationStyle="pageSheet"
      onRequestClose={() => setShowCreate(false)}
    >
      <KeyboardAvoidingView
        style={{ flex: 1, backgroundColor: Colors.background }}
        behavior={Platform.OS === "ios" ? "padding" : "height"}
      >
        {/* Header */}
        <View
          style={{
            flexDirection: "row", alignItems: "center", justifyContent: "space-between",
            paddingHorizontal: 20, paddingVertical: 16,
            paddingTop: insets.top + 16,
            borderBottomWidth: 1, borderBottomColor: Colors.border,
            backgroundColor: Colors.surface,
          }}
        >
          <Pressable onPress={() => setShowCreate(false)}>
            <Text style={{ fontSize: 15, color: Colors.textSecondary, fontWeight: "600" }}>Cancel</Text>
          </Pressable>
          <Text style={{ fontSize: 16, fontWeight: "800", color: Colors.text }}>New Post</Text>
          <Pressable
            onPress={handlePost}
            disabled={!caption.trim()}
            style={({ pressed }) => ({ opacity: caption.trim() ? (pressed ? 0.7 : 1) : 0.4 })}
          >
            <LinearGradient
              colors={[Colors.primary, Colors.accent]}
              start={{ x: 0, y: 0 }} end={{ x: 1, y: 0 }}
              style={{ paddingHorizontal: 18, paddingVertical: 8, borderRadius: 14 }}
            >
              <Text style={{ color: "#fff", fontWeight: "800", fontSize: 14 }}>Post</Text>
            </LinearGradient>
          </Pressable>
        </View>

        <ScrollView
          contentContainerStyle={{ padding: 20, gap: 20 }}
          keyboardShouldPersistTaps="handled"
          showsVerticalScrollIndicator={false}
        >
          {/* Post type selector */}
          <View style={{ flexDirection: "row", gap: 10 }}>
            {POST_TYPES.map(({ type, label, emoji }) => {
              const isActive = postType === type;
              return (
                <Pressable
                  key={type}
                  onPress={() => setPostType(type)}
                  style={{ flex: 1 }}
                >
                  {isActive ? (
                    <LinearGradient
                      colors={[Colors.primary, Colors.accent]}
                      start={{ x: 0, y: 0 }} end={{ x: 1, y: 1 }}
                      style={{ borderRadius: 16, padding: 12, alignItems: "center", gap: 4 }}
                    >
                      <Text style={{ fontSize: 22 }}>{emoji}</Text>
                      <Text style={{ color: "#fff", fontSize: 12, fontWeight: "700" }}>{label}</Text>
                    </LinearGradient>
                  ) : (
                    <View style={{ borderRadius: 16, padding: 12, alignItems: "center", gap: 4, backgroundColor: Colors.card, borderWidth: 1, borderColor: Colors.border }}>
                      <Text style={{ fontSize: 22 }}>{emoji}</Text>
                      <Text style={{ color: Colors.textMuted, fontSize: 12, fontWeight: "600" }}>{label}</Text>
                    </View>
                  )}
                </Pressable>
              );
            })}
          </View>

          {/* Mood selector (mood posts only) */}
          {postType === "mood" && (
            <View style={{ gap: 10 }}>
              <Text style={{ fontSize: 13, fontWeight: "700", color: Colors.textSecondary, letterSpacing: 0.3 }}>
                SELECT MOOD
              </Text>
              <View style={{ flexDirection: "row", flexWrap: "wrap", gap: 8 }}>
                {MOOD_OPTIONS.map((m) => {
                  const isSelected = selectedMood.label === m.label;
                  return (
                    <Pressable key={m.label} onPress={() => setMood(m)}>
                      {isSelected ? (
                        <LinearGradient
                          colors={m.gradient}
                          start={{ x: 0, y: 0 }} end={{ x: 1, y: 0 }}
                          style={{ paddingHorizontal: 14, paddingVertical: 8, borderRadius: 20, flexDirection: "row", alignItems: "center", gap: 6 }}
                        >
                          <Text style={{ fontSize: 14 }}>{m.emoji}</Text>
                          <Text style={{ color: "#fff", fontSize: 13, fontWeight: "700" }}>{m.label}</Text>
                        </LinearGradient>
                      ) : (
                        <View style={{ paddingHorizontal: 14, paddingVertical: 8, borderRadius: 20, borderWidth: 1.5, borderColor: Colors.border, backgroundColor: Colors.card, flexDirection: "row", alignItems: "center", gap: 6 }}>
                          <Text style={{ fontSize: 14 }}>{m.emoji}</Text>
                          <Text style={{ color: Colors.textSecondary, fontSize: 13, fontWeight: "600" }}>{m.label}</Text>
                        </View>
                      )}
                    </Pressable>
                  );
                })}
              </View>
            </View>
          )}

          {/* Live preview for mood */}
          {postType === "mood" && caption.trim() && (
            <LinearGradient
              colors={selectedMood.gradient}
              start={{ x: 0, y: 0 }} end={{ x: 1, y: 1 }}
              style={{ borderRadius: 18, padding: 20, gap: 8 }}
            >
              <View style={{ alignSelf: "flex-start", backgroundColor: "rgba(255,255,255,0.25)", paddingHorizontal: 12, paddingVertical: 4, borderRadius: 12 }}>
                <Text style={{ color: "#fff", fontSize: 11, fontWeight: "800", letterSpacing: 0.5 }}>
                  {selectedMood.label.toUpperCase()}
                </Text>
              </View>
              <Text style={{ color: "#fff", fontSize: 16, lineHeight: 24, fontWeight: "600" }}>
                {caption}
              </Text>
              {isAnonymous && (
                <Text style={{ color: "rgba(255,255,255,0.7)", fontSize: 12 }}>— shared anonymously</Text>
              )}
            </LinearGradient>
          )}

          {/* Live preview for thought */}
          {postType === "thought" && caption.trim() && (
            <LinearGradient
              colors={[Colors.card, Colors.background]}
              start={{ x: 0, y: 0 }} end={{ x: 1, y: 1 }}
              style={{ borderRadius: 16, padding: 18, borderWidth: 1, borderColor: Colors.border, borderLeftWidth: 4, borderLeftColor: Colors.primary }}
            >
              <Text style={{ fontSize: 16, color: Colors.text, lineHeight: 24, fontWeight: "500", fontStyle: "italic" }}>
                "{caption}"
              </Text>
            </LinearGradient>
          )}

          {/* Caption input */}
          <View style={{ gap: 8 }}>
            <Text style={{ fontSize: 13, fontWeight: "700", color: Colors.textSecondary, letterSpacing: 0.3 }}>
              {postType === "thought" ? "YOUR THOUGHT" : postType === "mood" ? "WHAT DO YOU WANT TO SAY?" : "CAPTION"}
            </Text>
            <TextInput
              value={caption}
              onChangeText={setCaption}
              placeholder={
                postType === "mood"
                  ? "Share what you're feeling right now…"
                  : postType === "thought"
                  ? "Share a thought, hot take, or something on your mind…"
                  : "Write something…"
              }
              placeholderTextColor={Colors.textMuted}
              multiline
              numberOfLines={5}
              maxLength={500}
              style={{
                backgroundColor: Colors.surface,
                borderRadius: 16, borderWidth: 1, borderColor: Colors.border,
                padding: 14, fontSize: 15, color: Colors.text,
                lineHeight: 23, minHeight: 120, textAlignVertical: "top",
              }}
            />
            <Text style={{ fontSize: 11, color: Colors.textMuted, textAlign: "right" }}>
              {caption.length}/500
            </Text>
          </View>

          {/* Tags input */}
          <View style={{ gap: 8 }}>
            <Text style={{ fontSize: 13, fontWeight: "700", color: Colors.textSecondary, letterSpacing: 0.3 }}>
              TAGS (optional)
            </Text>
            <TextInput
              value={tags}
              onChangeText={setTagsText}
              placeholder="#LateNightThoughts #Mumbai #Feelings"
              placeholderTextColor={Colors.textMuted}
              autoCapitalize="none"
              style={{
                backgroundColor: Colors.surface,
                borderRadius: 16, borderWidth: 1, borderColor: Colors.border,
                paddingHorizontal: 14, paddingVertical: 12,
                fontSize: 14, color: Colors.text,
              }}
            />
          </View>

          {/* Anonymous toggle */}
          <Pressable
            onPress={() => setAnon(!isAnonymous)}
            style={({ pressed }) => ({
              flexDirection: "row", alignItems: "center", justifyContent: "space-between",
              padding: 16, borderRadius: 16,
              backgroundColor: isAnonymous ? Colors.violet + "14" : Colors.card,
              borderWidth: 1.5, borderColor: isAnonymous ? Colors.violet : Colors.border,
              opacity: pressed ? 0.8 : 1,
            })}
          >
            <View style={{ flexDirection: "row", alignItems: "center", gap: 12 }}>
              <View style={{
                width: 40, height: 40, borderRadius: 12,
                backgroundColor: isAnonymous ? Colors.violet + "22" : Colors.surface,
                alignItems: "center", justifyContent: "center",
                borderWidth: 1, borderColor: isAnonymous ? Colors.violet + "44" : Colors.border,
              }}>
                <Text style={{ fontSize: 18 }}>👤</Text>
              </View>
              <View>
                <Text style={{ fontSize: 14, fontWeight: "700", color: Colors.text }}>Post anonymously</Text>
                <Text style={{ fontSize: 12, color: Colors.textMuted, marginTop: 2 }}>
                  Your name won't be shown
                </Text>
              </View>
            </View>
            <View
              style={{
                width: 48, height: 28, borderRadius: 14,
                backgroundColor: isAnonymous ? Colors.violet : Colors.border,
                justifyContent: "center", paddingHorizontal: 3,
              }}
            >
              <View
                style={{
                  width: 22, height: 22, borderRadius: 11, backgroundColor: "#fff",
                  transform: [{ translateX: isAnonymous ? 20 : 0 }],
                  shadowColor: "#000", shadowOffset: { width: 0, height: 1 },
                  shadowOpacity: 0.15, shadowRadius: 3, elevation: 2,
                }}
              />
            </View>
          </Pressable>
        </ScrollView>
      </KeyboardAvoidingView>
    </Modal>
  );
}
