import { useRef, useCallback } from "react";
import {
  View,
  Text,
  ScrollView,
  Pressable,
  Animated,
} from "react-native";
import { LinearGradient } from "expo-linear-gradient";
import { Colors } from "@constants/theme";
import { useDiscoverStore } from "@/store/discoverStore";
import { useDiscoverFilters, useActiveFilterCount } from "@/hooks/useDiscoverFilters";
import { DiscoverCard } from "@components/discover/DiscoverCard";
import { FilterSheet } from "@components/discover/FilterSheet";
import { SpotlightBanner } from "@components/discover/SpotlightBanner";
import { EmptyDiscover } from "@components/discover/EmptyDiscover";

const INTENT_TABS = ["All", "Dating", "Friends", "Hookup", "LGBTQ+"];

// ── Animated press hook ────────────────────────────────────────────────────────
function useSpringPress() {
  const scale = useRef(new Animated.Value(1)).current;

  const onPressIn = useCallback(() => {
    Animated.spring(scale, {
      toValue: 0.92,
      useNativeDriver: true,
      speed: 50,
      bounciness: 6,
    }).start();
  }, [scale]);

  const onPressOut = useCallback(() => {
    Animated.spring(scale, {
      toValue: 1,
      useNativeDriver: true,
      speed: 30,
      bounciness: 10,
    }).start();
  }, [scale]);

  return { scale, onPressIn, onPressOut };
}

// ── Animated Intent Tab ────────────────────────────────────────────────────────
function IntentTab({ tab, isActive, onPress }: { tab: string; isActive: boolean; onPress: () => void }) {
  const { scale, onPressIn, onPressOut } = useSpringPress();

  return (
    <Animated.View style={{ transform: [{ scale }] }}>
      <Pressable
        onPress={onPress}
        onPressIn={onPressIn}
        onPressOut={onPressOut}
      >
        {isActive ? (
          <LinearGradient
            colors={tab === "LGBTQ+" ? [Colors.violet, Colors.rose] : [Colors.primary, Colors.accent]}
            start={{ x: 0, y: 0 }}
            end={{ x: 1, y: 1 }}
            style={{
              paddingHorizontal: 18,
              paddingVertical: 9,
              borderRadius: 22,
              shadowColor: tab === "LGBTQ+" ? Colors.violet : Colors.primary,
              shadowOffset: { width: 0, height: 3 },
              shadowOpacity: 0.35,
              shadowRadius: 8,
              elevation: 4,
            }}
          >
            <Text style={{ color: "#fff", fontSize: 13, fontWeight: "700", letterSpacing: 0.2 }}>
              {tab}
            </Text>
          </LinearGradient>
        ) : (
          <View
            style={{
              paddingHorizontal: 18,
              paddingVertical: 9,
              borderRadius: 22,
              backgroundColor: Colors.card,
              borderWidth: 1.5,
              borderColor: Colors.border,
            }}
          >
            <Text style={{ color: Colors.textSecondary, fontSize: 13, fontWeight: "600", letterSpacing: 0.2 }}>
              {tab}
            </Text>
          </View>
        )}
      </Pressable>
    </Animated.View>
  );
}

// ── Intent tab bar ─────────────────────────────────────────────────────────────
function IntentTabBar() {
  const active    = useDiscoverStore((s) => s.activeIntentFilter);
  const setActive = useDiscoverStore((s) => s.setActiveIntentFilter);

  return (
    <ScrollView
      horizontal
      showsHorizontalScrollIndicator={false}
      contentContainerStyle={{ paddingHorizontal: 16, paddingVertical: 10, gap: 8 }}
    >
      {INTENT_TABS.map((tab) => (
        <IntentTab
          key={tab}
          tab={tab}
          isActive={active === tab}
          onPress={() => setActive(tab)}
        />
      ))}
    </ScrollView>
  );
}

// ── Animated Toggle Button ─────────────────────────────────────────────────────
function AnimatedToggleBtn({
  onPress,
  isActive,
  activeColor,
  children,
}: {
  onPress: () => void;
  isActive: boolean;
  activeColor: string;
  children: React.ReactNode;
}) {
  const { scale, onPressIn, onPressOut } = useSpringPress();

  return (
    <Animated.View style={{ transform: [{ scale }] }}>
      <Pressable
        onPress={onPress}
        onPressIn={onPressIn}
        onPressOut={onPressOut}
        style={{
          flexDirection: "row",
          alignItems: "center",
          gap: 5,
          paddingHorizontal: 12,
          paddingVertical: 8,
          borderRadius: 14,
          backgroundColor: isActive ? activeColor + "22" : Colors.card,
          borderWidth: 1.5,
          borderColor: isActive ? activeColor : Colors.border,
        }}
      >
        {children}
      </Pressable>
    </Animated.View>
  );
}

// ── Animated Filter Button ─────────────────────────────────────────────────────
function AnimatedFilterBtn({
  onPress,
  isActive,
  children,
}: {
  onPress: () => void;
  isActive: boolean;
  children: React.ReactNode;
}) {
  const { scale, onPressIn, onPressOut } = useSpringPress();

  return (
    <Animated.View style={{ transform: [{ scale }] }}>
      <Pressable
        onPress={onPress}
        onPressIn={onPressIn}
        onPressOut={onPressOut}
        style={{
          flexDirection: "row",
          alignItems: "center",
          gap: 6,
          paddingHorizontal: 14,
          paddingVertical: 8,
          borderRadius: 14,
          backgroundColor: isActive ? Colors.primary + "18" : Colors.card,
          borderWidth: 1.5,
          borderColor: isActive ? Colors.primary : Colors.border,
        }}
      >
        {children}
      </Pressable>
    </Animated.View>
  );
}

// ── Sub-header: count + quick toggles + filter btn ───────────────────────────
function DiscoverHeader() {
  const setShowSheet  = useDiscoverStore((s) => s.setShowFilterSheet);
  const activeCount   = useActiveFilterCount();
  const filteredUsers = useDiscoverFilters();
  const filters       = useDiscoverStore((s) => s.filters);
  const setFilters    = useDiscoverStore((s) => s.setFilters);
  const onlineOnly    = filters.onlineOnly;
  const favOnly       = filters.favouritesOnly;

  return (
    <View
      style={{
        flexDirection: "row",
        alignItems: "center",
        paddingHorizontal: 16,
        paddingBottom: 10,
        gap: 8,
        flexWrap: "nowrap",
      }}
    >
      {/* Count label */}
      <View style={{ flex: 1, minWidth: 0 }}>
        <Text
          numberOfLines={1}
          style={{ fontSize: 12, color: Colors.textMuted, fontWeight: "600" }}
        >
          {filteredUsers.length === 0 ? "No matches" : `${filteredUsers.length} nearby`}
        </Text>
      </View>

      {/* Online toggle */}
      <AnimatedToggleBtn
        onPress={() => setFilters({ onlineOnly: !onlineOnly })}
        isActive={onlineOnly}
        activeColor="#16a34a"
      >
        <View
          style={{
            width: 7,
            height: 7,
            borderRadius: 4,
            backgroundColor: onlineOnly ? "#16a34a" : Colors.textMuted,
          }}
        />
        <Text style={{ fontSize: 12, fontWeight: "700", color: onlineOnly ? "#16a34a" : Colors.textMuted }}>
          Online
        </Text>
      </AnimatedToggleBtn>

      {/* Favourites toggle */}
      <AnimatedToggleBtn
        onPress={() => setFilters({ favouritesOnly: !favOnly })}
        isActive={favOnly}
        activeColor={Colors.gold}
      >
        <Text style={{ fontSize: 12 }}>{favOnly ? "⭐" : "☆"}</Text>
        <Text style={{ fontSize: 12, fontWeight: "700", color: favOnly ? Colors.gold : Colors.textMuted }}>
          Saved
        </Text>
      </AnimatedToggleBtn>

      {/* Filter button */}
      <AnimatedFilterBtn
        onPress={() => setShowSheet(true)}
        isActive={activeCount > 0}
      >
        <Text style={{ fontSize: 13 }}>⚙</Text>
        <Text style={{ fontSize: 12, fontWeight: "700", color: activeCount > 0 ? Colors.primary : Colors.textMuted }}>
          {activeCount > 0 ? `Filters (${activeCount})` : "Filters"}
        </Text>
      </AnimatedFilterBtn>
    </View>
  );
}

// ── Main screen ────────────────────────────────────────────────────────────────
export default function DiscoverScreen() {
  const filteredUsers = useDiscoverFilters();

  return (
    <View style={{ flex: 1, backgroundColor: Colors.background }}>
      <IntentTabBar />
      <DiscoverHeader />

      <ScrollView
        contentContainerStyle={{ paddingHorizontal: 16, paddingBottom: 32 }}
        showsVerticalScrollIndicator={false}
      >
        <SpotlightBanner />

        {filteredUsers.length === 0 ? (
          <EmptyDiscover />
        ) : (
          <View style={{ alignItems: "center", gap: 4 }}>
            {filteredUsers.map((user) => (
              <DiscoverCard key={user.id} user={user} />
            ))}
          </View>
        )}
      </ScrollView>

      <FilterSheet />
    </View>
  );
}
