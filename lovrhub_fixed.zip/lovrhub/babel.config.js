module.exports = function (api) {
  api.cache(true);
  return {
    presets: [
      ["babel-preset-expo", { jsxImportSource: "nativewind" }],
      "nativewind/babel",
    ],
    plugins: [
      // NOTE: react-native-reanimated/plugin must be LAST
      [
        "module-resolver",
        {
          root: ["./"],
          alias: {
            "@": "./",
            "@components": "./components",
            "@constants": "./constants",
            "@hooks": "./hooks",
            "@store": "./store",
          },
        },
      ],
      "react-native-reanimated/plugin",
    ],
  };
};
