import { useState, useRef, useEffect } from "react";
import {
  View, Text, Pressable, TextInput,
  FlatList, KeyboardAvoidingView, Platform,
  Modal, Animated, Dimensions,
} from "react-native";
import { LinearGradient } from "expo-linear-gradient";
import { Ionicons } from "@expo/vector-icons";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import { useTheme } from "@/context/ThemeContext";
import { useConnectionsStore } from "@/store/connectionsStore";
import { useConversationMessages } from "@/hooks/useConnections";
import { msgTimeAgo, msgStatusIcon, lastSeenText } from "@/hooks/useConnections";
import { CallScreen } from "@components/connections/CallScreen";
import { ME_ID } from "@/data/mockConversations";
import type { ChatMessage, ReactionEmoji } from "@/types/connections";

const { width: W } = Dimensions.get("window");
const REACTIONS: ReactionEmoji[] = ["❤️", "😂", "🔥", "😮", "👍", "😢"];

// ── Reaction picker popup ──────────────────────────────────────────────────────
function ReactionPicker({
  msgId, convId, onClose,
}: {
  msgId: string; convId: string; onClose: () => void;
}) {
  const { colors } = useTheme();
  const reactToMessage = useConnectionsStore((s) => s.reactToMessage);
  return (
    <Modal transparent animationType="fade" onRequestClose={onClose}>
      <Pressable style={{ flex: 1 }} onPress={onClose}>
        <View
          style={{
            position: "absolute",
            bottom: 120, left: W * 0.1, right: W * 0.1,
            backgroundColor: colors.surface,
            borderRadius: 20, padding: 12,
            flexDirection: "row", justifyContent: "center", gap: 8,
            shadowColor: "#000", shadowOffset: { width: 0, height: 8 },
            shadowOpacity: 0.15, shadowRadius: 20, elevation: 12,
            borderWidth: 1, borderColor: colors.border,
          }}
        >
          {REACTIONS.map((emoji) => (
            <Pressable
              key={emoji}
              onPress={() => { reactToMessage(convId, msgId, emoji); onClose(); }}
              style={({ pressed }) => ({
                width: 44, height: 44, borderRadius: 22,
                backgroundColor: pressed ? colors.card : "transparent",
                alignItems: "center", justifyContent: "center",
                transform: [{ scale: pressed ? 0.88 : 1 }],
              })}
            >
              <Text style={{ fontSize: 26 }}>{emoji}</Text>
            </Pressable>
          ))}
        </View>
      </Pressable>
    </Modal>
  );
}

// ── Message bubble ─────────────────────────────────────────────────────────────
function MessageBubble({
  msg, isMe, showAvatar, participantEmoji, participantGradient, convId,
}: {
  msg: ChatMessage;
  isMe: boolean;
  showAvatar: boolean;
  participantEmoji: string;
  participantGradient: [string, string];
  convId: string;
}) {
  const { colors } = useTheme();
  const [showPicker, setShowPicker] = useState(false);
  const deleteMessage = useConnectionsStore((s) => s.deleteMessage);
  const statusIcon = msgStatusIcon(msg.status);
  const time = msgTimeAgo(msg.createdAt);
  const totalReactions = msg.reactions.reduce((s, r) => s + r.count, 0);

  // System message
  if (msg.type === "system") {
    return (
      <View style={{ alignItems: "center", marginVertical: 8 }}>
        <View style={{ backgroundColor: colors.card, paddingHorizontal: 14, paddingVertical: 5, borderRadius: 12, borderWidth: 1, borderColor: colors.border }}>
          <Text style={{ fontSize: 12, color: colors.textMuted, fontWeight: "600" }}>{msg.text}</Text>
        </View>
      </View>
    );
  }

  return (
    <View
      style={{
        flexDirection: isMe ? "row-reverse" : "row",
        alignItems: "flex-end",
        marginHorizontal: 12, marginVertical: 2, gap: 8,
      }}
    >
      {/* Avatar (other side, last in group) */}
      {!isMe && (
        <View style={{ width: 28, flexShrink: 0 }}>
          {showAvatar ? (
            <LinearGradient
              colors={participantGradient}
              start={{ x: 0, y: 0 }} end={{ x: 1, y: 1 }}
              style={{ width: 28, height: 28, borderRadius: 14, alignItems: "center", justifyContent: "center" }}
            >
              <Text style={{ fontSize: 14 }}>{participantEmoji}</Text>
            </LinearGradient>
          ) : null}
        </View>
      )}

      <View style={{ maxWidth: "75%", gap: 2 }}>
        <Pressable
          onLongPress={() => setShowPicker(true)}
          style={({ pressed }) => ({ opacity: pressed ? 0.85 : 1 })}
        >
          {msg.type === "audio" ? (
            <View
              style={{
                flexDirection: "row", alignItems: "center", gap: 10,
                paddingHorizontal: 14, paddingVertical: 12, borderRadius: 18,
                backgroundColor: isMe ? colors.primary : colors.surface,
                borderWidth: isMe ? 0 : 1, borderColor: colors.border,
                minWidth: 160,
              }}
            >
              <Ionicons name="mic" size={18} color={isMe ? "#fff" : colors.textMuted} />
              {/* Waveform bars */}
              <View style={{ flex: 1, flexDirection: "row", alignItems: "center", gap: 2 }}>
                {Array.from({ length: 20 }).map((_, i) => (
                  <View
                    key={i}
                    style={{
                      width: 2.5, borderRadius: 1.5,
                      height: 4 + Math.sin(i * 1.2) * 10,
                      backgroundColor: isMe ? "rgba(255,255,255,0.7)" : colors.textMuted,
                    }}
                  />
                ))}
              </View>
              <Text style={{ fontSize: 11, color: isMe ? "rgba(255,255,255,0.8)" : colors.textMuted, fontWeight: "600" }}>
                {msg.audioDuration}
              </Text>
            </View>
          ) : (
            <View
              style={{
                paddingHorizontal: 14, paddingVertical: 10, borderRadius: 18,
                borderBottomRightRadius: isMe ? 4 : 18,
                borderBottomLeftRadius: isMe ? 18 : 4,
                backgroundColor: isMe ? colors.primary : colors.surface,
                borderWidth: isMe ? 0 : 1, borderColor: colors.border,
              }}
            >
              <Text style={{ fontSize: 15, color: isMe ? "#fff" : colors.text, lineHeight: 21 }}>
                {msg.text}
              </Text>
            </View>
          )}
        </Pressable>

        {/* Reactions */}
        {totalReactions > 0 && (
          <View style={{ flexDirection: "row", flexWrap: "wrap", gap: 4, alignSelf: isMe ? "flex-end" : "flex-start" }}>
            {msg.reactions.filter((r) => r.count > 0).map((r) => (
              <Pressable
                key={r.emoji}
                onPress={() => useConnectionsStore.getState().reactToMessage(convId, msg.id, r.emoji as ReactionEmoji)}
                style={{
                  flexDirection: "row", alignItems: "center", gap: 3,
                  backgroundColor: r.reactedByMe ? colors.primary + "18" : colors.card,
                  borderWidth: 1, borderColor: r.reactedByMe ? colors.primary : colors.border,
                  paddingHorizontal: 7, paddingVertical: 3, borderRadius: 10,
                }}
              >
                <Text style={{ fontSize: 13 }}>{r.emoji}</Text>
                <Text style={{ fontSize: 11, fontWeight: "700", color: r.reactedByMe ? colors.primary : colors.textMuted }}>
                  {r.count}
                </Text>
              </Pressable>
            ))}
          </View>
        )}

        {/* Time + status */}
        <View style={{ flexDirection: "row", alignItems: "center", gap: 4, alignSelf: isMe ? "flex-end" : "flex-start" }}>
          <Text style={{ fontSize: 10, color: colors.textMuted }}>{time}</Text>
          {isMe && (
            <Text style={{ fontSize: 10, color: msg.status === "read" ? colors.sky : colors.textMuted }}>
              {statusIcon}
            </Text>
          )}
        </View>
      </View>

      {showPicker && (
        <ReactionPicker msgId={msg.id} convId={convId} onClose={() => setShowPicker(false)} />
      )}
    </View>
  );
}

// ── Date separator ─────────────────────────────────────────────────────────────
function DateSeparator({ date }: { date: string }) {
  const { colors } = useTheme();
  return (
    <View style={{ alignItems: "center", marginVertical: 12 }}>
      <View style={{ backgroundColor: colors.card, paddingHorizontal: 14, paddingVertical: 5, borderRadius: 12, borderWidth: 1, borderColor: colors.border }}>
        <Text style={{ fontSize: 11, color: colors.textMuted, fontWeight: "700" }}>{date}</Text>
      </View>
    </View>
  );
}

// ── Main ChatScreen ────────────────────────────────────────────────────────────
export function ChatScreen() {
  const { colors } = useTheme();
  const insets          = useSafeAreaInsets();
  const convId          = useConnectionsStore((s) => s.activeConversationId);
  const conversations   = useConnectionsStore((s) => s.conversations);
  const sendMessage     = useConnectionsStore((s) => s.sendMessage);
  const setActive       = useConnectionsStore((s) => s.setActiveConversation);
  const initiateCall    = useConnectionsStore((s) => s.initiateCall);
  const call            = useConnectionsStore((s) => s.call);

  const messages  = useConversationMessages(convId ?? "");
  const conv      = conversations.find((c) => c.id === convId);

  const [text, setText]         = useState("");
  const [showAttach, setAttach] = useState(false);
  const listRef                 = useRef<FlatList>(null);

  useEffect(() => {
    if (messages.length > 0) {
      setTimeout(() => listRef.current?.scrollToEnd({ animated: true }), 100);
    }
  }, [messages.length]);

  if (!conv || !convId) return null;

  const participant  = conv.participants[0];
  const isGroup      = conv.type === "group";
  const displayName  = isGroup ? (conv.groupName ?? "Group") : participant.name;
  const displayEmoji = isGroup ? (conv.groupEmoji ?? "👥") : participant.avatarEmoji;
  const displayGrad  = (isGroup ? conv.groupGradient : participant.gradient) ?? [colors.primary, colors.accent] as [string, string];
  const subtitle     = isGroup
    ? `${conv.participants.length + 1} members`
    : participant.online
      ? "Online now"
      : lastSeenText(participant.lastSeen);

  const handleSend = () => {
    if (!text.trim()) return;
    sendMessage(convId, text);
    setText("");
  };

  const handleAudio = () => sendMessage(convId, "Voice note", "audio");

  // Build flat data with date separators
  const listData: (ChatMessage | { type: "__date"; key: string; label: string })[] = [];
  let lastDate = "";
  for (const msg of messages) {
    const date = new Date(msg.createdAt).toLocaleDateString("en-IN", { day: "numeric", month: "short" });
    if (date !== lastDate) {
      listData.push({ type: "__date", key: `sep_${msg.id}`, label: date });
      lastDate = date;
    }
    listData.push(msg);
  }

  return (
    <View style={{ flex: 1, backgroundColor: colors.background }}>
      {/* Header */}
      <View
        style={{
          paddingTop: insets.top,
          backgroundColor: colors.surface,
          borderBottomWidth: 1,
          borderBottomColor: colors.border,
          shadowColor: "#000",
          shadowOffset: { width: 0, height: 1 },
          shadowOpacity: 0.08,
          shadowRadius: 4,
          elevation: 3,
        }}
      >
        <View
          style={{
            height: 56, flexDirection: "row", alignItems: "center",
            paddingHorizontal: 12, gap: 10,
          }}
        >
          {/* Back */}
          <Pressable
            onPress={() => setActive(null)}
            hitSlop={10}
            style={({ pressed }) => ({
              opacity: pressed ? 0.6 : 1,
              width: 36, height: 36, borderRadius: 18,
              backgroundColor: colors.card,
              alignItems: "center", justifyContent: "center",
            })}
          >
            <Ionicons name="chevron-back" size={22} color={colors.text} />
          </Pressable>

          {/* Avatar */}
          <View style={{ position: "relative" }}>
            <LinearGradient
              colors={displayGrad}
              start={{ x: 0, y: 0 }} end={{ x: 1, y: 1 }}
              style={{ width: 42, height: 42, borderRadius: 21, alignItems: "center", justifyContent: "center" }}
            >
              <Text style={{ fontSize: 20 }}>{displayEmoji}</Text>
            </LinearGradient>
            {!isGroup && participant.online && (
              <View style={{ position: "absolute", bottom: 0, right: 0, width: 12, height: 12, borderRadius: 6, backgroundColor: "#22c55e", borderWidth: 2, borderColor: colors.surface }} />
            )}
          </View>

          {/* Name + status */}
          <View style={{ flex: 1, gap: 1 }}>
            <Text style={{ fontSize: 15, fontWeight: "700", color: colors.text }}>{displayName}</Text>
            <Text style={{ fontSize: 12, color: conv.isTyping ? colors.primary : colors.textMuted }}>
              {conv.isTyping ? "typing…" : subtitle}
            </Text>
          </View>

          {/* Call buttons */}
          <Pressable
            onPress={() => initiateCall(convId, "audio")}
            style={({ pressed }) => ({
              width: 36, height: 36, borderRadius: 18,
              backgroundColor: colors.card,
              alignItems: "center", justifyContent: "center",
              borderWidth: 1, borderColor: colors.border,
              opacity: pressed ? 0.6 : 1,
            })}
          >
            <Ionicons name="call-outline" size={18} color={colors.text} />
          </Pressable>
          <Pressable
            onPress={() => initiateCall(convId, "video")}
            style={({ pressed }) => ({
              width: 36, height: 36, borderRadius: 18,
              backgroundColor: colors.card,
              alignItems: "center", justifyContent: "center",
              borderWidth: 1, borderColor: colors.border,
              opacity: pressed ? 0.6 : 1,
            })}
          >
            <Ionicons name="videocam-outline" size={18} color={colors.text} />
          </Pressable>
        </View>
      </View>

      {/* Message list */}
      <FlatList
        ref={listRef}
        data={listData}
        keyExtractor={(item) => ("id" in item ? item.id : item.key)}
        renderItem={({ item, index }) => {
          if ("type" in item && item.type === "__date") {
            return <DateSeparator date={(item as any).label} />;
          }
          const msg = item as ChatMessage;
          const isMe = msg.senderId === ME_ID;
          const next = listData[index + 1];
          const isLastInGroup = !next || ("senderId" in next && (next as ChatMessage).senderId !== msg.senderId);
          return (
            <MessageBubble
              msg={msg}
              isMe={isMe}
              showAvatar={!isMe && isLastInGroup}
              participantEmoji={isGroup
                ? conv.participants.find((p) => p.id === msg.senderId)?.avatarEmoji ?? "👤"
                : participant.avatarEmoji}
              participantGradient={isGroup
                ? conv.participants.find((p) => p.id === msg.senderId)?.gradient ?? [colors.primary, colors.accent]
                : participant.gradient}
              convId={convId}
            />
          );
        }}
        showsVerticalScrollIndicator={false}
        contentContainerStyle={{ paddingVertical: 12, paddingBottom: 8 }}
        onContentSizeChange={() => listRef.current?.scrollToEnd({ animated: false })}
      />

      {/* Input bar */}
      <KeyboardAvoidingView behavior={Platform.OS === "ios" ? "padding" : "height"}>
        <View
          style={{
            flexDirection: "row", alignItems: "flex-end", gap: 8,
            paddingHorizontal: 12, paddingVertical: 10,
            paddingBottom: insets.bottom + 10,
            backgroundColor: colors.surface,
            borderTopWidth: 1, borderTopColor: colors.border,
          }}
        >
          {/* Attach */}
          <Pressable
            onPress={() => setAttach(!showAttach)}
            style={({ pressed }) => ({
              width: 38, height: 38, borderRadius: 19,
              backgroundColor: colors.card,
              alignItems: "center", justifyContent: "center",
              borderWidth: 1, borderColor: colors.border,
              opacity: pressed ? 0.7 : 1,
            })}
          >
            <Ionicons name={showAttach ? "close" : "add"} size={20} color={colors.textMuted} />
          </Pressable>

          {/* Text input */}
          <View
            style={{
              flex: 1, flexDirection: "row", alignItems: "flex-end",
              backgroundColor: colors.card, borderRadius: 22,
              paddingHorizontal: 14, paddingVertical: 8,
              borderWidth: 1, borderColor: colors.border, gap: 8,
              maxHeight: 120,
            }}
          >
            <TextInput
              value={text}
              onChangeText={setText}
              placeholder="Message…"
              placeholderTextColor={colors.textMuted}
              multiline
              style={{ flex: 1, fontSize: 15, color: colors.text, padding: 0, maxHeight: 100 }}
            />
          </View>

          {/* Send / Audio */}
          {text.trim() ? (
            <Pressable
              onPress={handleSend}
              style={({ pressed }) => ({
                width: 40, height: 40, borderRadius: 20, overflow: "hidden",
                opacity: pressed ? 0.85 : 1,
                transform: [{ scale: pressed ? 0.93 : 1 }],
              })}
            >
              <LinearGradient
                colors={[colors.primary, colors.accent]}
                start={{ x: 0, y: 0 }} end={{ x: 1, y: 1 }}
                style={{ flex: 1, alignItems: "center", justifyContent: "center" }}
              >
                <Ionicons name="arrow-up" size={20} color="#fff" />
              </LinearGradient>
            </Pressable>
          ) : (
            <Pressable
              onPress={handleAudio}
              style={({ pressed }) => ({
                width: 40, height: 40, borderRadius: 20,
                backgroundColor: colors.card,
                alignItems: "center", justifyContent: "center",
                borderWidth: 1, borderColor: colors.border,
                opacity: pressed ? 0.7 : 1,
              })}
            >
              <Ionicons name="mic-outline" size={20} color={colors.textMuted} />
            </Pressable>
          )}
        </View>

        {/* Quick attach row */}
        {showAttach && (
          <View
            style={{
              flexDirection: "row", gap: 12, padding: 16,
              paddingBottom: insets.bottom + 12,
              backgroundColor: colors.surface,
              borderTopWidth: 1, borderTopColor: colors.border,
            }}
          >
            {[
              { icon: "camera-outline" as const, label: "Camera" },
              { icon: "image-outline" as const, label: "Gallery" },
              { icon: "musical-notes-outline" as const, label: "Audio" },
              { icon: "location-outline" as const, label: "Location" },
              { icon: "happy-outline" as const, label: "GIF" },
            ].map((item) => (
              <Pressable
                key={item.label}
                onPress={() => setAttach(false)}
                style={({ pressed }) => ({ alignItems: "center", gap: 5, opacity: pressed ? 0.7 : 1 })}
              >
                <View style={{ width: 52, height: 52, borderRadius: 16, backgroundColor: colors.card, borderWidth: 1, borderColor: colors.border, alignItems: "center", justifyContent: "center" }}>
                  <Ionicons name={item.icon} size={24} color={colors.text} />
                </View>
                <Text style={{ fontSize: 11, color: colors.textMuted, fontWeight: "600" }}>{item.label}</Text>
              </Pressable>
            ))}
          </View>
        )}
      </KeyboardAvoidingView>

      {/* Call overlay */}
      {call && <CallScreen />}
    </View>
  );
}
