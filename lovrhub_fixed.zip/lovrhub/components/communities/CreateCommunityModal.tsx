import { useState } from "react";
import { View, Text, Modal, Pressable, TextInput, ScrollView, KeyboardAvoidingView, Platform } from "react-native";
import { LinearGradient } from "expo-linear-gradient";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import { Colors } from "@constants/theme";
import { useCommunityStore } from "@/store/communityStore";
import type { CommunityPrivacy } from "@/types/community";

const COVER_GRADIENTS: [string, string][] = [
  [Colors.primary, Colors.accent],
  [Colors.violet, Colors.rose],
  [Colors.sky, Colors.mint],
  [Colors.gold, Colors.accent],
  [Colors.secondary, Colors.rose],
  [Colors.rose, Colors.violet],
  [Colors.mint, Colors.sky],
  ["#1a1a2e", "#16213e"],
];

const COVER_EMOJIS = ["🌆", "🌈", "🔮", "💫", "🌙", "🔥", "🌺", "💼", "🎭", "🌊", "✨", "🎵"];

const CATEGORIES = ["Dating", "LGBTQ+", "Food & Social", "Sports", "Professional", "Hobbies", "Mental Health", "Travel", "Music", "Fitness"];

export function CreateCommunityModal() {
  const insets          = useSafeAreaInsets();
  const showCreate      = useCommunityStore((s) => s.showCreateModal);
  const setShowCreate   = useCommunityStore((s) => s.setShowCreateModal);
  const createCommunity = useCommunityStore((s) => s.createCommunity);

  const [name, setName]             = useState("");
  const [description, setDesc]      = useState("");
  const [privacy, setPrivacy]       = useState<CommunityPrivacy>("public");
  const [category, setCategory]     = useState(CATEGORIES[0]);
  const [coverGrad, setCoverGrad]   = useState<[string, string]>(COVER_GRADIENTS[0]);
  const [coverEmoji, setCoverEmoji] = useState(COVER_EMOJIS[0]);
  const [tagsText, setTagsText]     = useState("");
  const [step, setStep]             = useState(0);          // 0=details 1=appearance 2=rules

  const [rules, setRules] = useState([{ title: "", description: "" }]);

  const canProceed = step === 0 ? name.trim().length >= 3 && description.trim().length >= 10
    : step === 1 ? true
    : true;

  const handleCreate = () => {
    createCommunity({
      name: name.trim(),
      description: description.trim(),
      coverGradient: coverGrad,
      coverEmoji,
      privacy,
      category,
      tags: tagsText.trim().split(/\s+/).filter((t) => t.startsWith("#")).map((t) => t.slice(1)),
      rules: rules.filter((r) => r.title.trim()).map((r, i) => ({ id: `r${i}`, title: r.title.trim(), description: r.description.trim() })),
      isVerified: false,
    });
    // Reset
    setName(""); setDesc(""); setPrivacy("public"); setCategory(CATEGORIES[0]);
    setCoverGrad(COVER_GRADIENTS[0]); setCoverEmoji(COVER_EMOJIS[0]);
    setTagsText(""); setRules([{ title: "", description: "" }]); setStep(0);
  };

  const STEPS = ["Details", "Appearance", "Rules"];

  return (
    <Modal visible={showCreate} animationType="slide" presentationStyle="pageSheet" onRequestClose={() => setShowCreate(false)}>
      <KeyboardAvoidingView style={{ flex: 1, backgroundColor: Colors.background }} behavior={Platform.OS === "ios" ? "padding" : "height"}>
        {/* Header */}
        <View style={{ flexDirection: "row", alignItems: "center", justifyContent: "space-between", paddingHorizontal: 20, paddingTop: insets.top + 16, paddingBottom: 16, borderBottomWidth: 1, borderBottomColor: Colors.border, backgroundColor: Colors.surface }}>
          <Pressable onPress={() => step > 0 ? setStep(step - 1) : setShowCreate(false)}>
            <Text style={{ fontSize: 15, color: Colors.textSecondary, fontWeight: "600" }}>
              {step > 0 ? "← Back" : "Cancel"}
            </Text>
          </Pressable>
          <Text style={{ fontSize: 16, fontWeight: "800", color: Colors.text }}>New Community</Text>
          {step < 2 ? (
            <Pressable onPress={() => canProceed && setStep(step + 1)} disabled={!canProceed}>
              <LinearGradient colors={[Colors.primary, Colors.accent]} start={{ x: 0, y: 0 }} end={{ x: 1, y: 0 }} style={{ paddingHorizontal: 18, paddingVertical: 8, borderRadius: 14, opacity: canProceed ? 1 : 0.4 }}>
                <Text style={{ color: "#fff", fontWeight: "800", fontSize: 14 }}>Next</Text>
              </LinearGradient>
            </Pressable>
          ) : (
            <Pressable onPress={handleCreate} disabled={!name.trim()}>
              <LinearGradient colors={[Colors.primary, Colors.accent]} start={{ x: 0, y: 0 }} end={{ x: 1, y: 0 }} style={{ paddingHorizontal: 18, paddingVertical: 8, borderRadius: 14 }}>
                <Text style={{ color: "#fff", fontWeight: "800", fontSize: 14 }}>Create 🎉</Text>
              </LinearGradient>
            </Pressable>
          )}
        </View>

        {/* Step indicator */}
        <View style={{ flexDirection: "row", paddingHorizontal: 20, paddingVertical: 14, gap: 8 }}>
          {STEPS.map((s, i) => (
            <View key={s} style={{ flex: 1, height: 4, borderRadius: 2, backgroundColor: i <= step ? Colors.primary : Colors.border }} />
          ))}
        </View>

        <ScrollView contentContainerStyle={{ padding: 20, gap: 20 }} keyboardShouldPersistTaps="handled" showsVerticalScrollIndicator={false}>

          {/* ── Step 0: Details ─────────────────────────────────────── */}
          {step === 0 && (
            <>
              {/* Community name */}
              <View style={{ gap: 8 }}>
                <Text style={{ fontSize: 13, fontWeight: "700", color: Colors.textSecondary, letterSpacing: 0.3 }}>COMMUNITY NAME *</Text>
                <TextInput value={name} onChangeText={setName} placeholder="e.g. Mumbai Hikers, Queer Book Club…" placeholderTextColor={Colors.textMuted} maxLength={50}
                  style={{ backgroundColor: Colors.surface, borderRadius: 16, borderWidth: 1, borderColor: Colors.border, paddingHorizontal: 14, paddingVertical: 13, fontSize: 15, color: Colors.text }}
                />
                <Text style={{ fontSize: 11, color: Colors.textMuted, textAlign: "right" }}>{name.length}/50</Text>
              </View>

              {/* Description */}
              <View style={{ gap: 8 }}>
                <Text style={{ fontSize: 13, fontWeight: "700", color: Colors.textSecondary, letterSpacing: 0.3 }}>DESCRIPTION *</Text>
                <TextInput value={description} onChangeText={setDesc} placeholder="What's this community about? Who should join?" placeholderTextColor={Colors.textMuted} multiline numberOfLines={4} maxLength={300}
                  style={{ backgroundColor: Colors.surface, borderRadius: 16, borderWidth: 1, borderColor: Colors.border, padding: 14, fontSize: 15, color: Colors.text, lineHeight: 22, minHeight: 100, textAlignVertical: "top" }}
                />
                <Text style={{ fontSize: 11, color: Colors.textMuted, textAlign: "right" }}>{description.length}/300</Text>
              </View>

              {/* Privacy toggle */}
              <View style={{ gap: 10 }}>
                <Text style={{ fontSize: 13, fontWeight: "700", color: Colors.textSecondary, letterSpacing: 0.3 }}>PRIVACY</Text>
                <View style={{ flexDirection: "row", gap: 10 }}>
                  {(["public", "private"] as CommunityPrivacy[]).map((p) => {
                    const isActive = privacy === p;
                    return (
                      <Pressable key={p} onPress={() => setPrivacy(p)} style={{ flex: 1 }}>
                        {isActive ? (
                          <LinearGradient colors={[Colors.primary, Colors.accent]} start={{ x: 0, y: 0 }} end={{ x: 1, y: 1 }} style={{ borderRadius: 16, padding: 14, gap: 5 }}>
                            <Text style={{ fontSize: 22 }}>{p === "public" ? "🌐" : "🔒"}</Text>
                            <Text style={{ color: "#fff", fontSize: 14, fontWeight: "800" }}>{p === "public" ? "Public" : "Private"}</Text>
                            <Text style={{ color: "rgba(255,255,255,0.8)", fontSize: 12 }}>{p === "public" ? "Anyone can join" : "Request required"}</Text>
                          </LinearGradient>
                        ) : (
                          <View style={{ borderRadius: 16, padding: 14, gap: 5, backgroundColor: Colors.card, borderWidth: 1.5, borderColor: Colors.border }}>
                            <Text style={{ fontSize: 22 }}>{p === "public" ? "🌐" : "🔒"}</Text>
                            <Text style={{ color: Colors.text, fontSize: 14, fontWeight: "700" }}>{p === "public" ? "Public" : "Private"}</Text>
                            <Text style={{ color: Colors.textMuted, fontSize: 12 }}>{p === "public" ? "Anyone can join" : "Request required"}</Text>
                          </View>
                        )}
                      </Pressable>
                    );
                  })}
                </View>
              </View>

              {/* Category */}
              <View style={{ gap: 10 }}>
                <Text style={{ fontSize: 13, fontWeight: "700", color: Colors.textSecondary, letterSpacing: 0.3 }}>CATEGORY</Text>
                <View style={{ flexDirection: "row", flexWrap: "wrap", gap: 8 }}>
                  {CATEGORIES.map((cat) => {
                    const isActive = category === cat;
                    return (
                      <Pressable key={cat} onPress={() => setCategory(cat)}>
                        {isActive ? (
                          <LinearGradient colors={[Colors.violet, Colors.sky]} start={{ x: 0, y: 0 }} end={{ x: 1, y: 0 }} style={{ paddingHorizontal: 14, paddingVertical: 8, borderRadius: 20 }}>
                            <Text style={{ color: "#fff", fontSize: 13, fontWeight: "700" }}>{cat}</Text>
                          </LinearGradient>
                        ) : (
                          <View style={{ paddingHorizontal: 14, paddingVertical: 8, borderRadius: 20, borderWidth: 1.5, borderColor: Colors.border, backgroundColor: Colors.card }}>
                            <Text style={{ color: Colors.textSecondary, fontSize: 13, fontWeight: "600" }}>{cat}</Text>
                          </View>
                        )}
                      </Pressable>
                    );
                  })}
                </View>
              </View>

              {/* Tags */}
              <View style={{ gap: 8 }}>
                <Text style={{ fontSize: 13, fontWeight: "700", color: Colors.textSecondary, letterSpacing: 0.3 }}>TAGS</Text>
                <TextInput value={tagsText} onChangeText={setTagsText} placeholder="#Dating #Mumbai #Singles" placeholderTextColor={Colors.textMuted} autoCapitalize="none"
                  style={{ backgroundColor: Colors.surface, borderRadius: 16, borderWidth: 1, borderColor: Colors.border, paddingHorizontal: 14, paddingVertical: 13, fontSize: 14, color: Colors.text }}
                />
              </View>
            </>
          )}

          {/* ── Step 1: Appearance ────────────────────────────────── */}
          {step === 1 && (
            <>
              {/* Preview */}
              <LinearGradient colors={coverGrad} start={{ x: 0, y: 0 }} end={{ x: 1, y: 1 }} style={{ height: 100, borderRadius: 18, alignItems: "flex-start", justifyContent: "flex-end", padding: 16, marginBottom: 4 }}>
                <Text style={{ fontSize: 44 }}>{coverEmoji}</Text>
                <Text style={{ position: "absolute", top: 12, left: 16, color: "#fff", fontSize: 18, fontWeight: "800" }}>{name || "Preview"}</Text>
              </LinearGradient>

              {/* Cover gradient picker */}
              <View style={{ gap: 10 }}>
                <Text style={{ fontSize: 13, fontWeight: "700", color: Colors.textSecondary, letterSpacing: 0.3 }}>COVER COLOUR</Text>
                <View style={{ flexDirection: "row", flexWrap: "wrap", gap: 10 }}>
                  {COVER_GRADIENTS.map((grad, i) => (
                    <Pressable key={i} onPress={() => setCoverGrad(grad)}>
                      <LinearGradient colors={grad} start={{ x: 0, y: 0 }} end={{ x: 1, y: 1 }} style={{ width: 52, height: 52, borderRadius: 16, borderWidth: JSON.stringify(coverGrad) === JSON.stringify(grad) ? 3 : 0, borderColor: Colors.primary }} />
                    </Pressable>
                  ))}
                </View>
              </View>

              {/* Emoji picker */}
              <View style={{ gap: 10 }}>
                <Text style={{ fontSize: 13, fontWeight: "700", color: Colors.textSecondary, letterSpacing: 0.3 }}>COVER EMOJI</Text>
                <View style={{ flexDirection: "row", flexWrap: "wrap", gap: 10 }}>
                  {COVER_EMOJIS.map((emoji) => (
                    <Pressable key={emoji} onPress={() => setCoverEmoji(emoji)}
                      style={({ pressed }) => ({
                        width: 52, height: 52, borderRadius: 16,
                        backgroundColor: coverEmoji === emoji ? Colors.primary + "18" : Colors.card,
                        alignItems: "center", justifyContent: "center",
                        borderWidth: 1.5, borderColor: coverEmoji === emoji ? Colors.primary : Colors.border,
                        opacity: pressed ? 0.7 : 1,
                      })}
                    >
                      <Text style={{ fontSize: 26 }}>{emoji}</Text>
                    </Pressable>
                  ))}
                </View>
              </View>
            </>
          )}

          {/* ── Step 2: Rules ──────────────────────────────────────── */}
          {step === 2 && (
            <>
              <Text style={{ fontSize: 14, color: Colors.textMuted, lineHeight: 21 }}>
                Rules help set expectations. You can add up to 5 rules and edit them later.
              </Text>
              {rules.map((rule, i) => (
                <View key={i} style={{ backgroundColor: Colors.surface, borderRadius: 16, borderWidth: 1, borderColor: Colors.border, padding: 14, gap: 10 }}>
                  <View style={{ flexDirection: "row", alignItems: "center", justifyContent: "space-between" }}>
                    <Text style={{ fontSize: 13, fontWeight: "700", color: Colors.textSecondary }}>Rule {i + 1}</Text>
                    {rules.length > 1 && (
                      <Pressable onPress={() => setRules((r) => r.filter((_, idx) => idx !== i))}>
                        <Text style={{ fontSize: 13, color: Colors.primary }}>Remove</Text>
                      </Pressable>
                    )}
                  </View>
                  <TextInput value={rule.title} onChangeText={(v) => setRules((r) => r.map((x, idx) => idx === i ? { ...x, title: v } : x))}
                    placeholder="Rule title" placeholderTextColor={Colors.textMuted}
                    style={{ backgroundColor: Colors.card, borderRadius: 12, borderWidth: 1, borderColor: Colors.border, paddingHorizontal: 12, paddingVertical: 10, fontSize: 14, color: Colors.text }}
                  />
                  <TextInput value={rule.description} onChangeText={(v) => setRules((r) => r.map((x, idx) => idx === i ? { ...x, description: v } : x))}
                    placeholder="Rule description (optional)" placeholderTextColor={Colors.textMuted} multiline
                    style={{ backgroundColor: Colors.card, borderRadius: 12, borderWidth: 1, borderColor: Colors.border, paddingHorizontal: 12, paddingVertical: 10, fontSize: 13, color: Colors.text, minHeight: 60, textAlignVertical: "top" }}
                  />
                </View>
              ))}
              {rules.length < 5 && (
                <Pressable onPress={() => setRules((r) => [...r, { title: "", description: "" }])}
                  style={({ pressed }) => ({
                    flexDirection: "row", alignItems: "center", justifyContent: "center", gap: 8,
                    padding: 14, borderRadius: 16, borderWidth: 1.5, borderColor: Colors.border, borderStyle: "dashed",
                    backgroundColor: Colors.card, opacity: pressed ? 0.7 : 1,
                  })}
                >
                  <Text style={{ fontSize: 18 }}>+</Text>
                  <Text style={{ fontSize: 14, fontWeight: "700", color: Colors.textSecondary }}>Add rule</Text>
                </Pressable>
              )}
            </>
          )}
        </ScrollView>
      </KeyboardAvoidingView>
    </Modal>
  );
}
