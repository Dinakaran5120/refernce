import { useRef } from "react";
import { View, Text, Pressable, Animated } from "react-native";
import { LinearGradient } from "expo-linear-gradient";
import { Colors } from "@constants/theme";
import { useDiscoverStore } from "@/store/discoverStore";

export function SpotlightBanner() {
  const users  = useDiscoverStore((s) => s.users);
  const online = users.filter((u) => u.online).length;
  const liked  = users.filter((u) => u.liked).length;
  const nearby = users.filter((u) => u.distanceKm <= 5).length;

  const scale = useRef(new Animated.Value(1)).current;

  const onPressIn = () => {
    Animated.spring(scale, {
      toValue: 0.97,
      useNativeDriver: true,
      speed: 40,
      bounciness: 4,
    }).start();
  };

  const onPressOut = () => {
    Animated.spring(scale, {
      toValue: 1,
      useNativeDriver: true,
      speed: 28,
      bounciness: 8,
    }).start();
  };

  return (
    <Animated.View style={{ transform: [{ scale }], marginBottom: 16 }}>
      <Pressable onPressIn={onPressIn} onPressOut={onPressOut}>
        <LinearGradient
          colors={[Colors.violet, Colors.rose, Colors.accent]}
          start={{ x: 0, y: 0 }}
          end={{ x: 1, y: 0 }}
          style={{ borderRadius: 20, padding: 16 }}
        >
          <View style={{ flexDirection: "row", justifyContent: "space-between", alignItems: "center" }}>
            <View style={{ flex: 1, marginRight: 12 }}>
              <Text style={{ color: "rgba(255,255,255,0.85)", fontSize: 11, fontWeight: "700", letterSpacing: 0.5 }}>
                ✨ TODAY'S SNAPSHOT
              </Text>
              <Text style={{ color: "#fff", fontSize: 16, fontWeight: "800", marginTop: 3 }}>
                {online} online · {nearby} within 5 km
              </Text>
              {liked > 0 && (
                <Text style={{ color: "rgba(255,255,255,0.8)", fontSize: 12, marginTop: 2 }}>
                  You liked {liked} {liked === 1 ? "person" : "people"} today
                </Text>
              )}
            </View>
            <View
              style={{
                backgroundColor: "rgba(255,255,255,0.22)",
                paddingHorizontal: 14,
                paddingVertical: 9,
                borderRadius: 14,
              }}
            >
              <Text style={{ color: "#fff", fontSize: 12, fontWeight: "800" }}>Boost ⚡</Text>
            </View>
          </View>
        </LinearGradient>
      </Pressable>
    </Animated.View>
  );
}
