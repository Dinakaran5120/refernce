import { useState, useRef, useEffect } from "react";
import { View, Text, TextInput, Pressable, KeyboardAvoidingView, Platform, Animated } from "react-native";
import { useRouter } from "expo-router";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import { LinearGradient } from "expo-linear-gradient";
import { Colors } from "@constants/theme";
import { useAuthStore } from "@/store/authStore";
import { PrimaryButton, BackButton } from "@components/auth/AuthUI";

const FAKE_OTP = "1234";
const OTP_LENGTH = 4;

export default function OtpScreen() {
  const router     = useRouter();
  const insets     = useSafeAreaInsets();
  const profile    = useAuthStore((s) => s.profile);

  const [digits, setDigits]       = useState<string[]>(Array(OTP_LENGTH).fill(""));
  const [error, setError]         = useState("");
  const [loading, setLoading]     = useState(false);
  const [resendTimer, setTimer]   = useState(30);
  const [shake]                   = useState(new Animated.Value(0));
  const inputRefs                 = useRef<(TextInput | null)[]>([]);

  useEffect(() => {
    const id = setInterval(() => setTimer((t) => (t > 0 ? t - 1 : 0)), 1000);
    return () => clearInterval(id);
  }, []);

  useEffect(() => {
    const t = setTimeout(() => inputRefs.current[0]?.focus(), 300);
    return () => clearTimeout(t);
  }, []);

  const triggerShake = () => {
    Animated.sequence([
      Animated.timing(shake, { toValue: 10,  duration: 60, useNativeDriver: true }),
      Animated.timing(shake, { toValue: -10, duration: 60, useNativeDriver: true }),
      Animated.timing(shake, { toValue: 10,  duration: 60, useNativeDriver: true }),
      Animated.timing(shake, { toValue: 0,   duration: 60, useNativeDriver: true }),
    ]).start();
  };

  const handleDigit = (value: string, index: number) => {
    const cleaned = value.replace(/\D/g, "").slice(-1);
    const next = [...digits];
    next[index] = cleaned;
    setDigits(next);
    setError("");
    if (cleaned && index < OTP_LENGTH - 1) inputRefs.current[index + 1]?.focus();
    if (index === OTP_LENGTH - 1 && cleaned) {
      const full = [...next.slice(0, OTP_LENGTH - 1), cleaned].join("");
      if (full.length === OTP_LENGTH) handleVerify(full);
    }
  };

  const handleKeyPress = (key: string, index: number) => {
    if (key === "Backspace" && !digits[index] && index > 0) {
      inputRefs.current[index - 1]?.focus();
      const next = [...digits];
      next[index - 1] = "";
      setDigits(next);
    }
  };

  const handleVerify = async (code?: string) => {
    const otp = code ?? digits.join("");
    if (otp.length < OTP_LENGTH) { setError("Enter the complete 4-digit code"); return; }
    setLoading(true);
    await new Promise((r) => setTimeout(r, 800));
    setLoading(false);
    if (otp === FAKE_OTP) {
      router.push("/auth/email");
    } else {
      setError("Incorrect OTP. Hint: try 1234 😉");
      triggerShake();
      setDigits(Array(OTP_LENGTH).fill(""));
      setTimeout(() => inputRefs.current[0]?.focus(), 100);
    }
  };

  const handleResend = () => {
    if (resendTimer > 0) return;
    setTimer(30);
    setError("");
    setDigits(Array(OTP_LENGTH).fill(""));
    inputRefs.current[0]?.focus();
  };

  return (
    <KeyboardAvoidingView
      style={{ flex: 1, backgroundColor: Colors.background }}
      behavior={Platform.OS === "ios" ? "padding" : "height"}
    >
      <View style={{ paddingTop: insets.top }}>
        <BackButton onPress={() => router.back()} />
      </View>

      <View style={{ flex: 1, paddingHorizontal: 24, paddingBottom: insets.bottom + 32 }}>
        {/* Header */}
        <View style={{ paddingTop: 8, paddingBottom: 32 }}>
          <Text style={{ fontSize: 40, marginBottom: 12 }}>🔐</Text>
          <Text style={{ fontSize: 28, fontWeight: "800", color: Colors.text, letterSpacing: -0.5, marginBottom: 8 }}>
            Check your{"\n"}messages
          </Text>
          <Text style={{ fontSize: 15, color: Colors.textSecondary, lineHeight: 22 }}>
            We sent a 4-digit code to{"\n"}
            <Text style={{ fontWeight: "700", color: Colors.text }}>
              {profile.phone || "+91 98765 43210"}
            </Text>
          </Text>
          <View
            style={{
              marginTop: 10, backgroundColor: Colors.card, borderRadius: 10,
              paddingHorizontal: 12, paddingVertical: 7, alignSelf: "flex-start",
              borderWidth: 1, borderColor: Colors.border,
            }}
          >
            <Text style={{ fontSize: 12, color: Colors.textMuted, fontWeight: "600" }}>
              🧪 Dev mode — use{" "}
              <Text style={{ color: Colors.primary, fontWeight: "800" }}>1234</Text>
            </Text>
          </View>
        </View>

        {/* OTP boxes */}
        <Animated.View
          style={{ flexDirection: "row", gap: 14, justifyContent: "center", marginBottom: 10, transform: [{ translateX: shake }] }}
        >
          {digits.map((digit, i) => {
            const isCursor = !digit && digits.slice(0, i).every((d) => d !== "");
            return (
              <View key={i} style={{ position: "relative" }}>
                {digit ? (
                  <LinearGradient
                    colors={[Colors.primary, Colors.accent]}
                    start={{ x: 0, y: 0 }} end={{ x: 1, y: 1 }}
                    style={{
                      width: 68, height: 72, borderRadius: 18,
                      alignItems: "center", justifyContent: "center",
                      shadowColor: Colors.primary, shadowOffset: { width: 0, height: 4 },
                      shadowOpacity: 0.3, shadowRadius: 8, elevation: 4,
                    }}
                  >
                    <Text style={{ fontSize: 28, color: "#fff", fontWeight: "800" }}>{digit}</Text>
                  </LinearGradient>
                ) : (
                  <View
                    style={{
                      width: 68, height: 72, borderRadius: 18,
                      backgroundColor: Colors.surface,
                      borderWidth: isCursor ? 2 : 1.5,
                      borderColor: error ? Colors.primary : isCursor ? Colors.accent : Colors.border,
                      alignItems: "center", justifyContent: "center",
                    }}
                  >
                    {isCursor && (
                      <View style={{ width: 2, height: 28, borderRadius: 1, backgroundColor: Colors.accent, opacity: 0.8 }} />
                    )}
                  </View>
                )}
                <TextInput
                  ref={(r) => { inputRefs.current[i] = r; }}
                  value={digit}
                  onChangeText={(v) => handleDigit(v, i)}
                  onKeyPress={({ nativeEvent }) => handleKeyPress(nativeEvent.key, i)}
                  keyboardType="number-pad"
                  maxLength={1}
                  selectTextOnFocus
                  style={{ position: "absolute", width: 68, height: 72, opacity: 0 }}
                />
              </View>
            );
          })}
        </Animated.View>

        {error ? (
          <Text style={{ textAlign: "center", color: Colors.primary, fontSize: 13, fontWeight: "600", marginBottom: 20 }}>
            {error}
          </Text>
        ) : (
          <View style={{ height: 36 }} />
        )}

        <PrimaryButton label="Verify OTP" onPress={() => handleVerify()} loading={loading} disabled={digits.some((d) => !d)} icon="✓" />

        <View style={{ flexDirection: "row", alignItems: "center", justifyContent: "center", marginTop: 24, gap: 4 }}>
          <Text style={{ fontSize: 14, color: Colors.textMuted }}>Didn't receive it? </Text>
          <Pressable onPress={handleResend} disabled={resendTimer > 0}>
            <Text style={{ fontSize: 14, fontWeight: "800", color: resendTimer > 0 ? Colors.textMuted : Colors.primary }}>
              {resendTimer > 0 ? `Resend in ${resendTimer}s` : "Resend OTP"}
            </Text>
          </Pressable>
        </View>
      </View>
    </KeyboardAvoidingView>
  );
}
