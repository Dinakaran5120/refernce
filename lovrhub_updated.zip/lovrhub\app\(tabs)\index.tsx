import { useRef, useCallback } from "react";
import {
  View,
  Text,
  ScrollView,
  Pressable,
  Animated,
  Dimensions,
} from "react-native";
import { LinearGradient } from "expo-linear-gradient";
import { Ionicons } from "@expo/vector-icons";
import { useTheme } from "@/context/ThemeContext";
import { useDiscoverStore } from "@/store/discoverStore";
import { useDiscoverFilters, useActiveFilterCount } from "@/hooks/useDiscoverFilters";
import { DiscoverCard } from "@components/discover/DiscoverCard";
import { FilterSheet } from "@components/discover/FilterSheet";
import { EmptyDiscover } from "@components/discover/EmptyDiscover";
import type { NearbyUser } from "@/types/discover";

const { width: W } = Dimensions.get("window");
const CARD_HALF = (W - 48) / 2;

const INTENT_TABS = ["All", "Dating", "Friends", "Hookup", "LGBTQ+"];

// ── Spring press hook ─────────────────────────────────────────────────────────
function useSpringPress() {
  const scale = useRef(new Animated.Value(1)).current;

  const onPressIn = useCallback(() => {
    Animated.spring(scale, { toValue: 0.93, useNativeDriver: true, speed: 50, bounciness: 5 }).start();
  }, [scale]);

  const onPressOut = useCallback(() => {
    Animated.spring(scale, { toValue: 1, useNativeDriver: true, speed: 30, bounciness: 10 }).start();
  }, [scale]);

  return { scale, onPressIn, onPressOut };
}

// ── Intent pill ────────────────────────────────────────────────────────────────
function IntentPill({ tab, isActive, onPress }: { tab: string; isActive: boolean; onPress: () => void }) {
  const { scale, onPressIn, onPressOut } = useSpringPress();
  const { colors } = useTheme();

  return (
    <Animated.View style={{ transform: [{ scale }] }}>
      <Pressable onPress={onPress} onPressIn={onPressIn} onPressOut={onPressOut}>
        {isActive ? (
          <LinearGradient
            colors={tab === "LGBTQ+" ? [colors.violet, colors.rose] : [colors.primary, colors.accent]}
            start={{ x: 0, y: 0 }}
            end={{ x: 1, y: 1 }}
            style={{
              paddingHorizontal: 20,
              paddingVertical: 9,
              borderRadius: 24,
              shadowColor: tab === "LGBTQ+" ? colors.violet : colors.primary,
              shadowOffset: { width: 0, height: 4 },
              shadowOpacity: 0.4,
              shadowRadius: 8,
              elevation: 4,
            }}
          >
            <Text style={{ color: "#fff", fontSize: 13, fontWeight: "700", letterSpacing: 0.2 }}>{tab}</Text>
          </LinearGradient>
        ) : (
          <View
            style={{
              paddingHorizontal: 20,
              paddingVertical: 9,
              borderRadius: 24,
              backgroundColor: colors.card,
              borderWidth: 1.5,
              borderColor: colors.border,
            }}
          >
            <Text style={{ color: colors.textMuted, fontSize: 13, fontWeight: "600", letterSpacing: 0.2 }}>{tab}</Text>
          </View>
        )}
      </Pressable>
    </Animated.View>
  );
}

// ── Intent tab bar ─────────────────────────────────────────────────────────────
function IntentTabBar() {
  const active    = useDiscoverStore((s) => s.activeIntentFilter);
  const setActive = useDiscoverStore((s) => s.setActiveIntentFilter);

  return (
    <ScrollView
      horizontal
      showsHorizontalScrollIndicator={false}
      contentContainerStyle={{ paddingHorizontal: 16, paddingVertical: 10, gap: 8 }}
    >
      {INTENT_TABS.map((tab) => (
        <IntentPill
          key={tab}
          tab={tab}
          isActive={active === tab}
          onPress={() => setActive(tab)}
        />
      ))}
    </ScrollView>
  );
}

// ── Filter/toggle row ──────────────────────────────────────────────────────────
function DiscoverToolbar() {
  const { colors } = useTheme();
  const setShowSheet  = useDiscoverStore((s) => s.setShowFilterSheet);
  const activeCount   = useActiveFilterCount();
  const filteredUsers = useDiscoverFilters();
  const filters       = useDiscoverStore((s) => s.filters);
  const setFilters    = useDiscoverStore((s) => s.setFilters);
  const onlineOnly    = filters.onlineOnly;
  const favOnly       = filters.favouritesOnly;

  return (
    <View
      style={{
        flexDirection: "row",
        alignItems: "center",
        paddingHorizontal: 16,
        paddingBottom: 10,
        gap: 8,
      }}
    >
      {/* Count */}
      <View style={{ flex: 1 }}>
        <Text style={{ fontSize: 12, color: colors.textMuted, fontWeight: "600" }}>
          {filteredUsers.length === 0 ? "No matches" : `${filteredUsers.length} nearby`}
        </Text>
      </View>

      {/* Online toggle */}
      <Pressable
        onPress={() => setFilters({ onlineOnly: !onlineOnly })}
        style={{
          flexDirection: "row",
          alignItems: "center",
          gap: 5,
          paddingHorizontal: 12,
          paddingVertical: 7,
          borderRadius: 12,
          backgroundColor: onlineOnly ? "#16a34a22" : colors.card,
          borderWidth: 1.5,
          borderColor: onlineOnly ? "#16a34a" : colors.border,
        }}
      >
        <View style={{ width: 7, height: 7, borderRadius: 4, backgroundColor: onlineOnly ? "#16a34a" : colors.textMuted }} />
        <Text style={{ fontSize: 12, fontWeight: "700", color: onlineOnly ? "#16a34a" : colors.textMuted }}>Online</Text>
      </Pressable>

      {/* Saved toggle */}
      <Pressable
        onPress={() => setFilters({ favouritesOnly: !favOnly })}
        style={{
          flexDirection: "row",
          alignItems: "center",
          gap: 5,
          paddingHorizontal: 12,
          paddingVertical: 7,
          borderRadius: 12,
          backgroundColor: favOnly ? colors.gold + "22" : colors.card,
          borderWidth: 1.5,
          borderColor: favOnly ? colors.gold : colors.border,
        }}
      >
        <Ionicons name={favOnly ? "star" : "star-outline"} size={13} color={favOnly ? colors.gold : colors.textMuted} />
        <Text style={{ fontSize: 12, fontWeight: "700", color: favOnly ? colors.gold : colors.textMuted }}>Saved</Text>
      </Pressable>

      {/* Filter button */}
      <Pressable
        onPress={() => setShowSheet(true)}
        style={{
          flexDirection: "row",
          alignItems: "center",
          gap: 5,
          paddingHorizontal: 12,
          paddingVertical: 7,
          borderRadius: 12,
          backgroundColor: activeCount > 0 ? colors.primary + "18" : colors.card,
          borderWidth: 1.5,
          borderColor: activeCount > 0 ? colors.primary : colors.border,
        }}
      >
        <Ionicons name="options-outline" size={14} color={activeCount > 0 ? colors.primary : colors.textMuted} />
        <Text style={{ fontSize: 12, fontWeight: "700", color: activeCount > 0 ? colors.primary : colors.textMuted }}>
          {activeCount > 0 ? `Filters (${activeCount})` : "Filters"}
        </Text>
      </Pressable>
    </View>
  );
}

// ── Mini profile card (for grid sections) ──────────────────────────────────────
function MiniProfileCard({ user }: { user: NearbyUser }) {
  const { colors } = useTheme();
  const { scale, onPressIn, onPressOut } = useSpringPress();

  return (
    <Animated.View style={{ transform: [{ scale }], width: CARD_HALF }}>
      <Pressable
        onPressIn={onPressIn}
        onPressOut={onPressOut}
        style={{
          borderRadius: 20,
          overflow: "hidden",
          height: CARD_HALF * 1.35,
          shadowColor: "#000",
          shadowOffset: { width: 0, height: 6 },
          shadowOpacity: 0.18,
          shadowRadius: 14,
          elevation: 8,
        }}
      >
        {/* Background gradient */}
        <LinearGradient
          colors={user.gradient}
          start={{ x: 0, y: 0 }}
          end={{ x: 1, y: 1 }}
          style={{ flex: 1 }}
        >
          {/* Avatar */}
          <View style={{ flex: 1, alignItems: "center", justifyContent: "center" }}>
            <View
              style={{
                width: 64,
                height: 64,
                borderRadius: 32,
                backgroundColor: "rgba(255,255,255,0.25)",
                alignItems: "center",
                justifyContent: "center",
                borderWidth: 2,
                borderColor: "rgba(255,255,255,0.5)",
              }}
            >
              <Text style={{ fontSize: 32 }}>{user.avatarEmoji}</Text>
            </View>
          </View>

          {/* Online badge */}
          {user.online && (
            <View
              style={{
                position: "absolute",
                top: 10,
                left: 10,
                flexDirection: "row",
                alignItems: "center",
                backgroundColor: "#16a34a",
                paddingHorizontal: 8,
                paddingVertical: 3,
                borderRadius: 10,
                gap: 4,
              }}
            >
              <View style={{ width: 5, height: 5, borderRadius: 3, backgroundColor: "#fff" }} />
              <Text style={{ color: "#fff", fontSize: 10, fontWeight: "700" }}>Recently Active</Text>
            </View>
          )}

          {/* Bookmark icon */}
          <Pressable
            style={{
              position: "absolute",
              top: 10,
              right: 10,
              width: 28,
              height: 28,
              borderRadius: 14,
              backgroundColor: "rgba(0,0,0,0.3)",
              alignItems: "center",
              justifyContent: "center",
            }}
          >
            <Ionicons name="bookmark-outline" size={14} color="#fff" />
          </Pressable>

          {/* Bottom info */}
          <LinearGradient
            colors={["transparent", "rgba(0,0,0,0.7)"]}
            style={{ padding: 12, paddingTop: 28 }}
            pointerEvents="none"
          >
            <Text style={{ color: "#fff", fontSize: 14, fontWeight: "800", letterSpacing: -0.2 }}>
              {user.name} {user.age}
            </Text>
          </LinearGradient>
        </LinearGradient>
      </Pressable>
    </Animated.View>
  );
}

// ── Section header ─────────────────────────────────────────────────────────────
function SectionHeader({ title, onSeeMore }: { title: string; onSeeMore?: () => void }) {
  const { colors } = useTheme();
  return (
    <View
      style={{
        flexDirection: "row",
        alignItems: "center",
        justifyContent: "space-between",
        paddingHorizontal: 16,
        paddingTop: 6,
        paddingBottom: 10,
      }}
    >
      <Text style={{ fontSize: 17, fontWeight: "800", color: colors.text, letterSpacing: -0.3 }}>
        {title}
      </Text>
      {onSeeMore && (
        <Pressable onPress={onSeeMore}>
          <Text style={{ fontSize: 13, color: colors.textMuted, fontWeight: "600" }}>See More</Text>
        </Pressable>
      )}
    </View>
  );
}

// ── Spotlight / Stats banner ───────────────────────────────────────────────────
function SnapshotBanner() {
  const { colors } = useTheme();
  const users  = useDiscoverStore((s) => s.users);
  const online = users.filter((u) => u.online).length;
  const nearby = users.filter((u) => u.distanceKm <= 5).length;
  const liked  = users.filter((u) => u.liked).length;

  return (
    <LinearGradient
      colors={[colors.violet, colors.rose, colors.accent]}
      start={{ x: 0, y: 0 }}
      end={{ x: 1, y: 0 }}
      style={{
        marginHorizontal: 16,
        marginBottom: 16,
        borderRadius: 18,
        padding: 16,
      }}
    >
      <View style={{ flexDirection: "row", alignItems: "center", justifyContent: "space-between" }}>
        <View style={{ flex: 1, marginRight: 12 }}>
          <Text style={{ color: "rgba(255,255,255,0.85)", fontSize: 11, fontWeight: "700", letterSpacing: 0.6 }}>
            ✨ TODAY'S SNAPSHOT
          </Text>
          <Text style={{ color: "#fff", fontSize: 16, fontWeight: "800", marginTop: 3 }}>
            {online} online · {nearby} within 5 km
          </Text>
          {liked > 0 && (
            <Text style={{ color: "rgba(255,255,255,0.8)", fontSize: 12, marginTop: 2 }}>
              You liked {liked} {liked === 1 ? "person" : "people"} today
            </Text>
          )}
        </View>
        <View
          style={{
            backgroundColor: "rgba(255,255,255,0.2)",
            paddingHorizontal: 14,
            paddingVertical: 9,
            borderRadius: 14,
            borderWidth: 1,
            borderColor: "rgba(255,255,255,0.3)",
          }}
        >
          <Text style={{ color: "#fff", fontSize: 12, fontWeight: "800" }}>⚡ Boost</Text>
        </View>
      </View>
    </LinearGradient>
  );
}

// ── Tinder-style Top Picks banner ──────────────────────────────────────────────
function TopPicksBanner() {
  const { colors } = useTheme();
  return (
    <LinearGradient
      colors={[colors.primary, colors.accent]}
      start={{ x: 0, y: 0 }}
      end={{ x: 1, y: 0 }}
      style={{
        marginHorizontal: 16,
        marginBottom: 16,
        borderRadius: 18,
        padding: 16,
        flexDirection: "row",
        alignItems: "center",
        gap: 12,
      }}
    >
      <View
        style={{
          width: 44,
          height: 44,
          borderRadius: 22,
          backgroundColor: "rgba(255,255,255,0.2)",
          alignItems: "center",
          justifyContent: "center",
        }}
      >
        <Ionicons name="star" size={22} color="#FFD166" />
      </View>
      <View style={{ flex: 1 }}>
        <Text style={{ color: "#fff", fontSize: 15, fontWeight: "800" }}>Top Picks for You</Text>
        <Text style={{ color: "rgba(255,255,255,0.8)", fontSize: 12, marginTop: 2 }}>
          Curated profiles based on your preferences
        </Text>
      </View>
      <Ionicons name="chevron-forward" size={20} color="rgba(255,255,255,0.7)" />
    </LinearGradient>
  );
}

// ── Main screen ────────────────────────────────────────────────────────────────
export default function DiscoverScreen() {
  const { colors } = useTheme();
  const filteredUsers = useDiscoverFilters();
  const activeIntent  = useDiscoverStore((s) => s.activeIntentFilter);

  const onlineUsers      = filteredUsers.filter((u) => u.online).slice(0, 4);
  const recommendedUsers = filteredUsers.filter((u) => !u.online).slice(0, 4);
  const allOthers        = filteredUsers.slice(4);

  return (
    <View style={{ flex: 1, backgroundColor: colors.background }}>
      {/* Intent filter bar */}
      <IntentTabBar />

      <ScrollView
        showsVerticalScrollIndicator={false}
        contentContainerStyle={{ paddingBottom: 32 }}
      >
        {/* Snapshot / Boost banner */}
        <SnapshotBanner />

        {filteredUsers.length === 0 ? (
          <EmptyDiscover />
        ) : (
          <>
            {/* ── Recently Active ── */}
            {onlineUsers.length > 0 && (
              <View style={{ marginBottom: 8 }}>
                <SectionHeader title="Recently Active" />
                <View
                  style={{
                    flexDirection: "row",
                    flexWrap: "wrap",
                    paddingHorizontal: 16,
                    gap: 10,
                  }}
                >
                  {onlineUsers.map((user) => (
                    <MiniProfileCard key={user.id} user={user} />
                  ))}
                </View>
              </View>
            )}

            {/* ── Top Picks banner ── */}
            <TopPicksBanner />

            {/* ── Recommended ── */}
            {recommendedUsers.length > 0 && (
              <View style={{ marginBottom: 8 }}>
                <SectionHeader title="Recommended" onSeeMore={() => {}} />
                <View
                  style={{
                    flexDirection: "row",
                    flexWrap: "wrap",
                    paddingHorizontal: 16,
                    gap: 10,
                  }}
                >
                  {recommendedUsers.map((user) => (
                    <MiniProfileCard key={user.id} user={user} />
                  ))}
                </View>
              </View>
            )}

            {/* ── Divider + Full-size swipe cards ── */}
            {allOthers.length > 0 && (
              <View style={{ marginTop: 8 }}>
                <View
                  style={{
                    flexDirection: "row",
                    alignItems: "center",
                    paddingHorizontal: 16,
                    marginBottom: 14,
                    gap: 10,
                  }}
                >
                  <View style={{ flex: 1, height: 1, backgroundColor: colors.border }} />
                  <Text style={{ fontSize: 12, color: colors.textMuted, fontWeight: "700", letterSpacing: 0.5 }}>
                    EXPLORE ALL
                  </Text>
                  <View style={{ flex: 1, height: 1, backgroundColor: colors.border }} />
                </View>

                {/* Filter/toggle toolbar */}
                <DiscoverToolbar />

                {/* Full swipe cards */}
                <View style={{ alignItems: "center", paddingHorizontal: 16, gap: 4 }}>
                  {allOthers.map((user) => (
                    <DiscoverCard key={user.id} user={user} />
                  ))}
                </View>
              </View>
            )}

            {/* If we have all users in mini cards, still show toolbar + full cards for first few */}
            {allOthers.length === 0 && filteredUsers.length > 0 && (
              <View style={{ marginTop: 8 }}>
                <View
                  style={{
                    flexDirection: "row",
                    alignItems: "center",
                    paddingHorizontal: 16,
                    marginBottom: 14,
                    gap: 10,
                  }}
                >
                  <View style={{ flex: 1, height: 1, backgroundColor: colors.border }} />
                  <Text style={{ fontSize: 12, color: colors.textMuted, fontWeight: "700", letterSpacing: 0.5 }}>
                    SWIPE CARDS
                  </Text>
                  <View style={{ flex: 1, height: 1, backgroundColor: colors.border }} />
                </View>
                <DiscoverToolbar />
                <View style={{ alignItems: "center", paddingHorizontal: 16, gap: 4 }}>
                  {filteredUsers.slice(0, 3).map((user) => (
                    <DiscoverCard key={user.id} user={user} />
                  ))}
                </View>
              </View>
            )}
          </>
        )}
      </ScrollView>

      <FilterSheet />
    </View>
  );
}
