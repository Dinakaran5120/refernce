/** @type {import('tailwindcss').Config} */
module.exports = {
  content: ["./app/**/*.{js,jsx,ts,tsx}", "./components/**/*.{js,jsx,ts,tsx}"],
  presets: [require("nativewind/preset")],
  theme: {
    extend: {
      colors: {
        primary: {
          DEFAULT: "#E63946",
          light: "#FF5A66",
          dark: "#C0202E",
        },
        secondary: {
          DEFAULT: "#F7A1C4",
          light: "#FFC4DC",
          dark: "#E07AA0",
        },
        accent: {
          DEFAULT: "#FF8C6B",
          light: "#FFAA8A",
          dark: "#E06A48",
        },
        rose: "#FF6B9D",
        violet: "#B06BFF",
        sky: "#6BD4FF",
        gold: "#FFD166",
        background: "#FFF8F5",
        surface: "#FFFFFF",
        card: "#FFF0EC",
        border: "#F0D9D4",
        muted: "#9B8A87",
        text: {
          DEFAULT: "#2B2B2B",
          secondary: "#6B5E5B",
          muted: "#9B8A87",
          inverse: "#FFFFFF",
        },
      },
      fontFamily: {
        sans: ["System"],
      },
      borderRadius: {
        "4xl": "2rem",
        "5xl": "2.5rem",
      },
    },
  },
  plugins: [],
};
