import { useState } from "react";
import { View, Text, ScrollView, Pressable, TextInput, Dimensions } from "react-native";
import { LinearGradient } from "expo-linear-gradient";
import { Ionicons } from "@expo/vector-icons";
import { useTheme } from "@/context/ThemeContext";
import { useConnectionsStore } from "@/store/connectionsStore";
import { useSortedConversations, useTotalUnreadMessages, msgTimeAgo } from "@/hooks/useConnections";
import { ChatScreen } from "@components/connections/ChatScreen";
import { CallScreen } from "@components/connections/CallScreen";
import { CreateGroupModal } from "@components/connections/CreateGroupModal";
import type { Conversation } from "@/types/connections";

const { width: W } = Dimensions.get("window");

// ── Matches carousel ───────────────────────────────────────────────────────────
const MATCHES = [
  { id: "u1", name: "Arjun",  avatarEmoji: "😊", gradient: ["#F7A1C4","#FF6B9D"]  as [string,string], isNew: true  },
  { id: "u2", name: "Priya",  avatarEmoji: "🥰", gradient: ["#B06BFF","#6BD4FF"]  as [string,string], isNew: true  },
  { id: "u3", name: "Dev",    avatarEmoji: "😎", gradient: ["#E63946","#FF8C6B"]  as [string,string], isNew: false },
  { id: "u4", name: "Zara",   avatarEmoji: "🌈", gradient: ["#FF8C6B","#FFD166"]  as [string,string], isNew: true  },
  { id: "u5", name: "Riya",   avatarEmoji: "💫", gradient: ["#FF6B9D","#B06BFF"]  as [string,string], isNew: false },
  { id: "u6", name: "Karan",  avatarEmoji: "🏏", gradient: ["#6BD4FF","#6BFFB8"]  as [string,string], isNew: false },
];

function MatchesRow({ onOpenChat }: { onOpenChat: (convId: string) => void }) {
  const { colors } = useTheme();
  const conversations = useConnectionsStore((s) => s.conversations);

  return (
    <View style={{ paddingVertical: 4 }}>
      <ScrollView
        horizontal
        showsHorizontalScrollIndicator={false}
        contentContainerStyle={{ paddingHorizontal: 16, gap: 14, paddingVertical: 8 }}
      >
        {MATCHES.map((m) => {
          const conv = conversations.find((c) => c.type === "direct" && c.participants[0]?.id === m.id);
          return (
            <Pressable
              key={m.id}
              onPress={() => conv && onOpenChat(conv.id)}
              style={({ pressed }) => ({ alignItems: "center", gap: 6, opacity: pressed ? 0.7 : 1 })}
            >
              <View style={{ position: "relative" }}>
                {/* Gradient ring */}
                <LinearGradient
                  colors={m.isNew ? m.gradient : [colors.border, colors.card]}
                  start={{ x: 0, y: 0 }}
                  end={{ x: 1, y: 1 }}
                  style={{ width: 66, height: 66, borderRadius: 33, padding: 2.5 }}
                >
                  <View
                    style={{
                      flex: 1,
                      borderRadius: 30,
                      backgroundColor: colors.surface,
                      alignItems: "center",
                      justifyContent: "center",
                    }}
                  >
                    <Text style={{ fontSize: 28 }}>{m.avatarEmoji}</Text>
                  </View>
                </LinearGradient>
                {/* New indicator */}
                {m.isNew && (
                  <View
                    style={{
                      position: "absolute",
                      bottom: 1,
                      right: 1,
                      width: 16,
                      height: 16,
                      borderRadius: 8,
                      backgroundColor: colors.primary,
                      borderWidth: 2,
                      borderColor: colors.background,
                      alignItems: "center",
                      justifyContent: "center",
                    }}
                  >
                    <Text style={{ color: "#fff", fontSize: 8, fontWeight: "800" }}>!</Text>
                  </View>
                )}
              </View>
              <Text
                style={{ fontSize: 11, color: m.isNew ? colors.text : colors.textSecondary, fontWeight: m.isNew ? "700" : "500" }}
                numberOfLines={1}
              >
                {m.name}
              </Text>
            </Pressable>
          );
        })}
      </ScrollView>
    </View>
  );
}

// ── Conversation row ──────────────────────────────────────────────────────────
function ConvRow({ conv, onPress }: { conv: Conversation; onPress: () => void }) {
  const { colors } = useTheme();
  const isGroup   = conv.type === "group";
  const p         = conv.participants[0];
  const name      = isGroup ? (conv.groupName ?? "Group") : p?.name ?? "";
  const emoji     = isGroup ? (conv.groupEmoji ?? "👥") : p?.avatarEmoji ?? "👤";
  const grad      = (isGroup ? conv.groupGradient : p?.gradient) ?? [colors.primary, colors.accent] as [string,string];
  const isOnline  = !isGroup && p?.online;
  const isMine    = conv.lastSenderId === "me";
  const timeStr   = msgTimeAgo(conv.lastMessageTime);
  const hasUnread = conv.unreadCount > 0;

  return (
    <Pressable
      onPress={onPress}
      style={({ pressed }) => ({
        flexDirection: "row",
        alignItems: "center",
        paddingHorizontal: 16,
        paddingVertical: 13,
        gap: 12,
        backgroundColor: pressed ? colors.card : "transparent",
      })}
    >
      {/* Avatar */}
      <View style={{ position: "relative", flexShrink: 0 }}>
        <LinearGradient
          colors={grad}
          start={{ x: 0, y: 0 }}
          end={{ x: 1, y: 1 }}
          style={{
            width: 54,
            height: 54,
            borderRadius: 27,
            alignItems: "center",
            justifyContent: "center",
          }}
        >
          <Text style={{ fontSize: 26 }}>{emoji}</Text>
        </LinearGradient>
        {isOnline && (
          <View
            style={{
              position: "absolute",
              bottom: 1,
              right: 1,
              width: 14,
              height: 14,
              borderRadius: 7,
              backgroundColor: "#22c55e",
              borderWidth: 2,
              borderColor: colors.background,
            }}
          />
        )}
        {isGroup && (
          <View
            style={{
              position: "absolute",
              bottom: -2,
              right: -2,
              width: 18,
              height: 18,
              borderRadius: 9,
              backgroundColor: colors.violet,
              borderWidth: 2,
              borderColor: colors.surface,
              alignItems: "center",
              justifyContent: "center",
            }}
          >
            <Text style={{ color: "#fff", fontSize: 8, fontWeight: "800" }}>G</Text>
          </View>
        )}
      </View>

      {/* Content */}
      <View style={{ flex: 1, gap: 3 }}>
        <View style={{ flexDirection: "row", alignItems: "center", justifyContent: "space-between" }}>
          <Text
            style={{ fontSize: 15, fontWeight: hasUnread ? "800" : "600", color: colors.text }}
            numberOfLines={1}
          >
            {name}
          </Text>
          <Text style={{ fontSize: 12, color: hasUnread ? colors.primary : colors.textMuted, fontWeight: hasUnread ? "700" : "400" }}>
            {timeStr}
          </Text>
        </View>

        <View style={{ flexDirection: "row", alignItems: "center", justifyContent: "space-between", gap: 6 }}>
          <Text
            style={{
              fontSize: 13,
              color: conv.isTyping ? colors.primary : hasUnread ? colors.text : colors.textMuted,
              fontWeight: hasUnread ? "600" : "400",
              flex: 1,
              fontStyle: conv.isTyping ? "italic" : "normal",
            }}
            numberOfLines={1}
          >
            {conv.isTyping ? "typing…" : isMine ? `You: ${conv.lastMessage}` : conv.lastMessage}
          </Text>

          {hasUnread && (
            <LinearGradient
              colors={[colors.primary, colors.accent]}
              start={{ x: 0, y: 0 }}
              end={{ x: 1, y: 1 }}
              style={{
                minWidth: 22,
                height: 22,
                borderRadius: 11,
                alignItems: "center",
                justifyContent: "center",
                paddingHorizontal: 5,
              }}
            >
              <Text style={{ color: "#fff", fontSize: 11, fontWeight: "800" }}>{conv.unreadCount}</Text>
            </LinearGradient>
          )}

          {conv.isMuted && (
            <Ionicons name="volume-mute-outline" size={14} color={colors.textMuted} />
          )}
        </View>
      </View>
    </Pressable>
  );
}

// ── Main Screen ───────────────────────────────────────────────────────────────
export default function ConnectionsScreen() {
  const { colors } = useTheme();
  const activeConvId   = useConnectionsStore((s) => s.activeConversationId);
  const call           = useConnectionsStore((s) => s.call);
  const setActive      = useConnectionsStore((s) => s.setActiveConversation);

  const [activeTab, setActiveTab]   = useState<"messages" | "matches">("messages");
  const [search, setSearch]         = useState("");
  const [showCreate, setShowCreate] = useState(false);

  const sorted      = useSortedConversations(search);
  const totalUnread = useTotalUnreadMessages();

  const directConvs = sorted.filter((c) => c.type === "direct");
  const groupConvs  = sorted.filter((c) => c.type === "group");

  if (activeConvId) return <ChatScreen />;
  if (call) return <CallScreen />;

  return (
    <View style={{ flex: 1, backgroundColor: colors.background }}>

      {/* ── Tab switcher ── */}
      <View
        style={{
          flexDirection: "row",
          paddingHorizontal: 16,
          paddingTop: 14,
          paddingBottom: 10,
          gap: 10,
        }}
      >
        {(["messages", "matches"] as const).map((tab) => {
          const isActive = activeTab === tab;
          const label = tab === "messages"
            ? `Messages${totalUnread > 0 ? ` (${totalUnread})` : ""}`
            : "Matches 🔥";

          return (
            <Pressable key={tab} onPress={() => setActiveTab(tab)} style={{ flex: 1 }}>
              {isActive ? (
                <LinearGradient
                  colors={[colors.primary, colors.accent]}
                  start={{ x: 0, y: 0 }}
                  end={{ x: 1, y: 0 }}
                  style={{ paddingVertical: 11, borderRadius: 16, alignItems: "center" }}
                >
                  <Text style={{ color: "#fff", fontWeight: "800", fontSize: 14 }}>{label}</Text>
                </LinearGradient>
              ) : (
                <View
                  style={{
                    paddingVertical: 11,
                    borderRadius: 16,
                    alignItems: "center",
                    backgroundColor: colors.card,
                    borderWidth: 1,
                    borderColor: colors.border,
                  }}
                >
                  <Text style={{ color: colors.textMuted, fontWeight: "600", fontSize: 14 }}>{label}</Text>
                </View>
              )}
            </Pressable>
          );
        })}
      </View>

      {activeTab === "matches" ? (
        <MatchesRow onOpenChat={(id) => setActive(id)} />
      ) : (
        <ScrollView showsVerticalScrollIndicator={false}>

          {/* Search + new group */}
          <View
            style={{ flexDirection: "row", paddingHorizontal: 16, paddingBottom: 10, gap: 8 }}
          >
            <View
              style={{
                flex: 1,
                flexDirection: "row",
                alignItems: "center",
                backgroundColor: colors.inputBg,
                borderRadius: 14,
                paddingHorizontal: 12,
                paddingVertical: 10,
                borderWidth: 1,
                borderColor: colors.border,
                gap: 8,
              }}
            >
              <Ionicons name="search-outline" size={16} color={colors.textMuted} />
              <TextInput
                value={search}
                onChangeText={setSearch}
                placeholder="Search messages…"
                placeholderTextColor={colors.textMuted}
                style={{ flex: 1, fontSize: 14, color: colors.text, padding: 0 }}
              />
            </View>
            <Pressable
              onPress={() => setShowCreate(true)}
              style={({ pressed }) => ({ opacity: pressed ? 0.8 : 1 })}
            >
              <LinearGradient
                colors={[colors.violet, colors.sky]}
                start={{ x: 0, y: 0 }}
                end={{ x: 1, y: 1 }}
                style={{
                  width: 44,
                  height: 44,
                  borderRadius: 14,
                  alignItems: "center",
                  justifyContent: "center",
                }}
              >
                <Ionicons name="add" size={22} color="#fff" />
              </LinearGradient>
            </Pressable>
          </View>

          {/* Direct messages */}
          {directConvs.length > 0 && (
            <View style={{ marginBottom: 8 }}>
              <Text
                style={{
                  fontSize: 11,
                  fontWeight: "800",
                  color: colors.textMuted,
                  letterSpacing: 0.7,
                  paddingHorizontal: 16,
                  paddingTop: 6,
                  paddingBottom: 4,
                }}
              >
                DIRECT MESSAGES
              </Text>
              <View
                style={{
                  backgroundColor: colors.surface,
                  borderTopWidth: 1,
                  borderBottomWidth: 1,
                  borderColor: colors.border,
                }}
              >
                {directConvs.map((conv, i) => (
                  <View key={conv.id}>
                    <ConvRow conv={conv} onPress={() => setActive(conv.id)} />
                    {i < directConvs.length - 1 && (
                      <View style={{ height: 1, backgroundColor: colors.border, marginLeft: 82 }} />
                    )}
                  </View>
                ))}
              </View>
            </View>
          )}

          {/* Group chats */}
          {groupConvs.length > 0 && (
            <View style={{ marginBottom: 8 }}>
              <Text
                style={{
                  fontSize: 11,
                  fontWeight: "800",
                  color: colors.textMuted,
                  letterSpacing: 0.7,
                  paddingHorizontal: 16,
                  paddingTop: 6,
                  paddingBottom: 4,
                }}
              >
                GROUP CHATS
              </Text>
              <View
                style={{
                  backgroundColor: colors.surface,
                  borderTopWidth: 1,
                  borderBottomWidth: 1,
                  borderColor: colors.border,
                }}
              >
                {groupConvs.map((conv, i) => (
                  <View key={conv.id}>
                    <ConvRow conv={conv} onPress={() => setActive(conv.id)} />
                    {i < groupConvs.length - 1 && (
                      <View style={{ height: 1, backgroundColor: colors.border, marginLeft: 82 }} />
                    )}
                  </View>
                ))}
              </View>
            </View>
          )}

          {sorted.length === 0 && (
            <View style={{ alignItems: "center", paddingVertical: 56, gap: 12 }}>
              <View
                style={{
                  width: 72,
                  height: 72,
                  borderRadius: 36,
                  backgroundColor: colors.card,
                  alignItems: "center",
                  justifyContent: "center",
                  borderWidth: 1,
                  borderColor: colors.border,
                }}
              >
                <Ionicons name="chatbubbles-outline" size={32} color={colors.textMuted} />
              </View>
              <Text style={{ fontSize: 16, fontWeight: "700", color: colors.text }}>No conversations yet</Text>
              <Text style={{ fontSize: 13, color: colors.textMuted, textAlign: "center" }}>
                Match with someone to start chatting!
              </Text>
            </View>
          )}

          <View style={{ height: 32 }} />
        </ScrollView>
      )}

      <CreateGroupModal visible={showCreate} onClose={() => setShowCreate(false)} />
    </View>
  );
}
