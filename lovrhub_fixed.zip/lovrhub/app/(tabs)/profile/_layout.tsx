import { Stack } from "expo-router";

/**
 * Profile nested stack:
 * - index     → main profile tab (no extra header — tabs header handles it)
 * - edit      → slide in from right, own header
 * - settings  → slide in from right, own header
 * - notifications → slide in from right, own header
 */
export default function ProfileLayout() {
  return (
    <Stack screenOptions={{ headerShown: false, animation: "slide_from_right" }}>
      <Stack.Screen name="index"         options={{ animation: "none" }} />
      <Stack.Screen name="edit"          />
      <Stack.Screen name="settings"      />
      <Stack.Screen name="notifications" />
    </Stack>
  );
}
