import { View, Text, Pressable, ScrollView } from "react-native";
import { Colors } from "@constants/theme";
import { useExploreStore } from "@/store/exploreStore";
import { fmtCount } from "@/hooks/useExploreFeed";
import type { ExplorePost, VibeType } from "@/types/explore";

const VIBE_LABELS: Record<VibeType, string> = {
  "❤️": "Love",
  "😂": "Haha",
  "🔥": "Fire",
  "😮": "Wow",
  "💔": "Sad",
  "✨": "Magic",
};

export function VibeBar({ post }: { post: ExplorePost }) {
  const reactVibe       = useExploreStore((s) => s.reactVibe);
  const setShowComments = useExploreStore((s) => s.setShowComments);
  const sharePost       = useExploreStore((s) => s.sharePost);

  const totalVibes = post.vibes.reduce((s, v) => s + v.count, 0);
  const myReaction = post.vibes.find((v) => v.reacted);

  return (
    <View style={{ gap: 10 }}>
      {/* Vibe counts summary */}
      {totalVibes > 0 && (
        <View style={{ flexDirection: "row", alignItems: "center", paddingHorizontal: 16, gap: 6 }}>
          {post.vibes
            .filter((v) => v.count > 0)
            .slice(0, 4)
            .map((v) => (
              <Text key={v.emoji} style={{ fontSize: 14 }}>{v.emoji}</Text>
            ))}
          <Text style={{ fontSize: 13, color: Colors.textMuted, fontWeight: "600" }}>
            {fmtCount(totalVibes)} vibes
          </Text>
        </View>
      )}

      {/* Reaction row */}
      <View
        style={{
          flexDirection: "row",
          alignItems: "center",
          paddingHorizontal: 16,
          paddingBottom: 12,
          borderBottomWidth: 1,
          borderBottomColor: Colors.border,
          gap: 2,
        }}
      >
        {/* Vibe chips */}
        <ScrollView
          horizontal
          showsHorizontalScrollIndicator={false}
          contentContainerStyle={{ gap: 6, paddingRight: 8 }}
          style={{ flex: 1 }}
        >
          {post.vibes.map((v) => (
            <Pressable
              key={v.emoji}
              onPress={() => reactVibe(post.id, v.emoji as VibeType)}
              style={({ pressed }) => ({
                flexDirection: "row",
                alignItems: "center",
                gap: 4,
                paddingHorizontal: 10,
                paddingVertical: 6,
                borderRadius: 16,
                backgroundColor: v.reacted ? Colors.primary + "18" : Colors.card,
                borderWidth: 1.5,
                borderColor: v.reacted ? Colors.primary : Colors.border,
                opacity: pressed ? 0.7 : 1,
                transform: [{ scale: pressed ? 0.92 : 1 }],
              })}
            >
              <Text style={{ fontSize: 15 }}>{v.emoji}</Text>
              {v.count > 0 && (
                <Text
                  style={{
                    fontSize: 12,
                    fontWeight: "700",
                    color: v.reacted ? Colors.primary : Colors.textMuted,
                  }}
                >
                  {fmtCount(v.count)}
                </Text>
              )}
            </Pressable>
          ))}
        </ScrollView>

        {/* Comment + Share */}
        <Pressable
          onPress={() => setShowComments(post.id)}
          style={({ pressed }) => ({
            flexDirection: "row", alignItems: "center", gap: 5,
            paddingHorizontal: 12, paddingVertical: 6, borderRadius: 16,
            backgroundColor: Colors.card, borderWidth: 1, borderColor: Colors.border,
            opacity: pressed ? 0.7 : 1,
          })}
        >
          <Text style={{ fontSize: 15 }}>💬</Text>
          {post.comments.length > 0 && (
            <Text style={{ fontSize: 12, fontWeight: "700", color: Colors.textMuted }}>
              {fmtCount(post.comments.length)}
            </Text>
          )}
        </Pressable>

        <Pressable
          onPress={() => sharePost(post.id)}
          style={({ pressed }) => ({
            flexDirection: "row", alignItems: "center", gap: 5,
            paddingHorizontal: 12, paddingVertical: 6, borderRadius: 16,
            backgroundColor: Colors.card, borderWidth: 1, borderColor: Colors.border,
            opacity: pressed ? 0.7 : 1, marginLeft: 6,
          })}
        >
          <Text style={{ fontSize: 15 }}>↗️</Text>
          {post.shares > 0 && (
            <Text style={{ fontSize: 12, fontWeight: "700", color: Colors.textMuted }}>
              {fmtCount(post.shares)}
            </Text>
          )}
        </Pressable>
      </View>
    </View>
  );
}
