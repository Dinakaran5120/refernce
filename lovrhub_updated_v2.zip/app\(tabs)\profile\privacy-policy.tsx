import { View, Text, ScrollView, Pressable } from "react-native";
import { useRouter } from "expo-router";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import { Ionicons } from "@expo/vector-icons";
import { LinearGradient } from "expo-linear-gradient";
import { useTheme } from "@/context/ThemeContext";

const LAST_UPDATED = "January 1, 2025";

const SECTIONS = [
  {
    icon: "information-circle-outline" as const,
    title: "1. Introduction",
    body: `Welcome to Lovrhub ("we", "us", or "our"). We are committed to protecting your personal information and your right to privacy.\n\nThis Privacy Policy explains how we collect, use, disclose, and safeguard your information when you use our mobile application. Please read this policy carefully. If you disagree with its terms, please discontinue use of the app immediately.\n\nWe reserve the right to make changes to this Privacy Policy at any time. We will alert you about any changes by updating the "Last Updated" date.`,
  },
  {
    icon: "person-outline" as const,
    title: "2. Information We Collect",
    body: `We collect information that you voluntarily provide when registering, creating a profile, or using our services:\n\n• Personal Identifiers: name, email address, phone number, date of birth, gender identity, sexual orientation.\n\n• Profile Information: photos or avatar, bio, interests, relationship goals, languages spoken.\n\n• Location Data: precise GPS location (only when the app is in use) to show nearby profiles and calculate distances.\n\n• Communications: messages sent through the app (end-to-end encrypted in transit).\n\n• Device & Usage Data: device ID, OS version, app interactions, crash reports, and performance analytics.\n\n• Payment Data: if you subscribe to premium plans, payment is processed by a third-party processor (Stripe/Google Pay/Apple Pay). We do not store full card details.`,
  },
  {
    icon: "shield-outline" as const,
    title: "3. How We Use Your Information",
    body: `We use the information we collect or receive to:\n\n• Create and manage your account.\n• Match you with other users based on preferences, location, and intent.\n• Send push notifications (with your consent).\n• Personalise your experience and improve our recommendation algorithms.\n• Ensure safety and moderate content to enforce our Community Guidelines.\n• Prevent fraud, abuse, and other prohibited activities.\n• Comply with legal obligations.\n• Communicate service updates, security alerts, and support messages.\n\nWe will never sell your personal data to third-party advertisers.`,
  },
  {
    icon: "share-social-outline" as const,
    title: "4. Sharing Your Information",
    body: `We may share your information in the following limited circumstances:\n\n• With Other Users: Your profile, photos, bio, age, location distance, and intent badges are visible to other users in accordance with your privacy settings.\n\n• Service Providers: We share data with trusted vendors who assist us in operating the app (cloud hosting, analytics, customer support), all bound by confidentiality agreements.\n\n• Legal Compliance: We may disclose information if required by law, court order, or to protect the rights and safety of our users.\n\n• Business Transfers: If Lovrhub is acquired or merges with another entity, your information may be transferred as part of that deal.\n\n• With Your Consent: We may share data for purposes not listed above if you give us explicit consent.`,
  },
  {
    icon: "location-outline" as const,
    title: "5. Location Data",
    body: `Location is central to Lovrhub's discovery features. We collect your precise location only when the app is open and active ("foreground" access only).\n\n• You can disable location at any time via your device settings. Disabling location will limit discovery features.\n• We show other users only your approximate distance (e.g., "2 km away"), never your exact coordinates.\n• Location history is not stored beyond 30 days on our servers.`,
  },
  {
    icon: "heart-outline" as const,
    title: "6. Sensitive Personal Data",
    body: `Lovrhub is an inclusive platform welcoming all sexual orientations and gender identities. You may voluntarily share sensitive information such as:\n\n• Sexual orientation and gender identity\n• Relationship type preferences\n• Health-related preferences\n\nThis data is processed only to provide the core matchmaking service and is never used for advertising. You may update or delete this information at any time from your profile settings.`,
  },
  {
    icon: "lock-closed-outline" as const,
    title: "7. Data Security",
    body: `We implement industry-standard security measures to protect your information:\n\n• TLS 1.3 encryption for all data in transit.\n• AES-256 encryption for sensitive data at rest.\n• Messages are encrypted in transit and stored encrypted.\n• Regular third-party security audits and penetration testing.\n• Access to user data is restricted to authorised personnel only.\n\nDespite these measures, no method of transmission over the internet is 100% secure. If you suspect a security breach, contact us immediately at security@lovrhub.app.`,
  },
  {
    icon: "time-outline" as const,
    title: "8. Data Retention",
    body: `We retain your personal data for as long as your account is active or as needed to provide services.\n\n• Profile data is deleted within 30 days of account deletion.\n• Chat messages are deleted within 14 days of account deletion.\n• Aggregated, anonymised analytics data may be retained indefinitely.\n• Legal hold exceptions apply where we are required by law to retain data longer.`,
  },
  {
    icon: "people-outline" as const,
    title: "9. Children's Privacy",
    body: `Lovrhub is strictly for users aged 18 and over. We do not knowingly collect personal information from anyone under 18 years of age.\n\nIf we become aware that a user under 18 has created an account, we will immediately suspend and delete their account and all associated data.\n\nIf you believe a minor is using our platform, please report it to safety@lovrhub.app.`,
  },
  {
    icon: "hand-left-outline" as const,
    title: "10. Your Rights",
    body: `Depending on your location, you may have the following rights regarding your personal data:\n\n• Access: Request a copy of the data we hold about you.\n• Correction: Update inaccurate or incomplete data.\n• Deletion ("Right to be Forgotten"): Request deletion of your account and all personal data.\n• Portability: Receive your data in a machine-readable format.\n• Objection: Object to processing based on legitimate interests.\n• Withdraw Consent: Withdraw consent at any time without affecting prior processing.\n\nTo exercise these rights, go to Settings → Account Actions → Delete Account, or email privacy@lovrhub.app.`,
  },
  {
    icon: "globe-outline" as const,
    title: "11. International Transfers",
    body: `Lovrhub is headquartered in India and our servers are located in India and the EU. If you access our service from outside these regions, your information may be transferred to, stored, and processed in India or the EU.\n\nWe ensure appropriate safeguards (Standard Contractual Clauses or equivalent) are in place for international data transfers in compliance with applicable laws including GDPR and India's DPDP Act 2023.`,
  },
  {
    icon: "megaphone-outline" as const,
    title: "12. Cookies & Tracking",
    body: `Our mobile app does not use browser cookies. However, we use mobile analytics SDKs and device identifiers (with your consent) to:\n\n• Understand how users interact with the app.\n• Diagnose technical issues.\n• Measure the effectiveness of new features.\n\nYou may opt out of analytics tracking in Settings → Privacy & Location.`,
  },
  {
    icon: "mail-outline" as const,
    title: "13. Contact Us",
    body: `If you have questions, concerns, or requests regarding this Privacy Policy or our data practices, please contact our Data Protection Officer:\n\nEmail: privacy@lovrhub.app\nSafety: safety@lovrhub.app\nGeneral: hello@lovrhub.app\n\nLovrhub Technologies Pvt. Ltd.\nMumbai, Maharashtra, India — 400001\n\nWe aim to respond to all privacy requests within 30 days.`,
  },
];

export default function PrivacyPolicyScreen() {
  const router  = useRouter();
  const insets  = useSafeAreaInsets();
  const { colors } = useTheme();

  return (
    <View style={{ flex: 1, backgroundColor: colors.background }}>
      {/* Header */}
      <View
        style={{
          paddingTop: insets.top,
          backgroundColor: colors.surface,
          borderBottomWidth: 1,
          borderBottomColor: colors.border,
        }}
      >
        <View
          style={{
            height: 56,
            flexDirection: "row",
            alignItems: "center",
            paddingHorizontal: 16,
            gap: 12,
          }}
        >
          <Pressable
            onPress={() => router.back()}
            hitSlop={10}
            style={({ pressed }) => ({
              opacity: pressed ? 0.6 : 1,
              width: 34, height: 34, borderRadius: 10,
              backgroundColor: colors.card,
              alignItems: "center", justifyContent: "center",
              borderWidth: 1, borderColor: colors.border,
            })}
          >
            <Ionicons name="chevron-back" size={20} color={colors.text} />
          </Pressable>
          <View style={{ flex: 1 }}>
            <Text style={{ fontSize: 17, fontWeight: "800", color: colors.text }}>Privacy Policy</Text>
          </View>
        </View>
      </View>

      <ScrollView
        showsVerticalScrollIndicator={false}
        contentContainerStyle={{ paddingBottom: 48 }}
      >
        {/* Hero banner */}
        <LinearGradient
          colors={[colors.primary, colors.accent]}
          start={{ x: 0, y: 0 }}
          end={{ x: 1, y: 1 }}
          style={{ padding: 24, gap: 8 }}
        >
          <View
            style={{
              width: 56, height: 56, borderRadius: 18,
              backgroundColor: "rgba(255,255,255,0.2)",
              alignItems: "center", justifyContent: "center",
              marginBottom: 8,
            }}
          >
            <Ionicons name="shield-checkmark" size={30} color="#fff" />
          </View>
          <Text style={{ color: "#fff", fontSize: 22, fontWeight: "900", letterSpacing: -0.5 }}>
            Your Privacy Matters
          </Text>
          <Text style={{ color: "rgba(255,255,255,0.85)", fontSize: 13, lineHeight: 20 }}>
            We are committed to being transparent about how we collect, use, and protect your data.
          </Text>
          <View
            style={{
              backgroundColor: "rgba(255,255,255,0.2)",
              paddingHorizontal: 12, paddingVertical: 5,
              borderRadius: 10, alignSelf: "flex-start", marginTop: 4,
            }}
          >
            <Text style={{ color: "#fff", fontSize: 12, fontWeight: "600" }}>
              Last updated: {LAST_UPDATED}
            </Text>
          </View>
        </LinearGradient>

        {/* Quick summary pills */}
        <View style={{ padding: 16, gap: 8 }}>
          <Text style={{ fontSize: 13, fontWeight: "700", color: colors.textMuted, letterSpacing: 0.5 }}>
            KEY COMMITMENTS
          </Text>
          <View style={{ flexDirection: "row", flexWrap: "wrap", gap: 8 }}>
            {[
              { icon: "ban-outline" as const,           label: "No Selling Data" },
              { icon: "lock-closed-outline" as const,   label: "End-to-End Encrypted" },
              { icon: "person-outline" as const,        label: "18+ Only" },
              { icon: "eye-off-outline" as const,       label: "Location Private" },
              { icon: "trash-outline" as const,         label: "Right to Delete" },
              { icon: "rainbow-outline" as const,       label: "LGBTQ+ Safe" },
            ].map((item) => (
              <View
                key={item.label}
                style={{
                  flexDirection: "row",
                  alignItems: "center",
                  gap: 6,
                  paddingHorizontal: 12,
                  paddingVertical: 7,
                  borderRadius: 14,
                  backgroundColor: colors.card,
                  borderWidth: 1,
                  borderColor: colors.border,
                }}
              >
                <Ionicons name={item.icon} size={14} color={colors.primary} />
                <Text style={{ fontSize: 12, fontWeight: "600", color: colors.textSecondary }}>{item.label}</Text>
              </View>
            ))}
          </View>
        </View>

        {/* Policy sections */}
        <View style={{ paddingHorizontal: 16, gap: 4 }}>
          {SECTIONS.map((section) => (
            <View
              key={section.title}
              style={{
                backgroundColor: colors.surface,
                borderRadius: 16,
                padding: 16,
                marginBottom: 10,
                borderWidth: 1,
                borderColor: colors.border,
                gap: 10,
              }}
            >
              <View style={{ flexDirection: "row", alignItems: "center", gap: 10 }}>
                <View
                  style={{
                    width: 36, height: 36, borderRadius: 10,
                    backgroundColor: colors.primary + "18",
                    alignItems: "center", justifyContent: "center",
                    borderWidth: 1, borderColor: colors.primary + "33",
                  }}
                >
                  <Ionicons name={section.icon} size={18} color={colors.primary} />
                </View>
                <Text style={{ fontSize: 14, fontWeight: "800", color: colors.text, flex: 1 }}>
                  {section.title}
                </Text>
              </View>
              <Text style={{ fontSize: 13, color: colors.textSecondary, lineHeight: 21 }}>
                {section.body}
              </Text>
            </View>
          ))}
        </View>

        {/* Footer */}
        <View style={{ paddingHorizontal: 16, paddingTop: 8, gap: 12 }}>
          <View
            style={{
              backgroundColor: colors.card,
              borderRadius: 16,
              padding: 16,
              borderWidth: 1,
              borderColor: colors.border,
              gap: 8,
            }}
          >
            <Text style={{ fontSize: 13, fontWeight: "700", color: colors.text }}>Questions about this policy?</Text>
            <Text style={{ fontSize: 13, color: colors.textMuted, lineHeight: 20 }}>
              Contact our Data Protection Officer at{" "}
              <Text style={{ color: colors.primary, fontWeight: "600" }}>privacy@lovrhub.app</Text>
            </Text>
          </View>
          <Text style={{ textAlign: "center", fontSize: 12, color: colors.textMuted }}>
            © 2025 Lovrhub Technologies Pvt. Ltd.
          </Text>
        </View>
      </ScrollView>
    </View>
  );
}
