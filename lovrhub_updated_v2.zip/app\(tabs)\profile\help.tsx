import { useState } from "react";
import { View, Text, ScrollView, Pressable, TextInput, Linking } from "react-native";
import { useRouter } from "expo-router";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import { Ionicons } from "@expo/vector-icons";
import { LinearGradient } from "expo-linear-gradient";
import { useTheme } from "@/context/ThemeContext";

type IoniconsName = React.ComponentProps<typeof Ionicons>["name"];

const CATEGORIES: { id: string; icon: IoniconsName; label: string; color: string }[] = [
  { id: "account",    icon: "person-circle-outline",     label: "Account",       color: "#E63946" },
  { id: "matching",   icon: "heart-outline",             label: "Matching",      color: "#FF6B9D" },
  { id: "safety",     icon: "shield-checkmark-outline",  label: "Safety",        color: "#22c55e" },
  { id: "payments",   icon: "card-outline",              label: "Payments",      color: "#FFD166" },
  { id: "privacy",    icon: "lock-closed-outline",       label: "Privacy",       color: "#B06BFF" },
  { id: "technical",  icon: "construct-outline",         label: "Technical",     color: "#6BD4FF" },
];

const FAQS: { q: string; a: string; category: string }[] = [
  // Account
  { category: "account", q: "How do I create an account?", a: "Download Lovrhub, tap 'Continue with Phone' or 'Continue with Email', enter your details and complete the 9-step profile setup. You must be 18 or older to create an account." },
  { category: "account", q: "How do I delete my account?", a: "Go to Profile → Settings → Account Actions → Delete Account. Your profile and data will be permanently removed within 30 days. This action cannot be undone." },
  { category: "account", q: "I forgot my password. What do I do?", a: "On the login screen, tap 'Forgot Password' and enter your registered email or phone number. We'll send a reset link or OTP. Check your spam folder if you don't see it." },
  { category: "account", q: "How do I change my phone number?", a: "Go to Profile → Settings → Account → Phone Number. You will need to verify your new number with a one-time passcode (OTP)." },
  // Matching
  { category: "matching", q: "How does Lovrhub matching work?", a: "Lovrhub uses your intent (Dating, Friends, LGBTQ+, etc.), location, age range, interests, and mutual connections to suggest compatible profiles. Swipe right or tap ❤️ to like. A match happens when both people like each other." },
  { category: "matching", q: "What is a Super Like?", a: "A Super Like (⭐) lets someone know you're especially interested. They'll see you've super-liked them before they decide to like or pass on you. Free users get 1 Super Like per day; premium users get unlimited." },
  { category: "matching", q: "How do I undo a pass (swipe left)?", a: "Tap the ↩ Rewind button at the bottom of the discover screen. Free users get 1 rewind per day. Upgrade to Lovrhub Gold for unlimited rewinds." },
  { category: "matching", q: "Why are my matches disappearing?", a: "A match is removed if the other person unmatches you, deletes their account, or if either party blocks the other. You can report profiles that violate our guidelines." },
  // Safety
  { category: "safety", q: "How do I report someone?", a: "On any profile card or chat, tap the ⋮ menu → 'Report'. Choose a reason (harassment, fake profile, underage, inappropriate content, etc.) and submit. Our moderation team reviews reports within 24 hours." },
  { category: "safety", q: "How do I block someone?", a: "Open the chat or profile → tap ⋮ → 'Block'. The person won't be able to see your profile or message you. Blocking is confidential — they won't be notified." },
  { category: "safety", q: "Is Lovrhub safe for LGBTQ+ users?", a: "Absolutely. Lovrhub is built to be inclusive and safe for all gender identities and sexual orientations. You control what you share on your profile. We have a zero-tolerance policy for discrimination and harassment. Our Safety Centre has dedicated resources for LGBTQ+ users." },
  { category: "safety", q: "What should I do before meeting someone in person?", a: "• Tell a trusted friend or family member where you're going.\n• Meet in a public place for the first few dates.\n• Arrange your own transport.\n• Share your live location with someone you trust.\n• Video chat first to verify the person is who they say they are.\n• Trust your instincts — if something feels off, leave." },
  // Payments
  { category: "payments", q: "What does Lovrhub Gold include?", a: "Lovrhub Gold unlocks: unlimited likes, unlimited rewinds, see who liked you, 5 Super Likes/day, profile boost once per month, advanced filters, and ad-free experience. Plans start from ₹399/month." },
  { category: "payments", q: "How do I cancel my subscription?", a: "iOS: Settings app → Apple ID → Subscriptions → Lovrhub → Cancel.\nAndroid: Play Store → Menu → Subscriptions → Lovrhub → Cancel.\nCancellation takes effect at the end of your current billing period." },
  { category: "payments", q: "Can I get a refund?", a: "Subscriptions are generally non-refundable. However, if you believe you were charged in error, email billing@lovrhub.app with your transaction ID within 14 days of the charge." },
  // Privacy
  { category: "privacy", q: "Who can see my profile?", a: "By default, your profile is visible to all users in your discovery range. You can set your profile to 'Private' in Settings → Privacy → Private Profile, which requires others to send a request before viewing your full profile." },
  { category: "privacy", q: "Does Lovrhub sell my data?", a: "No. We never sell your personal data to third parties or advertisers. See our Privacy Policy for full details on how we use your information." },
  { category: "privacy", q: "Can I hide my online status?", a: "Yes. Go to Settings → Privacy & Location → Show Online Status and toggle it off. Others will not see when you were last active." },
  // Technical
  { category: "technical", q: "The app keeps crashing. What do I do?", a: "Try these steps:\n1. Force-close the app and reopen it.\n2. Check for app updates in the App Store / Play Store.\n3. Restart your device.\n4. Uninstall and reinstall the app (your account data is saved).\n5. If the issue persists, email support@lovrhub.app with your device model and OS version." },
  { category: "technical", q: "My messages are not sending. What's wrong?", a: "Check your internet connection. If you're on a slow connection, messages may be queued. Also verify the other person hasn't unmatched or blocked you — in that case you'll no longer be able to send messages." },
  { category: "technical", q: "How do I update the app?", a: "Open the App Store (iOS) or Google Play Store (Android), search for Lovrhub, and tap Update if available. We recommend enabling auto-updates to always have the latest security patches and features." },
];

const CONTACT_OPTIONS: { icon: IoniconsName; label: string; desc: string; action: string; color: string }[] = [
  { icon: "mail-outline",       label: "Email Support",   desc: "support@lovrhub.app",       action: "mailto:support@lovrhub.app",  color: "#E63946" },
  { icon: "shield-outline",     label: "Safety Team",     desc: "safety@lovrhub.app",        action: "mailto:safety@lovrhub.app",   color: "#22c55e" },
  { icon: "lock-closed-outline",label: "Privacy Officer", desc: "privacy@lovrhub.app",       action: "mailto:privacy@lovrhub.app",  color: "#B06BFF" },
  { icon: "card-outline",       label: "Billing",         desc: "billing@lovrhub.app",       action: "mailto:billing@lovrhub.app",  color: "#FFD166" },
];

function AccordionItem({ faq }: { faq: { q: string; a: string } }) {
  const [open, setOpen] = useState(false);
  const { colors } = useTheme();

  return (
    <View
      style={{
        backgroundColor: colors.surface,
        borderRadius: 14,
        marginBottom: 8,
        overflow: "hidden",
        borderWidth: 1,
        borderColor: open ? colors.primary + "44" : colors.border,
      }}
    >
      <Pressable
        onPress={() => setOpen((v) => !v)}
        style={({ pressed }) => ({
          flexDirection: "row",
          alignItems: "center",
          padding: 16,
          gap: 12,
          backgroundColor: pressed ? colors.card : "transparent",
        })}
      >
        <Text style={{ flex: 1, fontSize: 14, fontWeight: "600", color: colors.text, lineHeight: 20 }}>
          {faq.q}
        </Text>
        <Ionicons
          name={open ? "chevron-up" : "chevron-down"}
          size={16}
          color={open ? colors.primary : colors.textMuted}
        />
      </Pressable>
      {open && (
        <View
          style={{
            paddingHorizontal: 16,
            paddingBottom: 16,
            borderTopWidth: 1,
            borderTopColor: colors.border,
          }}
        >
          <Text style={{ fontSize: 13, color: colors.textSecondary, lineHeight: 21, marginTop: 12 }}>
            {faq.a}
          </Text>
        </View>
      )}
    </View>
  );
}

export default function HelpScreen() {
  const router   = useRouter();
  const insets   = useSafeAreaInsets();
  const { colors } = useTheme();

  const [activeCategory, setActiveCategory] = useState("account");
  const [search, setSearch]                 = useState("");

  const filteredFAQs = FAQS.filter((f) => {
    const matchesCategory = f.category === activeCategory;
    const matchesSearch   = search.trim()
      ? f.q.toLowerCase().includes(search.toLowerCase()) || f.a.toLowerCase().includes(search.toLowerCase())
      : true;
    return search.trim() ? matchesSearch : matchesCategory;
  });

  return (
    <View style={{ flex: 1, backgroundColor: colors.background }}>
      {/* Header */}
      <View
        style={{
          paddingTop: insets.top,
          backgroundColor: colors.surface,
          borderBottomWidth: 1,
          borderBottomColor: colors.border,
        }}
      >
        <View
          style={{
            height: 56,
            flexDirection: "row",
            alignItems: "center",
            paddingHorizontal: 16,
            gap: 12,
          }}
        >
          <Pressable
            onPress={() => router.back()}
            hitSlop={10}
            style={({ pressed }) => ({
              opacity: pressed ? 0.6 : 1,
              width: 34, height: 34, borderRadius: 10,
              backgroundColor: colors.card,
              alignItems: "center", justifyContent: "center",
              borderWidth: 1, borderColor: colors.border,
            })}
          >
            <Ionicons name="chevron-back" size={20} color={colors.text} />
          </Pressable>
          <Text style={{ fontSize: 17, fontWeight: "800", color: colors.text }}>Help Centre</Text>
        </View>
      </View>

      <ScrollView showsVerticalScrollIndicator={false} contentContainerStyle={{ paddingBottom: 48 }}>

        {/* Hero */}
        <LinearGradient
          colors={[colors.violet, colors.rose]}
          start={{ x: 0, y: 0 }}
          end={{ x: 1, y: 1 }}
          style={{ padding: 24, gap: 8 }}
        >
          <View
            style={{
              width: 56, height: 56, borderRadius: 18,
              backgroundColor: "rgba(255,255,255,0.2)",
              alignItems: "center", justifyContent: "center",
              marginBottom: 6,
            }}
          >
            <Ionicons name="help-buoy" size={30} color="#fff" />
          </View>
          <Text style={{ color: "#fff", fontSize: 22, fontWeight: "900", letterSpacing: -0.5 }}>
            How can we help?
          </Text>
          <Text style={{ color: "rgba(255,255,255,0.85)", fontSize: 13, lineHeight: 20 }}>
            Find answers to common questions or get in touch with our support team.
          </Text>
        </LinearGradient>

        {/* Search */}
        <View style={{ padding: 16 }}>
          <View
            style={{
              flexDirection: "row",
              alignItems: "center",
              backgroundColor: colors.inputBg,
              borderRadius: 16,
              paddingHorizontal: 14,
              paddingVertical: 12,
              borderWidth: 1,
              borderColor: colors.border,
              gap: 10,
            }}
          >
            <Ionicons name="search-outline" size={18} color={colors.textMuted} />
            <TextInput
              value={search}
              onChangeText={setSearch}
              placeholder="Search help articles…"
              placeholderTextColor={colors.textMuted}
              style={{ flex: 1, fontSize: 14, color: colors.text, padding: 0 }}
            />
            {search.length > 0 && (
              <Pressable onPress={() => setSearch("")}>
                <Ionicons name="close-circle" size={18} color={colors.textMuted} />
              </Pressable>
            )}
          </View>
        </View>

        {/* Category chips */}
        {search.trim() === "" && (
          <ScrollView
            horizontal
            showsHorizontalScrollIndicator={false}
            contentContainerStyle={{ paddingHorizontal: 16, gap: 10, paddingBottom: 4 }}
            style={{ marginBottom: 16 }}
          >
            {CATEGORIES.map((cat) => {
              const isActive = activeCategory === cat.id;
              return (
                <Pressable
                  key={cat.id}
                  onPress={() => setActiveCategory(cat.id)}
                  style={{
                    flexDirection: "row",
                    alignItems: "center",
                    gap: 6,
                    paddingHorizontal: 14,
                    paddingVertical: 9,
                    borderRadius: 14,
                    backgroundColor: isActive ? cat.color + "22" : colors.card,
                    borderWidth: 1.5,
                    borderColor: isActive ? cat.color : colors.border,
                  }}
                >
                  <Ionicons name={cat.icon} size={15} color={isActive ? cat.color : colors.textMuted} />
                  <Text style={{ fontSize: 13, fontWeight: "700", color: isActive ? cat.color : colors.textMuted }}>
                    {cat.label}
                  </Text>
                </Pressable>
              );
            })}
          </ScrollView>
        )}

        {/* FAQs */}
        <View style={{ paddingHorizontal: 16, marginBottom: 8 }}>
          {search.trim() !== "" && (
            <Text style={{ fontSize: 13, color: colors.textMuted, marginBottom: 12, fontWeight: "600" }}>
              {filteredFAQs.length} result{filteredFAQs.length !== 1 ? "s" : ""} for "{search}"
            </Text>
          )}
          {filteredFAQs.length === 0 ? (
            <View style={{ alignItems: "center", paddingVertical: 32, gap: 10 }}>
              <Ionicons name="search-outline" size={40} color={colors.textMuted} />
              <Text style={{ fontSize: 16, fontWeight: "700", color: colors.text }}>No results found</Text>
              <Text style={{ fontSize: 13, color: colors.textMuted, textAlign: "center" }}>
                Try different keywords or contact our support team below
              </Text>
            </View>
          ) : (
            filteredFAQs.map((faq, i) => <AccordionItem key={i} faq={faq} />)
          )}
        </View>

        {/* Contact options */}
        <View style={{ paddingHorizontal: 16, marginTop: 8 }}>
          <Text
            style={{
              fontSize: 11,
              fontWeight: "800",
              color: colors.textMuted,
              letterSpacing: 0.8,
              marginBottom: 12,
            }}
          >
            CONTACT US
          </Text>
          {CONTACT_OPTIONS.map((opt) => (
            <Pressable
              key={opt.label}
              onPress={() => Linking.openURL(opt.action).catch(() => {})}
              style={({ pressed }) => ({
                flexDirection: "row",
                alignItems: "center",
                gap: 14,
                backgroundColor: colors.surface,
                borderRadius: 16,
                padding: 14,
                marginBottom: 10,
                borderWidth: 1,
                borderColor: colors.border,
                opacity: pressed ? 0.7 : 1,
              })}
            >
              <View
                style={{
                  width: 42, height: 42, borderRadius: 13,
                  backgroundColor: opt.color + "18",
                  alignItems: "center", justifyContent: "center",
                  borderWidth: 1, borderColor: opt.color + "33",
                }}
              >
                <Ionicons name={opt.icon} size={20} color={opt.color} />
              </View>
              <View style={{ flex: 1 }}>
                <Text style={{ fontSize: 14, fontWeight: "700", color: colors.text }}>{opt.label}</Text>
                <Text style={{ fontSize: 13, color: colors.primary, marginTop: 2 }}>{opt.desc}</Text>
              </View>
              <Ionicons name="open-outline" size={16} color={colors.textMuted} />
            </Pressable>
          ))}
        </View>

        {/* Response time note */}
        <View style={{ paddingHorizontal: 16, marginTop: 4 }}>
          <View
            style={{
              backgroundColor: colors.card,
              borderRadius: 14,
              padding: 14,
              borderWidth: 1,
              borderColor: colors.border,
              flexDirection: "row",
              gap: 10,
              alignItems: "center",
            }}
          >
            <Ionicons name="time-outline" size={20} color={colors.gold} />
            <Text style={{ fontSize: 13, color: colors.textSecondary, flex: 1, lineHeight: 19 }}>
              Our support team typically responds within{" "}
              <Text style={{ fontWeight: "700", color: colors.text }}>24–48 hours</Text>.
              For urgent safety concerns, responses are prioritised.
            </Text>
          </View>
        </View>

        {/* Safety line */}
        <View style={{ paddingHorizontal: 16, marginTop: 12 }}>
          <LinearGradient
            colors={["#22c55e22", "#22c55e08"]}
            style={{ borderRadius: 14, padding: 14, borderWidth: 1, borderColor: "#22c55e44" }}
          >
            <View style={{ flexDirection: "row", gap: 10, alignItems: "flex-start" }}>
              <Ionicons name="shield-checkmark-outline" size={20} color="#22c55e" />
              <View style={{ flex: 1 }}>
                <Text style={{ fontSize: 13, fontWeight: "700", color: colors.text, marginBottom: 3 }}>
                  In immediate danger?
                </Text>
                <Text style={{ fontSize: 13, color: colors.textSecondary, lineHeight: 19 }}>
                  If you are in immediate danger, contact local emergency services (100 in India, 999 in UK, 911 in USA). Do not rely solely on the Lovrhub app.
                </Text>
              </View>
            </View>
          </LinearGradient>
        </View>

      </ScrollView>
    </View>
  );
}
