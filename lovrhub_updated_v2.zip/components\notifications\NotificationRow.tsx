import { useRef } from "react";
import {
  View, Text, Pressable, Animated,
  PanResponder, Dimensions,
} from "react-native";
import { LinearGradient } from "expo-linear-gradient";
import { Ionicons } from "@expo/vector-icons";
import { useTheme } from "@/context/ThemeContext";
import { useNotificationStore } from "@/store/notificationStore";
import { NOTIF_CONFIG, notifTimeAgo } from "@/hooks/useNotifications";
import type { Notification } from "@/types/notification";

const { width: W } = Dimensions.get("window");
const SWIPE_THRESHOLD = -W * 0.28;

export function NotificationRow({ notif }: { notif: Notification }) {
  const { colors } = useTheme();
  const markRead    = useNotificationStore((s) => s.markRead);
  const deleteNotif = useNotificationStore((s) => s.deleteNotif);

  const config  = NOTIF_CONFIG[notif.type];
  const timeAgo = notifTimeAgo(notif.createdAt);

  // Swipe-to-delete via PanResponder
  const translateX = useRef(new Animated.Value(0)).current;
  const rowOpacity = useRef(new Animated.Value(1)).current;

  const panResponder = useRef(
    PanResponder.create({
      onMoveShouldSetPanResponder: (_, g) => Math.abs(g.dx) > 8 && Math.abs(g.dy) < 20,
      onPanResponderMove: (_, g) => {
        if (g.dx < 0) translateX.setValue(g.dx);
      },
      onPanResponderRelease: (_, g) => {
        if (g.dx < SWIPE_THRESHOLD) {
          Animated.parallel([
            Animated.timing(translateX, { toValue: -W, duration: 220, useNativeDriver: true }),
            Animated.timing(rowOpacity, { toValue: 0, duration: 220, useNativeDriver: true }),
          ]).start(() => deleteNotif(notif.id));
        } else {
          Animated.spring(translateX, { toValue: 0, useNativeDriver: true, stiffness: 300, damping: 25 }).start();
        }
      },
    })
  ).current;

  const handlePress = () => {
    if (!notif.read) markRead(notif.id);
  };

  return (
    <View style={{ overflow: "hidden" }}>
      {/* Delete background revealed on swipe */}
      <View
        style={{
          position: "absolute", top: 0, right: 0, bottom: 0, width: 80,
          backgroundColor: colors.primary,
          alignItems: "center", justifyContent: "center",
        }}
      >
        <Ionicons name="trash-outline" size={22} color="#fff" />
        <Text style={{ color: "#fff", fontSize: 11, fontWeight: "700", marginTop: 2 }}>Delete</Text>
      </View>

      <Animated.View
        style={{ transform: [{ translateX }], opacity: rowOpacity }}
        {...panResponder.panHandlers}
      >
        <Pressable
          onPress={handlePress}
          style={({ pressed }) => ({
            flexDirection: "row",
            alignItems: "flex-start",
            paddingHorizontal: 16,
            paddingVertical: 14,
            gap: 12,
            backgroundColor: notif.read ? colors.surface : colors.primary + "07",
            borderBottomWidth: 1,
            borderBottomColor: colors.border,
            opacity: pressed ? 0.85 : 1,
          })}
        >
          {/* Actor avatar + type icon badge */}
          <View style={{ position: "relative", flexShrink: 0 }}>
            {notif.actor ? (
              <LinearGradient
                colors={notif.actor.gradient}
                start={{ x: 0, y: 0 }} end={{ x: 1, y: 1 }}
                style={{ width: 48, height: 48, borderRadius: 24, alignItems: "center", justifyContent: "center" }}
              >
                <Text style={{ fontSize: 24 }}>{notif.actor.avatarEmoji}</Text>
              </LinearGradient>
            ) : (
              <LinearGradient
                colors={[colors.primary, colors.accent]}
                start={{ x: 0, y: 0 }} end={{ x: 1, y: 1 }}
                style={{ width: 48, height: 48, borderRadius: 24, alignItems: "center", justifyContent: "center" }}
              >
                <Ionicons name="flame" size={22} color="#fff" />
              </LinearGradient>
            )}

            {/* Type icon badge */}
            <View
              style={{
                position: "absolute", bottom: -2, right: -2,
                width: 20, height: 20, borderRadius: 10,
                backgroundColor: config.bgColor,
                borderWidth: 1.5, borderColor: colors.surface,
                alignItems: "center", justifyContent: "center",
              }}
            >
              <Text style={{ fontSize: 10 }}>{config.icon}</Text>
            </View>
          </View>

          {/* Content */}
          <View style={{ flex: 1, gap: 3 }}>
            <View style={{ flexDirection: "row", alignItems: "center", justifyContent: "space-between", gap: 8 }}>
              <Text
                style={{
                  fontSize: 13,
                  fontWeight: notif.read ? "500" : "700",
                  color: colors.text,
                  flex: 1,
                  lineHeight: 19,
                }}
                numberOfLines={2}
              >
                {config.label(notif)}
                {notif.actor?.verified && (
                  <Text style={{ color: "#3b82f6", fontSize: 11 }}> ✓</Text>
                )}
              </Text>
              <Text style={{ fontSize: 11, color: colors.textMuted, flexShrink: 0 }}>{timeAgo}</Text>
            </View>

            <Text
              style={{
                fontSize: 12,
                color: notif.read ? colors.textMuted : colors.textSecondary,
                lineHeight: 17,
              }}
              numberOfLines={2}
            >
              {config.body(notif)}
            </Text>

            {notif.communityName && (
              <View style={{ flexDirection: "row", alignItems: "center", gap: 4, marginTop: 3 }}>
                <Text style={{ fontSize: 12 }}>{notif.communityEmoji}</Text>
                <Text style={{ fontSize: 11, color: config.color, fontWeight: "700" }}>
                  {notif.communityName}
                </Text>
              </View>
            )}
          </View>

          {/* Unread dot */}
          {!notif.read && (
            <View
              style={{
                width: 9, height: 9, borderRadius: 4.5,
                backgroundColor: config.color,
                flexShrink: 0, marginTop: 5,
              }}
            />
          )}
        </Pressable>
      </Animated.View>
    </View>
  );
}
