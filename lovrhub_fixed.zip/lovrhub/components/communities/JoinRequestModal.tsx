import { View, Text, Modal, Pressable, TextInput, KeyboardAvoidingView, Platform } from "react-native";
import { LinearGradient } from "expo-linear-gradient";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import { Colors } from "@constants/theme";
import { useCommunityStore } from "@/store/communityStore";

export function JoinRequestModal() {
  const insets             = useSafeAreaInsets();
  const communityId        = useCommunityStore((s) => s.showJoinRequestModal);
  const communities        = useCommunityStore((s) => s.communities);
  const message            = useCommunityStore((s) => s.requestMessage);
  const setMessage         = useCommunityStore((s) => s.setRequestMessage);
  const sendJoinRequest    = useCommunityStore((s) => s.sendJoinRequest);
  const setShowJoinRequest = useCommunityStore((s) => s.setShowJoinRequest);

  const community = communities.find((c) => c.id === communityId);
  if (!community) return null;

  const handleSend = () => {
    sendJoinRequest(community.id, message);
  };

  return (
    <Modal
      visible={!!communityId}
      animationType="slide"
      presentationStyle="pageSheet"
      onRequestClose={() => setShowJoinRequest(null)}
    >
      <KeyboardAvoidingView
        style={{ flex: 1, backgroundColor: Colors.background }}
        behavior={Platform.OS === "ios" ? "padding" : "height"}
      >
        {/* Header */}
        <View
          style={{
            flexDirection: "row", alignItems: "center", justifyContent: "space-between",
            paddingHorizontal: 20, paddingTop: insets.top + 16, paddingBottom: 16,
            borderBottomWidth: 1, borderBottomColor: Colors.border,
            backgroundColor: Colors.surface,
          }}
        >
          <Pressable onPress={() => setShowJoinRequest(null)}>
            <Text style={{ fontSize: 15, color: Colors.textSecondary, fontWeight: "600" }}>Cancel</Text>
          </Pressable>
          <Text style={{ fontSize: 16, fontWeight: "800", color: Colors.text }}>Request to Join</Text>
          <Pressable
            onPress={handleSend}
            style={({ pressed }) => ({ opacity: pressed ? 0.7 : 1 })}
          >
            <LinearGradient
              colors={[Colors.primary, Colors.accent]}
              start={{ x: 0, y: 0 }} end={{ x: 1, y: 0 }}
              style={{ paddingHorizontal: 18, paddingVertical: 8, borderRadius: 14 }}
            >
              <Text style={{ color: "#fff", fontWeight: "800", fontSize: 14 }}>Send</Text>
            </LinearGradient>
          </Pressable>
        </View>

        <View style={{ padding: 24, gap: 20 }}>
          {/* Community preview */}
          <View
            style={{
              flexDirection: "row", alignItems: "center", gap: 14,
              padding: 16, borderRadius: 18,
              backgroundColor: Colors.surface,
              borderWidth: 1, borderColor: Colors.border,
            }}
          >
            <LinearGradient
              colors={community.coverGradient}
              start={{ x: 0, y: 0 }} end={{ x: 1, y: 1 }}
              style={{ width: 52, height: 52, borderRadius: 16, alignItems: "center", justifyContent: "center" }}
            >
              <Text style={{ fontSize: 26 }}>{community.coverEmoji}</Text>
            </LinearGradient>
            <View style={{ flex: 1, gap: 3 }}>
              <Text style={{ fontSize: 15, fontWeight: "800", color: Colors.text }}>{community.name}</Text>
              <View style={{ flexDirection: "row", alignItems: "center", gap: 6 }}>
                <Text style={{ fontSize: 12, color: Colors.textMuted }}>🔒 Private</Text>
                <Text style={{ fontSize: 10, color: Colors.border }}>·</Text>
                <Text style={{ fontSize: 12, color: Colors.textMuted }}>
                  {community.memberCount.toLocaleString()} members
                </Text>
              </View>
            </View>
          </View>

          {/* Info */}
          <View
            style={{
              flexDirection: "row", alignItems: "flex-start", gap: 12,
              padding: 14, borderRadius: 14,
              backgroundColor: Colors.violet + "14",
              borderWidth: 1, borderColor: Colors.violet + "33",
            }}
          >
            <Text style={{ fontSize: 18 }}>ℹ️</Text>
            <Text style={{ fontSize: 13, color: Colors.textSecondary, lineHeight: 19, flex: 1 }}>
              This is a private community. The owner will review your request. Let them know why you'd like to join.
            </Text>
          </View>

          {/* Message input */}
          <View style={{ gap: 8 }}>
            <Text style={{ fontSize: 13, fontWeight: "700", color: Colors.textSecondary, letterSpacing: 0.3 }}>
              YOUR MESSAGE (optional)
            </Text>
            <TextInput
              value={message}
              onChangeText={setMessage}
              placeholder="Tell the owner why you'd like to join…"
              placeholderTextColor={Colors.textMuted}
              multiline
              numberOfLines={5}
              maxLength={300}
              style={{
                backgroundColor: Colors.surface,
                borderRadius: 16, borderWidth: 1, borderColor: Colors.border,
                padding: 14, fontSize: 15, color: Colors.text,
                lineHeight: 23, minHeight: 120, textAlignVertical: "top",
              }}
            />
            <Text style={{ fontSize: 11, color: Colors.textMuted, textAlign: "right" }}>
              {message.length}/300
            </Text>
          </View>

          {/* Rules reminder */}
          {community.rules.length > 0 && (
            <View style={{ gap: 10 }}>
              <Text style={{ fontSize: 13, fontWeight: "700", color: Colors.textSecondary, letterSpacing: 0.3 }}>
                COMMUNITY RULES
              </Text>
              <View
                style={{
                  backgroundColor: Colors.surface, borderRadius: 16,
                  borderWidth: 1, borderColor: Colors.border, overflow: "hidden",
                }}
              >
                {community.rules.map((rule, i) => (
                  <View
                    key={rule.id}
                    style={{
                      padding: 14, gap: 3,
                      borderBottomWidth: i < community.rules.length - 1 ? 1 : 0,
                      borderBottomColor: Colors.border,
                    }}
                  >
                    <Text style={{ fontSize: 13, fontWeight: "700", color: Colors.text }}>
                      {i + 1}. {rule.title}
                    </Text>
                    <Text style={{ fontSize: 12, color: Colors.textMuted, lineHeight: 17 }}>
                      {rule.description}
                    </Text>
                  </View>
                ))}
              </View>
            </View>
          )}
        </View>
      </KeyboardAvoidingView>
    </Modal>
  );
}
