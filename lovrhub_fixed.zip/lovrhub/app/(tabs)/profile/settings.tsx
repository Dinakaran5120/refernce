import {
  View, Text, ScrollView, Pressable, Switch,
} from "react-native";
import { useRouter } from "expo-router";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import { LinearGradient } from "expo-linear-gradient";
import { Colors } from "@constants/theme";
import { useAuthStore } from "@/store/authStore";
import { useNotificationStore } from "@/store/notificationStore";
import { useState } from "react";

function SettingsRow({
  emoji, label, subtitle, value, onToggle, onPress, danger = false, chevron = false,
}: {
  emoji: string; label: string; subtitle?: string;
  value?: boolean; onToggle?: () => void; onPress?: () => void;
  danger?: boolean; chevron?: boolean;
}) {
  return (
    <Pressable
      onPress={onPress}
      disabled={!onPress && !onToggle}
      style={({ pressed }) => ({
        flexDirection: "row", alignItems: "center", paddingHorizontal: 16, paddingVertical: 14,
        backgroundColor: pressed && onPress ? Colors.card : "transparent", gap: 12,
      })}
    >
      <View style={{
        width: 36, height: 36, borderRadius: 10,
        backgroundColor: danger ? Colors.primary + "18" : Colors.card,
        alignItems: "center", justifyContent: "center",
        borderWidth: 1, borderColor: danger ? Colors.primary + "33" : Colors.border,
      }}>
        <Text style={{ fontSize: 18 }}>{emoji}</Text>
      </View>
      <View style={{ flex: 1, gap: 2 }}>
        <Text style={{ fontSize: 14, fontWeight: "600", color: danger ? Colors.primary : Colors.text }}>
          {label}
        </Text>
        {subtitle && <Text style={{ fontSize: 12, color: Colors.textMuted }}>{subtitle}</Text>}
      </View>
      {onToggle !== undefined && value !== undefined ? (
        <Switch value={value} onValueChange={onToggle} trackColor={{ false: Colors.border, true: Colors.primary }} thumbColor="#fff" />
      ) : chevron ? (
        <Text style={{ color: Colors.textMuted, fontSize: 16 }}>›</Text>
      ) : null}
    </Pressable>
  );
}

function Section({ title, children }: { title: string; children: React.ReactNode }) {
  return (
    <View style={{ marginBottom: 24 }}>
      <Text style={{ fontSize: 12, fontWeight: "800", color: Colors.textMuted, letterSpacing: 0.6, paddingHorizontal: 16, paddingBottom: 8 }}>
        {title}
      </Text>
      <View style={{ backgroundColor: Colors.surface, borderTopWidth: 1, borderBottomWidth: 1, borderColor: Colors.border }}>
        {children}
      </View>
    </View>
  );
}

export default function SettingsScreen() {
  const router    = useRouter();
  const insets    = useSafeAreaInsets();
  const reset     = useAuthStore((s) => s.reset);
  const prefs     = useNotificationStore((s) => s.preferences);
  const updatePref= useNotificationStore((s) => s.updatePreference);
  const [locationEnabled, setLocation] = useState(true);
  const [showDistance, setShowDist]    = useState(true);
  const [showOnline, setShowOnline]    = useState(true);

  const handleLogout = () => {
    reset();
    router.replace("/auth/welcome");
  };

  return (
    <View style={{ flex: 1, backgroundColor: Colors.background }}>
      {/* Header */}
      <View style={{ paddingTop: insets.top, backgroundColor: Colors.surface, borderBottomWidth: 1, borderBottomColor: Colors.border }}>
        <View style={{ height: 56, flexDirection: "row", alignItems: "center", paddingHorizontal: 16, gap: 12 }}>
          <Pressable onPress={() => router.back()} hitSlop={10} style={({ pressed }) => ({ opacity: pressed ? 0.6 : 1 })}>
            <Text style={{ fontSize: 22, color: Colors.text }}>←</Text>
          </Pressable>
          <Text style={{ fontSize: 17, fontWeight: "800", color: Colors.text }}>Settings</Text>
        </View>
      </View>

      <ScrollView showsVerticalScrollIndicator={false} contentContainerStyle={{ paddingTop: 20, paddingBottom: 48 }}>
        <Section title="ACCOUNT">
          <SettingsRow emoji="✏️" label="Edit Profile"       subtitle="Name, photo, bio, interests" onPress={() => router.push("/(tabs)/profile/edit")} chevron />
          <View style={{ height: 1, backgroundColor: Colors.border, marginLeft: 64 }} />
          <SettingsRow emoji="📱" label="Phone Number"       subtitle={useAuthStore.getState().profile.phone || "Not set"} onPress={() => {}} chevron />
          <View style={{ height: 1, backgroundColor: Colors.border, marginLeft: 64 }} />
          <SettingsRow emoji="✉️" label="Email Address"      subtitle={useAuthStore.getState().profile.email || "Not set"} onPress={() => {}} chevron />
          <View style={{ height: 1, backgroundColor: Colors.border, marginLeft: 64 }} />
          <SettingsRow emoji="🔐" label="Change Password"    onPress={() => {}} chevron />
        </Section>

        <Section title="PRIVACY & LOCATION">
          <SettingsRow emoji="📍" label="Location Services"  subtitle="Required for discovery" value={locationEnabled} onToggle={() => setLocation((v) => !v)} />
          <View style={{ height: 1, backgroundColor: Colors.border, marginLeft: 64 }} />
          <SettingsRow emoji="📏" label="Show Distance"      subtitle="Show how far you are from others" value={showDistance} onToggle={() => setShowDist((v) => !v)} />
          <View style={{ height: 1, backgroundColor: Colors.border, marginLeft: 64 }} />
          <SettingsRow emoji="🟢" label="Show Online Status" subtitle="Let others see when you're active" value={showOnline} onToggle={() => setShowOnline((v) => !v)} />
          <View style={{ height: 1, backgroundColor: Colors.border, marginLeft: 64 }} />
          <SettingsRow emoji="🔒" label="Private Profile"    subtitle="Require request to view full profile" onPress={() => {}} chevron />
          <View style={{ height: 1, backgroundColor: Colors.border, marginLeft: 64 }} />
          <SettingsRow emoji="🚫" label="Blocked Users"      onPress={() => {}} chevron />
        </Section>

        <Section title="NOTIFICATIONS">
          <SettingsRow emoji="🔔" label="Push Notifications" value={prefs.pushEnabled} onToggle={() => updatePref("pushEnabled", !prefs.pushEnabled)} />
          <View style={{ height: 1, backgroundColor: Colors.border, marginLeft: 64 }} />
          <SettingsRow emoji="💬" label="Messages"           value={prefs.messages}    onToggle={() => updatePref("messages", !prefs.messages)} />
          <View style={{ height: 1, backgroundColor: Colors.border, marginLeft: 64 }} />
          <SettingsRow emoji="❤️" label="Likes & Matches"    value={prefs.likes}       onToggle={() => updatePref("likes", !prefs.likes)} />
          <View style={{ height: 1, backgroundColor: Colors.border, marginLeft: 64 }} />
          <SettingsRow emoji="🏘️" label="Community Posts"    value={prefs.communityPosts} onToggle={() => updatePref("communityPosts", !prefs.communityPosts)} />
          <View style={{ height: 1, backgroundColor: Colors.border, marginLeft: 64 }} />
          <SettingsRow emoji="⚙" label="All Notification Settings" onPress={() => router.push("/(tabs)/profile/notifications")} chevron />
        </Section>

        <Section title="DISCOVERY PREFERENCES">
          <SettingsRow emoji="🎯" label="Intent"             subtitle="Dating · Friends · LGBTQ+" onPress={() => {}} chevron />
          <View style={{ height: 1, backgroundColor: Colors.border, marginLeft: 64 }} />
          <SettingsRow emoji="📐" label="Age Range & Distance" onPress={() => {}} chevron />
          <View style={{ height: 1, backgroundColor: Colors.border, marginLeft: 64 }} />
          <SettingsRow emoji="🌈" label="Orientation"        onPress={() => {}} chevron />
        </Section>

        <Section title="SUPPORT">
          <SettingsRow emoji="❓" label="Help Centre"        onPress={() => {}} chevron />
          <View style={{ height: 1, backgroundColor: Colors.border, marginLeft: 64 }} />
          <SettingsRow emoji="🛡" label="Safety Centre"      onPress={() => {}} chevron />
          <View style={{ height: 1, backgroundColor: Colors.border, marginLeft: 64 }} />
          <SettingsRow emoji="📋" label="Privacy Policy"     onPress={() => {}} chevron />
          <View style={{ height: 1, backgroundColor: Colors.border, marginLeft: 64 }} />
          <SettingsRow emoji="📜" label="Terms of Service"   onPress={() => {}} chevron />
        </Section>

        <Section title="ACCOUNT ACTIONS">
          <SettingsRow emoji="🗑" label="Delete Account" subtitle="Permanently remove your account" danger onPress={() => {}} chevron />
          <View style={{ height: 1, backgroundColor: Colors.border, marginLeft: 64 }} />
          <SettingsRow emoji="🚪" label="Log Out" danger onPress={handleLogout} chevron />
        </Section>

        <Text style={{ textAlign: "center", fontSize: 12, color: Colors.textMuted, paddingBottom: 16 }}>
          Lovrhub v1.0.0 · Made with ❤️ in Mumbai
        </Text>
      </ScrollView>
    </View>
  );
}
