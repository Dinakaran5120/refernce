export type CommunityPrivacy = "public" | "private";
export type CommunityMemberRole = "owner" | "admin" | "member";
export type MembershipStatus = "none" | "pending" | "member" | "admin" | "owner" | "rejected" | "banned";
export type CommunityPostType = "text" | "image" | "poll" | "event" | "announcement";
export type JoinRequestStatus = "pending" | "approved" | "rejected";

export interface CommunityMember {
  id: string;
  name: string;
  avatarEmoji: string;
  gradient: [string, string];
  role: CommunityMemberRole;
  joinedAt: string;
}

export interface JoinRequest {
  id: string;
  userId: string;
  userName: string;
  avatarEmoji: string;
  gradient: [string, string];
  message: string;
  requestedAt: string;
  status: JoinRequestStatus;
}

export interface CommunityRule {
  id: string;
  title: string;
  description: string;
}

export interface PollOption {
  id: string;
  text: string;
  votes: number;
  votedByMe: boolean;
}

export interface CommunityPost {
  id: string;
  communityId: string;
  type: CommunityPostType;
  author: CommunityMember;
  title?: string;
  content: string;
  mediaEmoji?: string;
  mediaGradient?: [string, string];
  pollOptions?: PollOption[];
  pollEndsAt?: string;
  eventDate?: string;
  eventLocation?: string;
  likes: number;
  liked: boolean;
  commentCount: number;
  isPinned: boolean;
  isAnnouncement: boolean;
  createdAt: string;
  tags: string[];
}

export interface Community {
  id: string;
  name: string;
  slug: string;
  description: string;
  coverGradient: [string, string];
  coverEmoji: string;
  privacy: CommunityPrivacy;
  category: string;
  tags: string[];
  memberCount: number;
  postCount: number;
  rules: CommunityRule[];
  members: CommunityMember[];           // top 5 shown
  pendingRequests: JoinRequest[];       // only visible to owner/admin
  myStatus: MembershipStatus;
  isVerified: boolean;
  createdAt: string;
  lastActivityAt: string;
}
