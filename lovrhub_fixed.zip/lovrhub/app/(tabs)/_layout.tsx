import { Tabs } from "expo-router";
import { View, Text, Pressable } from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import type { BottomTabBarProps } from "@react-navigation/bottom-tabs";
import { LinearGradient } from "expo-linear-gradient";
import { Colors } from "@constants/theme";
import TopNavBar from "@components/TopNavBar";
import { useConnectionsStore } from "@/store/connectionsStore";
import { useCommunityStore } from "@/store/communityStore";

const TAB_ICONS: Record<string, { active: string; inactive: string }> = {
  index:        { active: "🔥", inactive: "🔥" },
  explore:      { active: "✦",  inactive: "✦"  },
  post:         { active: "+",  inactive: "+"  },
  connections:  { active: "💬", inactive: "💬" },
  communities:  { active: "🏘️", inactive: "🏘️" },
  profile:      { active: "◉",  inactive: "◎"  },
};

const TAB_LABELS: Record<string, string> = {
  index:        "Discover",
  explore:      "Explore",
  post:         "Post",
  connections:  "Chats",
  communities:  "Groups",
  profile:      "Profile",
};

function CustomTabBar({ state, navigation }: BottomTabBarProps) {
  const insets = useSafeAreaInsets();

  // Hide tab bar when inside a chat, call, or community detail
  const activeConvId       = useConnectionsStore((s) => s.activeConversationId);
  const activeCall         = useConnectionsStore((s) => s.call);
  const activeCommunityId  = useCommunityStore((s) => s.activeCommunityId);

  if (activeConvId || activeCall || activeCommunityId) return null;

  return (
    <View
      style={{
        backgroundColor: Colors.surface,
        paddingBottom: insets.bottom + 4,
        paddingTop: 8,
        borderTopWidth: 1,
        borderTopColor: Colors.border,
        shadowColor: Colors.primary,
        shadowOffset: { width: 0, height: -4 },
        shadowOpacity: 0.08,
        shadowRadius: 16,
        elevation: 12,
      }}
    >
      <View style={{ flexDirection: "row", paddingHorizontal: 8 }}>
        {state.routes.map((route, index) => {
          const isActive = state.index === index;
          const isPost   = route.name === "post";

          const onPress = () => {
            const event = navigation.emit({
              type: "tabPress",
              target: route.key,
              canPreventDefault: true,
            });
            if (!isActive && !event.defaultPrevented) {
              navigation.navigate(route.name);
            }
          };

          if (isPost) {
            return (
              <View key={route.key} style={{ flex: 1, alignItems: "center" }}>
                <Pressable
                  onPress={onPress}
                  style={({ pressed }) => ({
                    opacity: pressed ? 0.85 : 1,
                    transform: [{ scale: pressed ? 0.93 : 1 }],
                  })}
                >
                  <LinearGradient
                    colors={[Colors.primary, Colors.accent]}
                    start={{ x: 0, y: 0 }} end={{ x: 1, y: 1 }}
                    style={{
                      width: 52, height: 52, borderRadius: 26,
                      alignItems: "center", justifyContent: "center",
                      marginTop: -20,
                      shadowColor: Colors.primary,
                      shadowOffset: { width: 0, height: 4 },
                      shadowOpacity: 0.45, shadowRadius: 12, elevation: 8,
                    }}
                  >
                    <Text style={{ color: "#fff", fontSize: 28, lineHeight: 32 }}>+</Text>
                  </LinearGradient>
                </Pressable>
                <Text style={{ fontSize: 11, fontWeight: "600", marginTop: 4, color: Colors.textMuted, letterSpacing: 0.3 }}>
                  {TAB_LABELS[route.name]}
                </Text>
              </View>
            );
          }

          return (
            <Pressable
              key={route.key}
              onPress={onPress}
              style={({ pressed }) => ({
                flex: 1, alignItems: "center", paddingVertical: 2,
                opacity: pressed ? 0.7 : 1,
              })}
            >
              {isActive && (
                <View style={{
                  position: "absolute", top: -6,
                  width: 36, height: 3, borderRadius: 2,
                  backgroundColor: Colors.primary,
                }} />
              )}
              <View style={{
                width: 40, height: 32, alignItems: "center", justifyContent: "center",
                borderRadius: 10,
                backgroundColor: isActive ? Colors.card : "transparent",
              }}>
                <Text style={{ fontSize: route.name === "index" ? 20 : 18 }}>
                  {isActive ? TAB_ICONS[route.name]?.active : TAB_ICONS[route.name]?.inactive}
                </Text>
              </View>
              <Text style={{
                fontSize: 11, fontWeight: isActive ? "700" : "500", marginTop: 2,
                color: isActive ? Colors.primary : Colors.textMuted, letterSpacing: 0.3,
              }}>
                {TAB_LABELS[route.name]}
              </Text>
            </Pressable>
          );
        })}
      </View>
    </View>
  );
}

function DynamicHeader() {
  const activeConvId      = useConnectionsStore((s) => s.activeConversationId);
  const activeCall        = useConnectionsStore((s) => s.call);
  const activeCommunityId = useCommunityStore((s) => s.activeCommunityId);
  if (activeConvId || activeCall || activeCommunityId) return null;
  return <TopNavBar />;
}

export default function TabLayout() {
  return (
    <Tabs
      tabBar={(props) => <CustomTabBar {...props} />}
      screenOptions={{ header: () => <DynamicHeader /> }}
    >
      <Tabs.Screen name="index"       options={{ title: "Discover"    }} />
      <Tabs.Screen name="explore"     options={{ title: "Explore"     }} />
      <Tabs.Screen name="post"        options={{ title: "Post"        }} />
      <Tabs.Screen name="connections" options={{ title: "Connections" }} />
      <Tabs.Screen name="communities" options={{ title: "Communities" }} />
      <Tabs.Screen name="profile"     options={{ title: "Profile",    headerShown: false }} />
    </Tabs>
  );
}
