import { View, Text, Pressable, Dimensions } from "react-native";
import { LinearGradient } from "expo-linear-gradient";
import { useRouter } from "expo-router";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import { Colors } from "@constants/theme";

const { width: W, height: H } = Dimensions.get("window");

const FLOATING_CARDS = [
  { emoji: "😊", name: "Arjun", age: 26, top: H * 0.12, left: 18,      rotate: "-8deg", grad: [Colors.secondary, Colors.rose]  as [string,string] },
  { emoji: "🥰", name: "Priya", age: 24, top: H * 0.08, left: W - 148, rotate: "6deg",  grad: [Colors.violet, Colors.sky]      as [string,string] },
  { emoji: "😎", name: "Dev",   age: 28, top: H * 0.26, left: 8,       rotate: "4deg",  grad: [Colors.primary, Colors.accent]  as [string,string] },
  { emoji: "🌈", name: "Zara",  age: 23, top: H * 0.22, left: W - 138, rotate: "-5deg", grad: [Colors.accent, Colors.gold]    as [string,string] },
];

function GoogleIcon() {
  return (
    <View
      style={{
        width: 22, height: 22, borderRadius: 11,
        backgroundColor: "#fff", borderWidth: 1, borderColor: "#E0E0E0",
        alignItems: "center", justifyContent: "center",
      }}
    >
      <Text style={{ fontSize: 13, fontWeight: "800", color: "#4285F4" }}>G</Text>
    </View>
  );
}

export default function WelcomeScreen() {
  const router = useRouter();
  const insets = useSafeAreaInsets();

  return (
    <View style={{ flex: 1, backgroundColor: Colors.background }}>
      {/* Hero gradient */}
      <LinearGradient
        colors={[Colors.secondary + "55", Colors.accent + "33", Colors.background]}
        locations={[0, 0.5, 1]}
        style={{ position: "absolute", top: 0, left: 0, right: 0, height: H * 0.55 }}
      />

      {/* Floating cards */}
      {FLOATING_CARDS.map((card, i) => (
        <View
          key={i}
          style={{
            position: "absolute", top: card.top, left: card.left,
            transform: [{ rotate: card.rotate }],
            shadowColor: "#000", shadowOffset: { width: 0, height: 6 },
            shadowOpacity: 0.12, shadowRadius: 14, elevation: 6,
          }}
        >
          <LinearGradient
            colors={card.grad}
            start={{ x: 0, y: 0 }} end={{ x: 1, y: 1 }}
            style={{ width: 120, height: 148, borderRadius: 22, alignItems: "center", justifyContent: "center", gap: 4 }}
          >
            <Text style={{ fontSize: 44 }}>{card.emoji}</Text>
            <Text style={{ color: "#fff", fontSize: 14, fontWeight: "800" }}>{card.name}</Text>
            <Text style={{ color: "rgba(255,255,255,0.8)", fontSize: 12, fontWeight: "600" }}>{card.age} yrs</Text>
            <View
              style={{
                position: "absolute", bottom: 12, right: 12,
                width: 26, height: 26, borderRadius: 13,
                backgroundColor: "rgba(255,255,255,0.3)",
                alignItems: "center", justifyContent: "center",
              }}
            >
              <Text style={{ fontSize: 13 }}>♥</Text>
            </View>
          </LinearGradient>
        </View>
      ))}

      {/* Bottom sheet */}
      <View
        style={{
          position: "absolute", bottom: 0, left: 0, right: 0,
          backgroundColor: Colors.surface,
          borderTopLeftRadius: 36, borderTopRightRadius: 36,
          paddingHorizontal: 28, paddingTop: 32,
          paddingBottom: insets.bottom + 32,
          shadowColor: "#000", shadowOffset: { width: 0, height: -8 },
          shadowOpacity: 0.08, shadowRadius: 24, elevation: 16,
        }}
      >
        {/* Logo */}
        <View style={{ flexDirection: "row", alignItems: "center", marginBottom: 6, gap: 8 }}>
          <LinearGradient
            colors={[Colors.primary, Colors.accent]}
            start={{ x: 0, y: 0 }} end={{ x: 1, y: 1 }}
            style={{ width: 38, height: 38, borderRadius: 12, alignItems: "center", justifyContent: "center" }}
          >
            <Text style={{ fontSize: 20 }}>🔥</Text>
          </LinearGradient>
          <Text style={{ fontSize: 28, fontWeight: "900", color: Colors.text, letterSpacing: -0.8 }}>
            lovrhub
          </Text>
        </View>

        <Text
          style={{
            fontSize: 32, fontWeight: "800", color: Colors.text,
            letterSpacing: -0.8, lineHeight: 40, marginBottom: 10,
          }}
        >
          Find your{"\n"}
          <Text style={{ color: Colors.primary }}>people</Text>. Be{" "}
          <Text style={{ color: Colors.violet }}>yourself</Text>. 🌈
        </Text>

        <Text style={{ fontSize: 14, color: Colors.textMuted, lineHeight: 21, marginBottom: 28 }}>
          Dating · Friendships · LGBTQ+ inclusive.{"\n"}Lovrhub is for everyone.
        </Text>

        {/* Pride strip */}
        <View style={{ flexDirection: "row", height: 4, borderRadius: 2, overflow: "hidden", marginBottom: 28 }}>
          {Colors.pride.map((c, i) => (
            <View key={i} style={{ flex: 1, backgroundColor: c }} />
          ))}
        </View>

        {/* Phone CTA */}
        <Pressable
          onPress={() => router.push("/auth/phone")}
          style={({ pressed }) => ({
            opacity: pressed ? 0.88 : 1, transform: [{ scale: pressed ? 0.97 : 1 }], marginBottom: 12,
          })}
        >
          <LinearGradient
            colors={[Colors.primary, Colors.accent]}
            start={{ x: 0, y: 0 }} end={{ x: 1, y: 0 }}
            style={{
              borderRadius: 18, paddingVertical: 18, alignItems: "center",
              shadowColor: Colors.primary, shadowOffset: { width: 0, height: 6 },
              shadowOpacity: 0.35, shadowRadius: 14, elevation: 6,
            }}
          >
            <Text style={{ color: "#fff", fontSize: 16, fontWeight: "800" }}>📱  Continue with Phone</Text>
          </LinearGradient>
        </Pressable>

        {/* Google */}
        <Pressable
          onPress={() => router.push("/auth/email")}
          style={({ pressed }) => ({
            borderRadius: 18, paddingVertical: 17,
            flexDirection: "row", alignItems: "center", justifyContent: "center", gap: 10,
            borderWidth: 1.5, borderColor: Colors.border, backgroundColor: Colors.surface,
            marginBottom: 12, opacity: pressed ? 0.7 : 1,
          })}
        >
          <GoogleIcon />
          <Text style={{ color: Colors.text, fontSize: 15, fontWeight: "700" }}>Continue with Google</Text>
        </Pressable>

        {/* Email */}
        <Pressable
          onPress={() => router.push("/auth/email")}
          style={({ pressed }) => ({
            borderRadius: 18, paddingVertical: 17,
            flexDirection: "row", alignItems: "center", justifyContent: "center", gap: 10,
            borderWidth: 1.5, borderColor: Colors.border, backgroundColor: Colors.surface,
            opacity: pressed ? 0.7 : 1,
          })}
        >
          <Text style={{ fontSize: 18 }}>✉️</Text>
          <Text style={{ color: Colors.text, fontSize: 15, fontWeight: "700" }}>Continue with Email</Text>
        </Pressable>

        <Text style={{ fontSize: 11, color: Colors.textMuted, textAlign: "center", marginTop: 20, lineHeight: 17 }}>
          By continuing, you agree to our Terms of Service{"\n"}and Privacy Policy.
        </Text>
      </View>
    </View>
  );
}
