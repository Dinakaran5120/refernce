import { useState } from "react";
import { View, Text, ScrollView, Pressable, Dimensions } from "react-native";
import { LinearGradient } from "expo-linear-gradient";
import { Ionicons } from "@expo/vector-icons";
import { useRouter } from "expo-router";
import { useTheme } from "@/context/ThemeContext";
import { useAuthStore } from "@/store/authStore";

const { width: SCREEN_W } = Dimensions.get("window");
const GRID_TILE = (SCREEN_W - 36) / 3;

const STATS = [
  { label: "Posts",   value: "48"  },
  { label: "Matches", value: "126" },
  { label: "Friends", value: "83"  },
];

const HIGHLIGHTS = [
  { id: "1", label: "Travel", emoji: "✈️", gradient: ["#6BD4FF","#B06BFF"]     as [string, string] },
  { id: "2", label: "Foodie", emoji: "🍜", gradient: ["#FF8C6B","#FFD166"]     as [string, string] },
  { id: "3", label: "Art",    emoji: "🎨", gradient: ["#FF6B9D","#B06BFF"]     as [string, string] },
  { id: "4", label: "Music",  emoji: "🎵", gradient: ["#E63946","#FF8C6B"]     as [string, string] },
  { id: "5", label: "Vibes",  emoji: "✨", gradient: ["#F7A1C4","#FF6B9D"]     as [string, string] },
];

const GRID_ITEMS = [
  { id: "1", emoji: "🌆", gradient: ["#F7A1C4","#FF6B9D"]   as [string, string], span: 1 },
  { id: "2", emoji: "☕", gradient: ["#FF8C6B","#FFD166"]   as [string, string], span: 1 },
  { id: "3", emoji: "🎨", gradient: ["#B06BFF","#6BD4FF"]   as [string, string], span: 1 },
  { id: "4", emoji: "🌊", gradient: ["#6BD4FF","#6BFFB8"]   as [string, string], span: 2 },
  { id: "5", emoji: "🌸", gradient: ["#FF6B9D","#F7A1C4"]   as [string, string], span: 1 },
  { id: "6", emoji: "🍣", gradient: ["#E63946","#FF8C6B"]   as [string, string], span: 1 },
  { id: "7", emoji: "🌙", gradient: ["#B06BFF","#FF6B9D"]   as [string, string], span: 1 },
  { id: "8", emoji: "🌈", gradient: ["#FFD166","#FF8C6B"]   as [string, string], span: 1 },
];

const INTENT_PILLS = [
  { label: "Dating 💕",  colors: ["#E63946","#FF8C6B"] as [string, string] },
  { label: "Friends 🤝", colors: ["#B06BFF","#6BD4FF"] as [string, string] },
  { label: "LGBTQ+ 🌈",  colors: ["#B06BFF","#FF6B9D"] as [string, string] },
];

const INTEREST_TAGS = ["☕ Coffee", "🎵 Indie music", "✈️ Travel", "📸 Photography", "🍜 Ramen", "🌿 Plants"];

export default function ProfileScreen() {
  const router  = useRouter();
  const { colors } = useTheme();
  const profile = useAuthStore((s) => s.profile);
  const [activeGrid, setActiveGrid] = useState<"posts" | "liked">("posts");

  const displayName  = profile.name || "Your Name";
  const displayEmoji = profile.photoEmoji || "😊";

  return (
    <ScrollView
      style={{ flex: 1, backgroundColor: colors.background }}
      showsVerticalScrollIndicator={false}
    >
      {/* ── Banner ── */}
      <LinearGradient
        colors={[colors.primary, colors.secondary, colors.accent]}
        start={{ x: 0, y: 0 }}
        end={{ x: 1, y: 1 }}
        style={{ height: 130, width: "100%" }}
      />

      {/* ── Avatar row ── */}
      <View
        style={{
          paddingHorizontal: 20,
          marginTop: -52,
          flexDirection: "row",
          alignItems: "flex-end",
          justifyContent: "space-between",
          marginBottom: 16,
        }}
      >
        {/* Avatar */}
        <LinearGradient
          colors={[colors.primary, colors.accent]}
          start={{ x: 0, y: 0 }}
          end={{ x: 1, y: 1 }}
          style={{
            width: 96,
            height: 96,
            borderRadius: 48,
            padding: 3,
            shadowColor: colors.primary,
            shadowOffset: { width: 0, height: 4 },
            shadowOpacity: 0.4,
            shadowRadius: 12,
            elevation: 10,
          }}
        >
          <View
            style={{
              flex: 1,
              borderRadius: 45,
              backgroundColor: colors.card,
              alignItems: "center",
              justifyContent: "center",
              borderWidth: 3,
              borderColor: colors.surface,
            }}
          >
            <Text style={{ fontSize: 42 }}>{displayEmoji}</Text>
          </View>
        </LinearGradient>

        {/* Action buttons */}
        <View style={{ flexDirection: "row", gap: 10, marginBottom: 4 }}>
          <Pressable
            onPress={() => router.push("/(tabs)/profile/edit")}
            style={({ pressed }) => ({
              paddingHorizontal: 20,
              paddingVertical: 10,
              borderRadius: 14,
              borderWidth: 1.5,
              borderColor: colors.border,
              backgroundColor: colors.surface,
              opacity: pressed ? 0.7 : 1,
              shadowColor: "#000",
              shadowOffset: { width: 0, height: 2 },
              shadowOpacity: 0.08,
              shadowRadius: 6,
              elevation: 3,
            })}
          >
            <Text style={{ color: colors.text, fontSize: 13, fontWeight: "700" }}>Edit Profile</Text>
          </Pressable>
          <Pressable
            onPress={() => router.push("/(tabs)/profile/settings")}
            style={({ pressed }) => ({
              width: 40,
              height: 40,
              borderRadius: 14,
              borderWidth: 1.5,
              borderColor: colors.border,
              backgroundColor: colors.surface,
              alignItems: "center",
              justifyContent: "center",
              opacity: pressed ? 0.7 : 1,
              shadowColor: "#000",
              shadowOffset: { width: 0, height: 2 },
              shadowOpacity: 0.08,
              shadowRadius: 6,
              elevation: 3,
            })}
          >
            <Ionicons name="settings-outline" size={18} color={colors.text} />
          </Pressable>
        </View>
      </View>

      {/* ── Name & bio ── */}
      <View style={{ paddingHorizontal: 20, marginBottom: 16, gap: 6 }}>
        <View style={{ flexDirection: "row", alignItems: "center", gap: 8 }}>
          <Text style={{ fontSize: 22, fontWeight: "800", color: colors.text, letterSpacing: -0.3 }}>
            {displayName}
          </Text>
          <View
            style={{
              backgroundColor: "#3b82f6",
              width: 22,
              height: 22,
              borderRadius: 11,
              alignItems: "center",
              justifyContent: "center",
            }}
          >
            <Ionicons name="checkmark" size={13} color="#fff" />
          </View>
        </View>
        <Text style={{ color: colors.textSecondary, fontSize: 14 }}>
          @{(displayName || "you").toLowerCase().replace(/\s+/g, "_")} · Mumbai, IN 📍
        </Text>
        <Text style={{ color: colors.text, fontSize: 14, lineHeight: 21, marginTop: 4 }}>
          Living in colour ✨ Coffee addict, sunset chaser, music lover.{"\n"}Here for connections that feel real 🌈
        </Text>
        <View style={{ flexDirection: "row", gap: 8, marginTop: 8, flexWrap: "wrap" }}>
          {INTENT_PILLS.map((pill) => (
            <LinearGradient
              key={pill.label}
              colors={pill.colors}
              start={{ x: 0, y: 0 }}
              end={{ x: 1, y: 0 }}
              style={{ paddingHorizontal: 12, paddingVertical: 5, borderRadius: 14 }}
            >
              <Text style={{ color: "#fff", fontSize: 12, fontWeight: "700" }}>{pill.label}</Text>
            </LinearGradient>
          ))}
        </View>
      </View>

      {/* ── Quick actions ── */}
      <View style={{ flexDirection: "row", paddingHorizontal: 20, gap: 10, marginBottom: 16 }}>
        <Pressable
          onPress={() => router.push("/(tabs)/profile/notifications")}
          style={({ pressed }) => ({
            flex: 1,
            flexDirection: "row",
            alignItems: "center",
            gap: 8,
            padding: 13,
            borderRadius: 16,
            backgroundColor: colors.card,
            borderWidth: 1,
            borderColor: colors.border,
            opacity: pressed ? 0.7 : 1,
          })}
        >
          <Ionicons name="notifications-outline" size={18} color={colors.primary} />
          <Text style={{ fontSize: 13, fontWeight: "700", color: colors.textSecondary }}>Notifications</Text>
          <Ionicons name="chevron-forward" size={14} color={colors.textMuted} style={{ marginLeft: "auto" }} />
        </Pressable>
        <Pressable
          onPress={() => router.push("/(tabs)/profile/settings")}
          style={({ pressed }) => ({
            flex: 1,
            flexDirection: "row",
            alignItems: "center",
            gap: 8,
            padding: 13,
            borderRadius: 16,
            backgroundColor: colors.card,
            borderWidth: 1,
            borderColor: colors.border,
            opacity: pressed ? 0.7 : 1,
          })}
        >
          <Ionicons name="settings-outline" size={18} color={colors.primary} />
          <Text style={{ fontSize: 13, fontWeight: "700", color: colors.textSecondary }}>Settings</Text>
          <Ionicons name="chevron-forward" size={14} color={colors.textMuted} style={{ marginLeft: "auto" }} />
        </Pressable>
      </View>

      {/* ── Stats ── */}
      <View
        style={{
          flexDirection: "row",
          marginHorizontal: 20,
          backgroundColor: colors.surface,
          borderRadius: 20,
          paddingVertical: 16,
          marginBottom: 20,
          borderWidth: 1,
          borderColor: colors.border,
          shadowColor: "#000",
          shadowOffset: { width: 0, height: 2 },
          shadowOpacity: 0.06,
          shadowRadius: 8,
          elevation: 2,
        }}
      >
        {STATS.map((stat, i) => (
          <View
            key={stat.label}
            style={{
              flex: 1,
              alignItems: "center",
              gap: 4,
              borderRightWidth: i < STATS.length - 1 ? 1 : 0,
              borderRightColor: colors.border,
            }}
          >
            <Text style={{ fontSize: 21, fontWeight: "800", color: colors.text }}>{stat.value}</Text>
            <Text style={{ fontSize: 12, color: colors.textMuted, fontWeight: "600" }}>{stat.label}</Text>
          </View>
        ))}
      </View>

      {/* ── Highlights ── */}
      <ScrollView
        horizontal
        showsHorizontalScrollIndicator={false}
        contentContainerStyle={{ paddingHorizontal: 20, gap: 14, paddingBottom: 4 }}
        style={{ marginBottom: 20 }}
      >
        {HIGHLIGHTS.map((h) => (
          <Pressable key={h.id} style={({ pressed }) => ({ alignItems: "center", gap: 6, opacity: pressed ? 0.7 : 1 })}>
            <LinearGradient
              colors={h.gradient}
              start={{ x: 0, y: 0 }}
              end={{ x: 1, y: 1 }}
              style={{ width: 66, height: 66, borderRadius: 33, alignItems: "center", justifyContent: "center" }}
            >
              <Text style={{ fontSize: 28 }}>{h.emoji}</Text>
            </LinearGradient>
            <Text style={{ fontSize: 11, color: colors.textSecondary, fontWeight: "600" }}>{h.label}</Text>
          </Pressable>
        ))}
        <Pressable
          onPress={() => router.push("/(tabs)/profile/edit")}
          style={{ alignItems: "center", gap: 6 }}
        >
          <View
            style={{
              width: 66,
              height: 66,
              borderRadius: 33,
              backgroundColor: colors.card,
              alignItems: "center",
              justifyContent: "center",
              borderWidth: 1.5,
              borderColor: colors.border,
              borderStyle: "dashed",
            }}
          >
            <Ionicons name="add" size={26} color={colors.textMuted} />
          </View>
          <Text style={{ fontSize: 11, color: colors.textMuted, fontWeight: "600" }}>New</Text>
        </Pressable>
      </ScrollView>

      {/* ── Interests ── */}
      <View style={{ paddingHorizontal: 20, marginBottom: 20 }}>
        <View style={{ flexDirection: "row", alignItems: "center", justifyContent: "space-between", marginBottom: 10 }}>
          <Text style={{ fontSize: 15, fontWeight: "700", color: colors.text }}>My interests</Text>
          <Pressable onPress={() => router.push("/(tabs)/profile/edit")}>
            <Text style={{ fontSize: 13, color: colors.primary, fontWeight: "700" }}>Edit</Text>
          </Pressable>
        </View>
        <View style={{ flexDirection: "row", flexWrap: "wrap", gap: 8 }}>
          {(profile.interests && profile.interests.length > 0 ? profile.interests : INTEREST_TAGS).map((tag) => (
            <View
              key={tag}
              style={{
                paddingHorizontal: 14,
                paddingVertical: 7,
                borderRadius: 16,
                backgroundColor: colors.card,
                borderWidth: 1,
                borderColor: colors.border,
              }}
            >
              <Text style={{ color: colors.textSecondary, fontSize: 13, fontWeight: "600" }}>{tag}</Text>
            </View>
          ))}
        </View>
      </View>

      {/* ── Grid tab switcher ── */}
      <View style={{ flexDirection: "row", borderTopWidth: 1, borderTopColor: colors.border, marginBottom: 4 }}>
        {(["posts", "liked"] as const).map((tab) => {
          const isActive = activeGrid === tab;
          return (
            <Pressable
              key={tab}
              onPress={() => setActiveGrid(tab)}
              style={{
                flex: 1,
                paddingVertical: 13,
                alignItems: "center",
                borderBottomWidth: 2.5,
                borderBottomColor: isActive ? colors.primary : "transparent",
              }}
            >
              <Ionicons
                name={tab === "posts" ? "grid-outline" : "heart-outline"}
                size={22}
                color={isActive ? colors.primary : colors.textMuted}
              />
            </Pressable>
          );
        })}
      </View>

      {/* ── Photo grid ── */}
      <View style={{ flexDirection: "row", flexWrap: "wrap", gap: 3, paddingHorizontal: 16, paddingBottom: 40 }}>
        {GRID_ITEMS.map((item) => {
          const isWide = item.span === 2;
          return (
            <Pressable
              key={item.id}
              style={({ pressed }) => ({
                width: isWide ? GRID_TILE * 2 + 3 : GRID_TILE,
                height: GRID_TILE,
                borderRadius: 12,
                overflow: "hidden",
                opacity: pressed ? 0.85 : 1,
                transform: [{ scale: pressed ? 0.97 : 1 }],
              })}
            >
              <LinearGradient
                colors={item.gradient}
                start={{ x: 0, y: 0 }}
                end={{ x: 1, y: 1 }}
                style={{ flex: 1, alignItems: "center", justifyContent: "center" }}
              >
                <Text style={{ fontSize: isWide ? 36 : 28 }}>{item.emoji}</Text>
              </LinearGradient>
            </Pressable>
          );
        })}
      </View>
    </ScrollView>
  );
}
