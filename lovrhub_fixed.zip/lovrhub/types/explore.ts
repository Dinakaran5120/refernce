export type PostType = "text" | "image" | "video" | "thought" | "mood";
export type VibeType = "❤️" | "😂" | "🔥" | "😮" | "💔" | "✨";

export interface PostAuthor {
  id: string;
  name: string;
  avatarEmoji: string;
  gradient: [string, string];
  verified: boolean;
  isAnonymous: boolean;
}

export interface PostComment {
  id: string;
  author: PostAuthor;
  text: string;
  createdAt: string;
  likes: number;
  liked: boolean;
}

export interface VibeCount {
  emoji: VibeType;
  count: number;
  reacted: boolean;
}

export interface ExplorePost {
  id: string;
  type: PostType;
  author: PostAuthor;
  caption: string;
  mediaEmoji?: string;           // emoji placeholder for image/video
  mediaGradient?: [string, string];
  videoDuration?: string;        // e.g. "0:24"
  tags: string[];
  mood?: string;                 // for mood/thought posts
  moodColor?: string;
  moodGradient?: [string, string];
  vibes: VibeCount[];
  comments: PostComment[];
  shares: number;
  createdAt: string;
  location?: string;
  isPublic: boolean;
  isTrending: boolean;
}

export type ExploreFeedTab = "forYou" | "trending" | "vibes" | "reels";
