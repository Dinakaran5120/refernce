import { useState } from "react";
import { View, Text, KeyboardAvoidingView, Platform, ScrollView, Pressable } from "react-native";
import { useRouter } from "expo-router";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import { Ionicons } from "@expo/vector-icons";
import { useTheme } from "@/context/ThemeContext";
import { useAuthStore } from "@/store/authStore";
import { AuthInput, PrimaryButton, BackButton, StepHeader } from "@components/auth/AuthUI";

const COUNTRY_CODES = [
  { flag: "🇮🇳", code: "+91", name: "India"  },
  { flag: "🇺🇸", code: "+1",  name: "USA"    },
  { flag: "🇬🇧", code: "+44", name: "UK"     },
  { flag: "🇦🇺", code: "+61", name: "AUS"    },
  { flag: "🇨🇦", code: "+1",  name: "Canada" },
];

function GoogleIcon() {
  return (
    <View style={{ width: 22, height: 22, borderRadius: 11, backgroundColor: "#fff", borderWidth: 1, borderColor: "#E0E0E0", alignItems: "center", justifyContent: "center" }}>
      <Text style={{ fontSize: 13, fontWeight: "800", color: "#4285F4" }}>G</Text>
    </View>
  );
}

export default function PhoneScreen() {
  const router  = useRouter();
  const insets  = useSafeAreaInsets();
  const { colors } = useTheme();
  const updateProfile = useAuthStore((s) => s.updateProfile);

  const [phone, setPhone]           = useState("");
  const [selectedCC, setSelectedCC] = useState(COUNTRY_CODES[0]);
  const [showPicker, setShowPicker] = useState(false);
  const [error, setError]           = useState("");
  const [loading, setLoading]       = useState(false);

  const handleContinue = async () => {
    if (phone.length < 10) { setError("Enter a valid 10-digit mobile number"); return; }
    setError("");
    setLoading(true);
    await new Promise((r) => setTimeout(r, 900));
    setLoading(false);
    updateProfile({ phone: `${selectedCC.code}${phone}` });
    router.push("/auth/otp");
  };

  return (
    <KeyboardAvoidingView
      style={{ flex: 1, backgroundColor: colors.background }}
      behavior={Platform.OS === "ios" ? "padding" : "height"}
    >
      <View style={{ paddingTop: insets.top }}>
        <BackButton onPress={() => router.back()} />
      </View>

      <ScrollView
        contentContainerStyle={{ flexGrow: 1, paddingBottom: insets.bottom + 32 }}
        keyboardShouldPersistTaps="handled"
        showsVerticalScrollIndicator={false}
      >
        <StepHeader emoji="📱" title={"What's your\nnumber?"} subtitle="We'll send a one-time code to verify it's you." />

        <View style={{ paddingHorizontal: 24, gap: 16 }}>
          {/* Country picker */}
          <View>
            <Text style={{ fontSize: 13, fontWeight: "700", color: colors.textSecondary, marginBottom: 8, letterSpacing: 0.3 }}>
              Country
            </Text>
            <Pressable
              onPress={() => setShowPicker(!showPicker)}
              style={({ pressed }) => ({
                flexDirection: "row", alignItems: "center", justifyContent: "space-between",
                backgroundColor: colors.surface, borderRadius: 16,
                borderWidth: 1.5, borderColor: showPicker ? colors.accent : colors.border,
                paddingHorizontal: 16, paddingVertical: 14,
                opacity: pressed ? 0.8 : 1,
              })}
            >
              <View style={{ flexDirection: "row", alignItems: "center", gap: 10 }}>
                <Text style={{ fontSize: 22 }}>{selectedCC.flag}</Text>
                <Text style={{ fontSize: 15, color: colors.text, fontWeight: "600" }}>{selectedCC.name}</Text>
                <Text style={{ fontSize: 15, color: colors.textMuted }}>{selectedCC.code}</Text>
              </View>
              <Ionicons name={showPicker ? "chevron-up" : "chevron-down"} size={16} color={colors.textMuted} />
            </Pressable>

            {showPicker && (
              <View
                style={{
                  backgroundColor: colors.surface, borderRadius: 16,
                  borderWidth: 1, borderColor: colors.border, marginTop: 4,
                  overflow: "hidden", shadowColor: "#000",
                  shadowOffset: { width: 0, height: 4 }, shadowOpacity: 0.08,
                  shadowRadius: 12, elevation: 4,
                }}
              >
                {COUNTRY_CODES.map((cc) => (
                  <Pressable
                    key={cc.name}
                    onPress={() => { setSelectedCC(cc); setShowPicker(false); }}
                    style={({ pressed }) => ({
                      flexDirection: "row", alignItems: "center", gap: 12, padding: 14,
                      backgroundColor: selectedCC.name === cc.name ? colors.card : pressed ? colors.card : colors.surface,
                      borderBottomWidth: 1, borderBottomColor: colors.border,
                    })}
                  >
                    <Text style={{ fontSize: 22 }}>{cc.flag}</Text>
                    <Text style={{ fontSize: 15, color: colors.text, fontWeight: "600", flex: 1 }}>{cc.name}</Text>
                    <Text style={{ fontSize: 14, color: colors.textMuted }}>{cc.code}</Text>
                    {selectedCC.name === cc.name && (
                      <Ionicons name="checkmark" size={16} color={colors.primary} />
                    )}
                  </Pressable>
                ))}
              </View>
            )}
          </View>

          <AuthInput
            label="Mobile Number"
            prefix={selectedCC.code}
            placeholder="98765 43210"
            value={phone}
            onChangeText={(t) => { setPhone(t.replace(/\D/g, "").slice(0, 10)); if (error) setError(""); }}
            keyboardType="phone-pad"
            maxLength={10}
            error={error}
            hint="We'll send an OTP to this number"
          />

          <PrimaryButton label="Send OTP" onPress={handleContinue} loading={loading} disabled={phone.length < 10} icon="→" />

          <View style={{ flexDirection: "row", alignItems: "center", gap: 12 }}>
            <View style={{ flex: 1, height: 1, backgroundColor: colors.border }} />
            <Text style={{ color: colors.textMuted, fontSize: 13 }}>or</Text>
            <View style={{ flex: 1, height: 1, backgroundColor: colors.border }} />
          </View>

          <Pressable
            style={({ pressed }) => ({
              borderRadius: 18, paddingVertical: 17,
              flexDirection: "row", alignItems: "center", justifyContent: "center", gap: 10,
              borderWidth: 1.5, borderColor: colors.border, backgroundColor: colors.surface,
              opacity: pressed ? 0.7 : 1,
            })}
          >
            <GoogleIcon />
            <Text style={{ color: colors.text, fontSize: 15, fontWeight: "700" }}>Sign up with Google</Text>
          </Pressable>
        </View>
      </ScrollView>
    </KeyboardAvoidingView>
  );
}
