import { View, Text, Pressable } from "react-native";
import { LinearGradient } from "expo-linear-gradient";
import { Ionicons } from "@expo/vector-icons";
import { useTheme } from "@/context/ThemeContext";
import { useDiscoverStore } from "@/store/discoverStore";

export function EmptyDiscover() {
  const { colors } = useTheme();
  const resetFilters = useDiscoverStore((s) => s.resetFilters);
  const setShowSheet = useDiscoverStore((s) => s.setShowFilterSheet);

  return (
    <View
      style={{
        alignItems: "center",
        paddingVertical: 60,
        paddingHorizontal: 32,
        gap: 16,
      }}
    >
      <View
        style={{
          width: 100,
          height: 100,
          borderRadius: 50,
          backgroundColor: colors.card,
          alignItems: "center",
          justifyContent: "center",
          borderWidth: 2,
          borderColor: colors.border,
          borderStyle: "dashed",
          marginBottom: 8,
        }}
      >
        <Ionicons name="search-outline" size={44} color={colors.textMuted} />
      </View>
      <Text
        style={{
          fontSize: 22,
          fontWeight: "800",
          color: colors.text,
          textAlign: "center",
          letterSpacing: -0.3,
        }}
      >
        No matches found
      </Text>
      <Text
        style={{
          fontSize: 15,
          color: colors.textMuted,
          textAlign: "center",
          lineHeight: 22,
        }}
      >
        Try adjusting your filters or expanding your search distance.
      </Text>

      <Pressable
        onPress={() => setShowSheet(true)}
        style={({ pressed }) => ({
          opacity: pressed ? 0.85 : 1,
          transform: [{ scale: pressed ? 0.97 : 1 }],
          width: "100%",
        })}
      >
        <LinearGradient
          colors={[colors.primary, colors.accent]}
          start={{ x: 0, y: 0 }}
          end={{ x: 1, y: 0 }}
          style={{
            borderRadius: 16,
            paddingVertical: 16,
            alignItems: "center",
            flexDirection: "row",
            justifyContent: "center",
            gap: 8,
          }}
        >
          <Ionicons name="options-outline" size={18} color="#fff" />
          <Text style={{ color: "#fff", fontSize: 15, fontWeight: "800" }}>
            Adjust Filters
          </Text>
        </LinearGradient>
      </Pressable>

      <Pressable
        onPress={resetFilters}
        style={({ pressed }) => ({
          opacity: pressed ? 0.7 : 1,
          paddingVertical: 12,
        })}
      >
        <Text style={{ color: colors.primary, fontSize: 14, fontWeight: "700" }}>
          Reset all filters
        </Text>
      </Pressable>
    </View>
  );
}
