import { useEffect, useRef } from "react";
import {
  View, Text, Modal, Pressable,
  Animated, Dimensions,
} from "react-native";
import { LinearGradient } from "expo-linear-gradient";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import { Colors } from "@constants/theme";
import { useConnectionsStore } from "@/store/connectionsStore";
import { formatDuration, formatRemaining } from "@/hooks/useConnections";

const { width: W, height: H } = Dimensions.get("window");
const CALL_LIMIT = 5 * 60;

// ── Ripple ring animation ─────────────────────────────────────────────────────
function RippleRing({ delay = 0, color }: { delay?: number; color: string }) {
  const scale   = useRef(new Animated.Value(1)).current;
  const opacity = useRef(new Animated.Value(0.6)).current;

  useEffect(() => {
    const loop = Animated.loop(
      Animated.sequence([
        Animated.delay(delay),
        Animated.parallel([
          Animated.timing(scale,   { toValue: 2.2, duration: 1600, useNativeDriver: true }),
          Animated.timing(opacity, { toValue: 0,   duration: 1600, useNativeDriver: true }),
        ]),
        Animated.parallel([
          Animated.timing(scale,   { toValue: 1, duration: 0, useNativeDriver: true }),
          Animated.timing(opacity, { toValue: 0.6, duration: 0, useNativeDriver: true }),
        ]),
      ])
    );
    loop.start();
    return () => loop.stop();
  }, []);

  return (
    <Animated.View
      pointerEvents="none"
      style={{
        position: "absolute",
        width: 90, height: 90, borderRadius: 45,
        borderWidth: 2, borderColor: color,
        transform: [{ scale }],
        opacity,
      }}
    />
  );
}

// ── Timer progress arc (uses a simple rectangle mask) ─────────────────────────
function TimerBar({ duration }: { duration: number }) {
  const pct   = Math.min(duration / CALL_LIMIT, 1);
  const warn  = pct > 0.75;
  const crit  = pct > 0.9;
  const color = crit ? Colors.primary : warn ? Colors.gold : Colors.mint;
  const remaining = formatRemaining(duration);

  return (
    <View style={{ alignItems: "center", gap: 6 }}>
      {/* Bar */}
      <View style={{ width: 200, height: 4, borderRadius: 2, backgroundColor: "rgba(255,255,255,0.2)" }}>
        <View
          style={{
            width: `${pct * 100}%`,
            height: "100%",
            borderRadius: 2,
            backgroundColor: color,
          }}
        />
      </View>
      {/* Label */}
      <Text style={{ color: crit ? Colors.primary : "rgba(255,255,255,0.7)", fontSize: 12, fontWeight: "700" }}>
        {crit ? `⚠ ${remaining} left` : warn ? `${remaining} remaining` : `${remaining} left`}
      </Text>
    </View>
  );
}

// ── Single control button ─────────────────────────────────────────────────────
function CtrlBtn({
  emoji, label, active = false,
  activeColor = "rgba(255,255,255,0.3)",
  onPress, large = false,
}: {
  emoji: string; label?: string; active?: boolean;
  activeColor?: string; onPress: () => void; large?: boolean;
}) {
  const size = large ? 72 : 58;
  return (
    <Pressable
      onPress={onPress}
      style={({ pressed }) => ({
        alignItems: "center", gap: 6,
        opacity: pressed ? 0.7 : 1,
        transform: [{ scale: pressed ? 0.9 : 1 }],
      })}
    >
      <View
        style={{
          width: size, height: size, borderRadius: size / 2,
          backgroundColor: active ? activeColor : "rgba(255,255,255,0.15)",
          alignItems: "center", justifyContent: "center",
          borderWidth: 1.5,
          borderColor: active ? activeColor : "rgba(255,255,255,0.3)",
        }}
      >
        <Text style={{ fontSize: large ? 30 : 24 }}>{emoji}</Text>
      </View>
      {label && (
        <Text style={{ color: "rgba(255,255,255,0.75)", fontSize: 11, fontWeight: "600" }}>
          {label}
        </Text>
      )}
    </Pressable>
  );
}

// ── Main CallScreen ────────────────────────────────────────────────────────────
export function CallScreen() {
  const insets       = useSafeAreaInsets();
  const call         = useConnectionsStore((s) => s.call);
  const endCall      = useConnectionsStore((s) => s.endCall);
  const declineCall  = useConnectionsStore((s) => s.declineCall);
  const toggleMic    = useConnectionsStore((s) => s.toggleMic);
  const toggleCamera = useConnectionsStore((s) => s.toggleCamera);
  const toggleSpeaker= useConnectionsStore((s) => s.toggleSpeaker);

  if (!call) return null;

  const participant = call.participants[0];
  const isVideo     = call.type === "video";
  const isRinging   = call.status === "ringing";
  const isActive    = call.status === "active";
  const isEnded     = call.status === "ended";

  const gradColors = participant?.gradient ?? ([Colors.primary, Colors.accent] as [string, string]);

  return (
    <Modal visible animationType="fade" statusBarTranslucent onRequestClose={endCall}>
      <LinearGradient
        colors={isVideo ? ["#0a0a1a", "#1a0a2e"] : [gradColors[0] + "ee", gradColors[1] + "dd", "#1a1a2e"]}
        start={{ x: 0, y: 0 }} end={{ x: 1, y: 1 }}
        style={{ flex: 1 }}
      >
        {/* Ended overlay */}
        {isEnded && (
          <View style={{ position: "absolute", top:0, left:0, right:0, bottom:0, zIndex: 99, alignItems: "center", justifyContent: "center", backgroundColor: "rgba(0,0,0,0.6)" }}>
            <Text style={{ color: "#fff", fontSize: 22, fontWeight: "800" }}>Call ended</Text>
            <Text style={{ color: "rgba(255,255,255,0.7)", fontSize: 15, marginTop: 6 }}>
              {formatDuration(call.duration)}
            </Text>
          </View>
        )}

        {/* Video mock — blurred gradient */}
        {isVideo && isActive && (
          <>
            {/* Remote video */}
            <View style={{ position: "absolute", top: 0, left: 0, right: 0, bottom: 0 }}>
              <LinearGradient
                colors={[gradColors[0] + "88", gradColors[1] + "66", "#000"]}
                start={{ x: 0, y: 0 }} end={{ x: 1, y: 1 }}
                style={{ flex: 1, alignItems: "center", justifyContent: "center" }}
              >
                {call.isCameraOff ? (
                  <Text style={{ fontSize: 80 }}>📷</Text>
                ) : (
                  <Text style={{ fontSize: 100 }}>{participant?.avatarEmoji}</Text>
                )}
              </LinearGradient>
            </View>
            {/* Self PiP */}
            <View
              style={{
                position: "absolute", top: insets.top + 16, right: 16,
                width: 100, height: 140, borderRadius: 16, overflow: "hidden",
                borderWidth: 2, borderColor: "rgba(255,255,255,0.4)",
              }}
            >
              <LinearGradient
                colors={[Colors.primary, Colors.accent]}
                start={{ x: 0, y: 0 }} end={{ x: 1, y: 1 }}
                style={{ flex: 1, alignItems: "center", justifyContent: "center" }}
              >
                <Text style={{ fontSize: 40 }}>😊</Text>
                {call.isCameraOff && (
                  <View style={{ position: "absolute", bottom: 6, left: 0, right: 0, alignItems: "center" }}>
                    <Text style={{ color: "#fff", fontSize: 10, fontWeight: "700" }}>Cam off</Text>
                  </View>
                )}
              </LinearGradient>
            </View>
          </>
        )}

        {/* Top — status + participant info */}
        <View
          style={{
            paddingTop: insets.top + 24,
            paddingBottom: 24,
            alignItems: "center",
            gap: 8,
          }}
        >
          {/* Type badge */}
          <View
            style={{
              backgroundColor: "rgba(255,255,255,0.15)",
              paddingHorizontal: 14, paddingVertical: 5,
              borderRadius: 14, flexDirection: "row", alignItems: "center", gap: 5,
            }}
          >
            <Text style={{ fontSize: 13 }}>{isVideo ? "📹" : "📞"}</Text>
            <Text style={{ color: "#fff", fontSize: 12, fontWeight: "700" }}>
              {isVideo ? "Video call" : "Voice call"}
            </Text>
          </View>

          {/* Status */}
          <Text style={{ color: "rgba(255,255,255,0.8)", fontSize: 14, fontWeight: "600" }}>
            {isRinging ? "Ringing…" : isActive ? "Connected" : isEnded ? "Call ended" : ""}
          </Text>
        </View>

        {/* Avatar + name */}
        <View style={{ flex: 1, alignItems: "center", justifyContent: "center", gap: 20 }}>
          <View style={{ alignItems: "center", gap: 6 }}>
            {(!isVideo || !isActive) && (
              <View style={{ position: "relative", alignItems: "center", justifyContent: "center" }}>
                {/* Ripple rings (ringing only) */}
                {isRinging && (
                  <>
                    <RippleRing delay={0}    color="rgba(255,255,255,0.5)" />
                    <RippleRing delay={500}  color="rgba(255,255,255,0.35)" />
                    <RippleRing delay={1000} color="rgba(255,255,255,0.2)" />
                  </>
                )}
                <LinearGradient
                  colors={gradColors}
                  start={{ x: 0, y: 0 }} end={{ x: 1, y: 1 }}
                  style={{
                    width: 100, height: 100, borderRadius: 50,
                    alignItems: "center", justifyContent: "center",
                    borderWidth: 3, borderColor: "rgba(255,255,255,0.5)",
                    shadowColor: "#000", shadowOffset: { width: 0, height: 8 },
                    shadowOpacity: 0.4, shadowRadius: 16, elevation: 12,
                  }}
                >
                  <Text style={{ fontSize: 52 }}>{participant?.avatarEmoji}</Text>
                </LinearGradient>
              </View>
            )}

            <Text style={{ color: "#fff", fontSize: 28, fontWeight: "900", letterSpacing: -0.5 }}>
              {call.participants.length > 1
                ? call.participants.map((p) => p.name).join(", ")
                : participant?.name}
            </Text>
          </View>

          {/* Timer */}
          {isActive && (
            <View style={{ alignItems: "center", gap: 8 }}>
              <Text style={{ color: "#fff", fontSize: 42, fontWeight: "800", letterSpacing: 2, fontVariant: ["tabular-nums"] }}>
                {formatDuration(call.duration)}
              </Text>
              <TimerBar duration={call.duration} />
              <Text style={{ color: "rgba(255,255,255,0.5)", fontSize: 11 }}>
                Max call duration: 5 minutes
              </Text>
            </View>
          )}
        </View>

        {/* Controls */}
        <View
          style={{
            paddingBottom: insets.bottom + 32,
            paddingHorizontal: 32,
            gap: 32,
          }}
        >
          {isActive && (
            <View style={{ flexDirection: "row", justifyContent: "center", gap: 24 }}>
              <CtrlBtn
                emoji={call.isMicMuted ? "🎤" : "🎙"}
                label={call.isMicMuted ? "Unmute" : "Mute"}
                active={call.isMicMuted}
                activeColor="rgba(255,255,255,0.25)"
                onPress={toggleMic}
              />
              <CtrlBtn
                emoji={call.isSpeakerOn ? "🔊" : "🔈"}
                label={call.isSpeakerOn ? "Speaker" : "Speaker"}
                active={call.isSpeakerOn}
                activeColor={Colors.violet + "88"}
                onPress={toggleSpeaker}
              />
              {isVideo && (
                <CtrlBtn
                  emoji={call.isCameraOff ? "📷" : "📹"}
                  label={call.isCameraOff ? "Start cam" : "Stop cam"}
                  active={call.isCameraOff}
                  activeColor="rgba(255,255,255,0.25)"
                  onPress={toggleCamera}
                />
              )}
            </View>
          )}

          {/* End / decline */}
          <View style={{ flexDirection: "row", justifyContent: "center", gap: 40, alignItems: "center" }}>
            {isRinging && (
              <CtrlBtn
                emoji="📞"
                label="Accept"
                large
                activeColor="#16a34a"
                active
                onPress={() => useConnectionsStore.getState().acceptCall()}
              />
            )}
            <Pressable
              onPress={isRinging ? declineCall : endCall}
              style={({ pressed }) => ({
                width: 72, height: 72, borderRadius: 36,
                backgroundColor: Colors.primary,
                alignItems: "center", justifyContent: "center",
                opacity: pressed ? 0.85 : 1,
                transform: [{ scale: pressed ? 0.92 : 1 }],
                shadowColor: Colors.primary, shadowOffset: { width: 0, height: 6 },
                shadowOpacity: 0.5, shadowRadius: 12, elevation: 8,
              })}
            >
              <Text style={{ fontSize: 30, transform: [{ rotate: "135deg" }] }}>📞</Text>
            </Pressable>
          </View>
        </View>
      </LinearGradient>
    </Modal>
  );
}
