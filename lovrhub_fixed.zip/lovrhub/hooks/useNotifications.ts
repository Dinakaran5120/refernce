import { useMemo } from "react";
import { useNotificationStore } from "@/store/notificationStore";
import type { Notification, NotificationGroup, NotificationType } from "@/types/notification";
import { Colors } from "@constants/theme";

// ── Per-type display config ────────────────────────────────────────────────────
export interface NotifConfig {
  icon: string;
  color: string;
  bgColor: string;
  label: (n: Notification) => string;
  body: (n: Notification) => string;
}

export const NOTIF_CONFIG: Record<NotificationType, NotifConfig> = {
  follow: {
    icon: "👤",
    color: Colors.violet,
    bgColor: Colors.violet + "18",
    label: (n) => `${n.actor?.name ?? "Someone"} followed you`,
    body: () => "Tap to view their profile",
  },
  message: {
    icon: "💬",
    color: Colors.sky,
    bgColor: Colors.sky + "18",
    label: (n) => `${n.actor?.name ?? "Someone"} sent you a message`,
    body: (n) => n.targetPreview ?? "New message",
  },
  match: {
    icon: "💕",
    color: Colors.rose,
    bgColor: Colors.rose + "18",
    label: (n) => `You matched with ${n.actor?.name ?? "someone"}!`,
    body: () => "Start a conversation →",
  },
  like_post: {
    icon: "❤️",
    color: Colors.primary,
    bgColor: Colors.primary + "18",
    label: (n) => `${n.actor?.name ?? "Someone"} liked your post`,
    body: (n) => n.targetPreview ? `"${n.targetPreview.slice(0, 50)}…"` : "See your post",
  },
  like_profile: {
    icon: "🔥",
    color: Colors.accent,
    bgColor: Colors.accent + "18",
    label: (n) => `${n.actor?.name ?? "Someone"} liked your profile`,
    body: () => "Like them back to match",
  },
  super_like: {
    icon: "⭐",
    color: "#3b82f6",
    bgColor: "#3b82f618",
    label: (n) => `${n.actor?.name ?? "Someone"} super liked you!`,
    body: () => "They really like you — check them out",
  },
  comment: {
    icon: "💬",
    color: Colors.violet,
    bgColor: Colors.violet + "18",
    label: (n) => `${n.actor?.name ?? "Someone"} commented on your post`,
    body: (n) => n.targetPreview ? `"${n.targetPreview.slice(0, 60)}…"` : "See the comment",
  },
  mention: {
    icon: "@",
    color: Colors.gold,
    bgColor: Colors.gold + "18",
    label: (n) => `${n.actor?.name ?? "Someone"} mentioned you`,
    body: (n) => n.targetPreview ? `"${n.targetPreview.slice(0, 60)}…"` : "See the post",
  },
  community_post: {
    icon: "📝",
    color: Colors.secondary,
    bgColor: Colors.secondary + "18",
    label: (n) => `New post in ${n.communityName ?? "a community"}`,
    body: (n) => n.targetPreview ? `${n.actor?.name}: "${n.targetPreview.slice(0, 50)}…"` : "View post",
  },
  community_join_request: {
    icon: "🔔",
    color: Colors.gold,
    bgColor: Colors.gold + "18",
    label: (n) => `${n.actor?.name ?? "Someone"} wants to join ${n.communityName ?? "your community"}`,
    body: (n) => n.targetPreview ? `"${n.targetPreview.slice(0, 60)}…"` : "Review request",
  },
  community_join_approved: {
    icon: "✅",
    color: Colors.mint,
    bgColor: Colors.mint + "18",
    label: (n) => `You're now a member of ${n.communityName ?? "a community"}`,
    body: () => "Welcome! Start exploring the community feed",
  },
  community_join_rejected: {
    icon: "❌",
    color: Colors.textMuted,
    bgColor: Colors.textMuted + "18",
    label: (n) => `Your request to join ${n.communityName ?? "a community"} was declined`,
    body: () => "You can try other communities",
  },
  profile_view: {
    icon: "👁",
    color: Colors.rose,
    bgColor: Colors.rose + "18",
    label: (n) => `${n.actor?.name ?? "Someone"} viewed your profile`,
    body: () => "They might be interested — check them out",
  },
  system: {
    icon: "🔔",
    color: Colors.primary,
    bgColor: Colors.primary + "18",
    label: () => "Lovrhub",
    body: (n) => n.targetPreview ?? "System notification",
  },
};

// ── Group config ───────────────────────────────────────────────────────────────
export const GROUP_CONFIG: Record<NotificationGroup | "all", { label: string; emoji: string; color: string }> = {
  all:         { label: "All",        emoji: "🔔", color: Colors.primary },
  social:      { label: "Social",     emoji: "❤️", color: Colors.rose    },
  messages:    { label: "Messages",   emoji: "💬", color: Colors.sky     },
  activity:    { label: "Activity",   emoji: "✦",  color: Colors.violet  },
  communities: { label: "Communities",emoji: "🏘️", color: Colors.accent  },
  system:      { label: "System",     emoji: "📣", color: Colors.gold    },
};

// ── useMemo-powered hooks ──────────────────────────────────────────────────────

/** Filtered + grouped notification list for the active tab */
export function useFilteredNotifications(): Notification[] {
  const notifications = useNotificationStore((s) => s.notifications);
  const activeGroup   = useNotificationStore((s) => s.activeGroup);

  return useMemo(() => {
    const list = activeGroup === "all"
      ? notifications
      : notifications.filter((n) => n.group === activeGroup);

    return [...list].sort(
      (a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime()
    );
  }, [notifications, activeGroup]);
}

/** Unread count per group — for badges on tab pills */
export function useGroupUnreadCounts(): Record<NotificationGroup | "all", number> {
  const notifications = useNotificationStore((s) => s.notifications);

  return useMemo(() => {
    const unread = notifications.filter((n) => !n.read);
    return {
      all:         unread.length,
      social:      unread.filter((n) => n.group === "social").length,
      messages:    unread.filter((n) => n.group === "messages").length,
      activity:    unread.filter((n) => n.group === "activity").length,
      communities: unread.filter((n) => n.group === "communities").length,
      system:      unread.filter((n) => n.group === "system").length,
    };
  }, [notifications]);
}

/** Total unread — for bell badge */
export function useTotalUnread(): number {
  const notifications = useNotificationStore((s) => s.notifications);
  return useMemo(() => notifications.filter((n) => !n.read).length, [notifications]);
}

/** Time-ago formatter */
export function notifTimeAgo(iso: string): string {
  const diff  = Date.now() - new Date(iso).getTime();
  const mins  = Math.floor(diff / 60000);
  const hours = Math.floor(diff / 3600000);
  const days  = Math.floor(diff / 86400000);
  if (mins < 1)    return "just now";
  if (mins < 60)   return `${mins}m`;
  if (hours < 24)  return `${hours}h`;
  if (days === 1)  return "yesterday";
  if (days < 7)    return `${days}d`;
  return new Date(iso).toLocaleDateString("en-IN", { day: "numeric", month: "short" });
}

/** Groups consecutive notifications by date bucket */
export function groupByDate(notifications: Notification[]): { label: string; items: Notification[] }[] {
  const buckets: Record<string, Notification[]> = {};

  for (const n of notifications) {
    const diff = Date.now() - new Date(n.createdAt).getTime();
    const label =
      diff < 3600000         ? "Just now"
      : diff < 86400000      ? "Today"
      : diff < 2 * 86400000  ? "Yesterday"
      : diff < 7 * 86400000  ? "This week"
      : "Earlier";
    if (!buckets[label]) buckets[label] = [];
    buckets[label].push(n);
  }

  const ORDER = ["Just now", "Today", "Yesterday", "This week", "Earlier"];
  return ORDER.filter((l) => buckets[l])
    .map((label) => ({ label, items: buckets[label] }));
}
