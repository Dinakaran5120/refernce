import { useState, useRef, useCallback } from "react";
import {
  View, Text, Modal, Pressable, Dimensions,
  FlatList, ViewToken,
} from "react-native";
import { LinearGradient } from "expo-linear-gradient";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import { Colors } from "@constants/theme";
import { useExploreStore } from "@/store/exploreStore";
import { fmtCount } from "@/hooks/useExploreFeed";
import { MOCK_REELS } from "@/data/mockExplorePosts";
import type { ExplorePost, VibeType } from "@/types/explore";

const { width: W, height: H } = Dimensions.get("window");

function ReelItem({
  item,
  isActive,
}: {
  item: ExplorePost;
  isActive: boolean;
}) {
  const reactVibe       = useExploreStore((s) => s.reactVibe);
  const setShowComments = useExploreStore((s) => s.setShowComments);
  const sharePost       = useExploreStore((s) => s.sharePost);
  const insets          = useSafeAreaInsets();

  const [playing, setPlaying] = useState(false);
  const totalVibes = item.vibes.reduce((s, v) => s + v.count, 0);
  const myReaction = item.vibes.find((v) => v.reacted);

  const topVibes = [...item.vibes]
    .filter((v) => v.count > 0)
    .sort((a, b) => b.count - a.count)
    .slice(0, 3);

  return (
    <View style={{ width: W, height: H, backgroundColor: "#000" }}>
      {/* Full-screen video placeholder */}
      <Pressable
        onPress={() => setPlaying((p) => !p)}
        style={{ position: "absolute", top: 0, left: 0, right: 0, bottom: 0 }}
      >
        <LinearGradient
          colors={item.mediaGradient ?? [Colors.violet, Colors.rose]}
          start={{ x: 0, y: 0 }} end={{ x: 1, y: 1 }}
          style={{ flex: 1, alignItems: "center", justifyContent: "center" }}
        >
          <Text style={{ fontSize: 100 }}>{item.mediaEmoji}</Text>

          {/* Play / pause indicator */}
          {!playing && (
            <View
              style={{
                position: "absolute",
                width: 70,
                height: 70,
                borderRadius: 35,
                backgroundColor: "rgba(0,0,0,0.45)",
                alignItems: "center",
                justifyContent: "center",
                borderWidth: 2,
                borderColor: "rgba(255,255,255,0.6)",
              }}
            >
              <Text style={{ fontSize: 26, color: "#fff", marginLeft: 5 }}>▶</Text>
            </View>
          )}
        </LinearGradient>
      </Pressable>

      {/* Bottom overlay — caption, author, tags */}
      <LinearGradient
        colors={["transparent", "rgba(0,0,0,0.85)"]}
        style={{
          position: "absolute",
          bottom: 0, left: 0, right: 0,
          paddingBottom: insets.bottom + 90,
          paddingTop: 80,
          paddingLeft: 16,
          paddingRight: 72,
        }}
        pointerEvents="none"
      >
        {/* Author */}
        <View style={{ flexDirection: "row", alignItems: "center", gap: 10, marginBottom: 10 }}>
          <LinearGradient
            colors={item.author.gradient}
            start={{ x: 0, y: 0 }} end={{ x: 1, y: 1 }}
            style={{ width: 40, height: 40, borderRadius: 20, alignItems: "center", justifyContent: "center", borderWidth: 2, borderColor: "#fff" }}
          >
            <Text style={{ fontSize: 18 }}>{item.author.avatarEmoji}</Text>
          </LinearGradient>
          <View>
            <Text style={{ color: "#fff", fontSize: 14, fontWeight: "800" }}>
              {item.author.name}
            </Text>
            {item.location && (
              <Text style={{ color: "rgba(255,255,255,0.7)", fontSize: 12 }}>
                📍 {item.location}
              </Text>
            )}
          </View>
        </View>

        {/* Caption */}
        <Text
          style={{
            color: "#fff",
            fontSize: 14,
            lineHeight: 21,
            marginBottom: 10,
            fontWeight: "500",
          }}
          numberOfLines={3}
        >
          {item.caption}
        </Text>

        {/* Tags */}
        <View style={{ flexDirection: "row", flexWrap: "wrap", gap: 6 }}>
          {item.tags.map((tag) => (
            <Text key={tag} style={{ color: "rgba(255,255,255,0.85)", fontSize: 12, fontWeight: "700" }}>
              {tag}
            </Text>
          ))}
        </View>
      </LinearGradient>

      {/* Right action column */}
      <View
        style={{
          position: "absolute",
          right: 12,
          bottom: insets.bottom + 100,
          gap: 20,
          alignItems: "center",
        }}
      >
        {/* Primary vibe (heart) */}
        <Pressable
          onPress={() => reactVibe(item.id, "❤️")}
          style={({ pressed }) => ({
            alignItems: "center", gap: 4,
            opacity: pressed ? 0.7 : 1,
            transform: [{ scale: pressed ? 0.88 : 1 }],
          })}
        >
          <View
            style={{
              width: 48, height: 48, borderRadius: 24,
              backgroundColor: "rgba(255,255,255,0.15)",
              alignItems: "center", justifyContent: "center",
            }}
          >
            <Text style={{ fontSize: 24 }}>
              {item.vibes[0].reacted ? "❤️" : "🤍"}
            </Text>
          </View>
          <Text style={{ color: "#fff", fontSize: 12, fontWeight: "700" }}>
            {fmtCount(item.vibes[0].count)}
          </Text>
        </Pressable>

        {/* Fire vibe */}
        <Pressable
          onPress={() => reactVibe(item.id, "🔥")}
          style={({ pressed }) => ({
            alignItems: "center", gap: 4,
            opacity: pressed ? 0.7 : 1,
            transform: [{ scale: pressed ? 0.88 : 1 }],
          })}
        >
          <View
            style={{
              width: 48, height: 48, borderRadius: 24,
              backgroundColor: "rgba(255,255,255,0.15)",
              alignItems: "center", justifyContent: "center",
            }}
          >
            <Text style={{ fontSize: 24 }}>🔥</Text>
          </View>
          <Text style={{ color: "#fff", fontSize: 12, fontWeight: "700" }}>
            {fmtCount(item.vibes[2].count)}
          </Text>
        </Pressable>

        {/* Comment */}
        <Pressable
          onPress={() => setShowComments(item.id)}
          style={({ pressed }) => ({
            alignItems: "center", gap: 4,
            opacity: pressed ? 0.7 : 1,
          })}
        >
          <View
            style={{
              width: 48, height: 48, borderRadius: 24,
              backgroundColor: "rgba(255,255,255,0.15)",
              alignItems: "center", justifyContent: "center",
            }}
          >
            <Text style={{ fontSize: 22 }}>💬</Text>
          </View>
          <Text style={{ color: "#fff", fontSize: 12, fontWeight: "700" }}>
            {fmtCount(item.comments.length)}
          </Text>
        </Pressable>

        {/* Share */}
        <Pressable
          onPress={() => sharePost(item.id)}
          style={({ pressed }) => ({
            alignItems: "center", gap: 4,
            opacity: pressed ? 0.7 : 1,
          })}
        >
          <View
            style={{
              width: 48, height: 48, borderRadius: 24,
              backgroundColor: "rgba(255,255,255,0.15)",
              alignItems: "center", justifyContent: "center",
            }}
          >
            <Text style={{ fontSize: 22 }}>↗️</Text>
          </View>
          <Text style={{ color: "#fff", fontSize: 12, fontWeight: "700" }}>
            {fmtCount(item.shares)}
          </Text>
        </Pressable>

        {/* Spark */}
        <Pressable
          onPress={() => reactVibe(item.id, "✨")}
          style={({ pressed }) => ({
            alignItems: "center", gap: 4,
            opacity: pressed ? 0.7 : 1,
          })}
        >
          <View
            style={{
              width: 48, height: 48, borderRadius: 24,
              backgroundColor: "rgba(255,255,255,0.15)",
              alignItems: "center", justifyContent: "center",
            }}
          >
            <Text style={{ fontSize: 22 }}>✨</Text>
          </View>
          <Text style={{ color: "#fff", fontSize: 12, fontWeight: "700" }}>
            {fmtCount(item.vibes[5].count)}
          </Text>
        </Pressable>
      </View>

      {/* Duration badge */}
      <View
        style={{
          position: "absolute",
          top: 16,
          right: 16,
          backgroundColor: "rgba(0,0,0,0.5)",
          paddingHorizontal: 10,
          paddingVertical: 4,
          borderRadius: 10,
        }}
      >
        <Text style={{ color: "#fff", fontSize: 12, fontWeight: "700" }}>
          {item.videoDuration}
        </Text>
      </View>
    </View>
  );
}

export function ReelsViewer({
  visible,
  startIndex,
  onClose,
}: {
  visible: boolean;
  startIndex: number;
  onClose: () => void;
}) {
  const insets = useSafeAreaInsets();
  const [activeIndex, setActiveIndex] = useState(startIndex);
  const posts = useExploreStore((s) => s.posts).filter((p) => p.type === "video");

  const onViewableItemsChanged = useCallback(
    ({ viewableItems }: { viewableItems: ViewToken[] }) => {
      if (viewableItems.length > 0) {
        setActiveIndex(viewableItems[0].index ?? 0);
      }
    },
    []
  );

  const viewabilityConfig = { itemVisiblePercentThreshold: 60 };

  return (
    <Modal
      visible={visible}
      animationType="slide"
      statusBarTranslucent
      onRequestClose={onClose}
    >
      <View style={{ flex: 1, backgroundColor: "#000" }}>
        {/* Close button */}
        <Pressable
          onPress={onClose}
          style={{
            position: "absolute",
            top: insets.top + 12,
            left: 16,
            zIndex: 100,
            width: 38,
            height: 38,
            borderRadius: 19,
            backgroundColor: "rgba(0,0,0,0.5)",
            alignItems: "center",
            justifyContent: "center",
          }}
        >
          <Text style={{ color: "#fff", fontSize: 18 }}>✕</Text>
        </Pressable>

        {/* Reels label */}
        <View
          style={{
            position: "absolute",
            top: insets.top + 12,
            left: 0,
            right: 0,
            alignItems: "center",
            zIndex: 99,
            pointerEvents: "none",
          }}
        >
          <Text style={{ color: "#fff", fontSize: 15, fontWeight: "800", letterSpacing: 0.5 }}>
            Reels
          </Text>
        </View>

        <FlatList
          data={posts}
          keyExtractor={(p) => p.id}
          renderItem={({ item, index }) => (
            <ReelItem item={item} isActive={index === activeIndex} />
          )}
          pagingEnabled
          vertical
          showsVerticalScrollIndicator={false}
          onViewableItemsChanged={onViewableItemsChanged}
          viewabilityConfig={viewabilityConfig}
          initialScrollIndex={startIndex}
          getItemLayout={(_, index) => ({
            length: H,
            offset: H * index,
            index,
          })}
        />
      </View>
    </Modal>
  );
}
