import { View, Text, Pressable } from "react-native";
import { LinearGradient } from "expo-linear-gradient";
import { Colors } from "@constants/theme";
import { useCommunityStore } from "@/store/communityStore";
import { fmtNum, timeAgo } from "@/hooks/useCommunity";
import type { Community } from "@/types/community";

const PRIVACY_LABELS = {
  public:  { label: "Public",  emoji: "🌐", color: Colors.mint },
  private: { label: "Private", emoji: "🔒", color: Colors.gold },
};

const STATUS_CONFIG: Record<string, { label: string; bg: string; fg: string }> = {
  member:  { label: "Joined ✓",       bg: Colors.primary + "18", fg: Colors.primary },
  owner:   { label: "Owner ✓",        bg: Colors.gold + "22",    fg: Colors.gold     },
  admin:   { label: "Admin ✓",        bg: Colors.violet + "18",  fg: Colors.violet   },
  pending: { label: "⏳ Pending",      bg: Colors.textMuted + "18", fg: Colors.textMuted },
  none:    { label: "Join",           bg: Colors.primary,        fg: "#fff"          },
};

export function CommunityCard({
  community,
  onPress,
  compact = false,
}: {
  community: Community;
  onPress: () => void;
  compact?: boolean;
}) {
  const joinCommunity       = useCommunityStore((s) => s.joinCommunity);
  const setShowJoinRequest  = useCommunityStore((s) => s.setShowJoinRequest);

  const privacy = PRIVACY_LABELS[community.privacy];
  const status  = STATUS_CONFIG[community.myStatus] ?? STATUS_CONFIG.none;
  const isMember = community.myStatus === "member" || community.myStatus === "owner" || community.myStatus === "admin";

  const handleJoinPress = (e: any) => {
    e.stopPropagation?.();
    if (community.privacy === "public") {
      joinCommunity(community.id);
    } else {
      setShowJoinRequest(community.id);
    }
  };

  if (compact) {
    return (
      <Pressable
        onPress={onPress}
        style={({ pressed }) => ({
          flexDirection: "row", alignItems: "center", gap: 12,
          padding: 12, borderRadius: 16,
          backgroundColor: Colors.surface,
          borderWidth: 1, borderColor: Colors.border,
          marginBottom: 8,
          opacity: pressed ? 0.85 : 1,
        })}
      >
        <LinearGradient
          colors={community.coverGradient}
          start={{ x: 0, y: 0 }} end={{ x: 1, y: 1 }}
          style={{ width: 48, height: 48, borderRadius: 14, alignItems: "center", justifyContent: "center" }}
        >
          <Text style={{ fontSize: 24 }}>{community.coverEmoji}</Text>
        </LinearGradient>
        <View style={{ flex: 1, gap: 2 }}>
          <View style={{ flexDirection: "row", alignItems: "center", gap: 6 }}>
            <Text style={{ fontSize: 14, fontWeight: "700", color: Colors.text }} numberOfLines={1}>
              {community.name}
            </Text>
            {community.isVerified && (
              <View style={{ width: 14, height: 14, borderRadius: 7, backgroundColor: "#3b82f6", alignItems: "center", justifyContent: "center" }}>
                <Text style={{ color: "#fff", fontSize: 8, fontWeight: "800" }}>✓</Text>
              </View>
            )}
          </View>
          <Text style={{ fontSize: 12, color: Colors.textMuted }}>
            {fmtNum(community.memberCount)} members · {privacy.emoji} {privacy.label}
          </Text>
        </View>
        <View style={{ paddingHorizontal: 12, paddingVertical: 6, borderRadius: 12, backgroundColor: status.bg }}>
          <Text style={{ fontSize: 12, fontWeight: "700", color: status.fg }}>{status.label}</Text>
        </View>
      </Pressable>
    );
  }

  return (
    <Pressable
      onPress={onPress}
      style={({ pressed }) => ({
        borderRadius: 20, overflow: "hidden",
        backgroundColor: Colors.surface,
        borderWidth: 1, borderColor: Colors.border,
        marginBottom: 14,
        shadowColor: "#000", shadowOffset: { width: 0, height: 3 },
        shadowOpacity: 0.07, shadowRadius: 10, elevation: 3,
        opacity: pressed ? 0.95 : 1,
      })}
    >
      {/* Cover banner */}
      <LinearGradient
        colors={community.coverGradient}
        start={{ x: 0, y: 0 }} end={{ x: 1, y: 1 }}
        style={{ height: 96, alignItems: "flex-end", justifyContent: "flex-start", padding: 12 }}
      >
        {/* Privacy badge */}
        <View
          style={{
            flexDirection: "row", alignItems: "center", gap: 4,
            backgroundColor: "rgba(0,0,0,0.35)",
            paddingHorizontal: 10, paddingVertical: 4, borderRadius: 12,
          }}
        >
          <Text style={{ fontSize: 11 }}>{privacy.emoji}</Text>
          <Text style={{ color: "#fff", fontSize: 11, fontWeight: "700" }}>{privacy.label}</Text>
        </View>
        {/* Large emoji */}
        <Text
          style={{
            position: "absolute", bottom: 10, left: 16,
            fontSize: 40,
          }}
        >
          {community.coverEmoji}
        </Text>
      </LinearGradient>

      {/* Content */}
      <View style={{ padding: 14, gap: 8 }}>
        {/* Name row */}
        <View style={{ flexDirection: "row", alignItems: "center", gap: 6 }}>
          <Text style={{ fontSize: 16, fontWeight: "800", color: Colors.text, flex: 1 }} numberOfLines={1}>
            {community.name}
          </Text>
          {community.isVerified && (
            <View style={{ width: 18, height: 18, borderRadius: 9, backgroundColor: "#3b82f6", alignItems: "center", justifyContent: "center" }}>
              <Text style={{ color: "#fff", fontSize: 10, fontWeight: "800" }}>✓</Text>
            </View>
          )}
        </View>

        {/* Description */}
        <Text style={{ fontSize: 13, color: Colors.textSecondary, lineHeight: 19 }} numberOfLines={2}>
          {community.description}
        </Text>

        {/* Stats row */}
        <View style={{ flexDirection: "row", alignItems: "center", gap: 16 }}>
          <Text style={{ fontSize: 12, color: Colors.textMuted, fontWeight: "600" }}>
            👥 {fmtNum(community.memberCount)}
          </Text>
          <Text style={{ fontSize: 12, color: Colors.textMuted, fontWeight: "600" }}>
            📝 {fmtNum(community.postCount)}
          </Text>
          <Text style={{ fontSize: 12, color: Colors.textMuted }}>
            Active {timeAgo(community.lastActivityAt)}
          </Text>
        </View>

        {/* Tags */}
        <View style={{ flexDirection: "row", flexWrap: "wrap", gap: 6 }}>
          {community.tags.slice(0, 3).map((tag) => (
            <View
              key={tag}
              style={{
                paddingHorizontal: 10, paddingVertical: 4, borderRadius: 10,
                backgroundColor: Colors.card, borderWidth: 1, borderColor: Colors.border,
              }}
            >
              <Text style={{ fontSize: 11, color: Colors.textSecondary, fontWeight: "600" }}>{tag}</Text>
            </View>
          ))}
        </View>

        {/* Member avatars + join button */}
        <View style={{ flexDirection: "row", alignItems: "center", justifyContent: "space-between" }}>
          {/* Member stack */}
          <View style={{ flexDirection: "row" }}>
            {community.members.slice(0, 4).map((m, i) => (
              <LinearGradient
                key={m.id}
                colors={m.gradient}
                start={{ x: 0, y: 0 }} end={{ x: 1, y: 1 }}
                style={{
                  width: 28, height: 28, borderRadius: 14,
                  alignItems: "center", justifyContent: "center",
                  marginLeft: i > 0 ? -8 : 0,
                  borderWidth: 2, borderColor: Colors.surface,
                }}
              >
                <Text style={{ fontSize: 13 }}>{m.avatarEmoji}</Text>
              </LinearGradient>
            ))}
            {community.memberCount > 4 && (
              <View
                style={{
                  width: 28, height: 28, borderRadius: 14,
                  backgroundColor: Colors.card,
                  alignItems: "center", justifyContent: "center",
                  marginLeft: -8, borderWidth: 2, borderColor: Colors.surface,
                }}
              >
                <Text style={{ fontSize: 11, color: Colors.textMuted, fontWeight: "700" }}>
                  +{fmtNum(community.memberCount - 4)}
                </Text>
              </View>
            )}
          </View>

          {/* Join / status button */}
          {isMember ? (
            <View style={{ paddingHorizontal: 16, paddingVertical: 8, borderRadius: 14, backgroundColor: status.bg }}>
              <Text style={{ fontSize: 13, fontWeight: "700", color: status.fg }}>{status.label}</Text>
            </View>
          ) : community.myStatus === "pending" ? (
            <View style={{ paddingHorizontal: 16, paddingVertical: 8, borderRadius: 14, backgroundColor: Colors.card, borderWidth: 1, borderColor: Colors.border }}>
              <Text style={{ fontSize: 13, fontWeight: "700", color: Colors.textMuted }}>⏳ Pending</Text>
            </View>
          ) : (
            <Pressable
              onPress={handleJoinPress}
              style={({ pressed }) => ({ opacity: pressed ? 0.85 : 1, transform: [{ scale: pressed ? 0.96 : 1 }] })}
            >
              <LinearGradient
                colors={[Colors.primary, Colors.accent]}
                start={{ x: 0, y: 0 }} end={{ x: 1, y: 0 }}
                style={{ paddingHorizontal: 18, paddingVertical: 9, borderRadius: 14 }}
              >
                <Text style={{ color: "#fff", fontSize: 13, fontWeight: "800" }}>
                  {community.privacy === "private" ? "🔒 Request" : "Join →"}
                </Text>
              </LinearGradient>
            </Pressable>
          )}
        </View>
      </View>
    </Pressable>
  );
}
