import { useMemo } from "react";
import { useCommunityStore } from "@/store/communityStore";
import type { Community, CommunityPost } from "@/types/community";

/** All communities the current user is a member/owner of */
export function useMyCommunitites(): Community[] {
  const communities = useCommunityStore((s) => s.communities);
  return useMemo(
    () => communities.filter((c) => c.myStatus === "member" || c.myStatus === "owner" || c.myStatus === "admin"),
    [communities]
  );
}

/** Communities user has not joined yet */
export function useDiscoverCommunities(search: string): Community[] {
  const communities = useCommunityStore((s) => s.communities);
  return useMemo(() => {
    const q = search.toLowerCase().trim();
    return communities
      .filter((c) => c.myStatus === "none" || c.myStatus === "pending")
      .filter((c) =>
        !q ||
        c.name.toLowerCase().includes(q) ||
        c.description.toLowerCase().includes(q) ||
        c.tags.some((t) => t.toLowerCase().includes(q))
      );
  }, [communities, search]);
}

/** Active community object */
export function useActiveCommunity(): Community | null {
  const id          = useCommunityStore((s) => s.activeCommunityId);
  const communities = useCommunityStore((s) => s.communities);
  return useMemo(() => communities.find((c) => c.id === id) ?? null, [communities, id]);
}

/** Posts for a specific community — pinned first, then chronological */
export function useCommunityFeed(communityId: string): CommunityPost[] {
  const posts = useCommunityStore((s) => s.posts);
  return useMemo(() => {
    const list = posts[communityId] ?? [];
    return [...list].sort((a, b) => {
      if (a.isPinned !== b.isPinned) return a.isPinned ? -1 : 1;
      return new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime();
    });
  }, [posts, communityId]);
}

/** Pending request count for communities I own/admin */
export function usePendingRequestCount(): number {
  const communities = useCommunityStore((s) => s.communities);
  return useMemo(
    () =>
      communities
        .filter((c) => c.myStatus === "owner" || c.myStatus === "admin")
        .reduce((sum, c) => sum + c.pendingRequests.length, 0),
    [communities]
  );
}

/** Time-ago from ISO string */
export function timeAgo(iso: string): string {
  const diff  = Date.now() - new Date(iso).getTime();
  const mins  = Math.floor(diff / 60000);
  const hours = Math.floor(diff / 3600000);
  const days  = Math.floor(diff / 86400000);
  if (mins < 1)   return "just now";
  if (mins < 60)  return `${mins}m ago`;
  if (hours < 24) return `${hours}h ago`;
  return `${days}d ago`;
}

/** Format large numbers */
export function fmtNum(n: number): string {
  if (n >= 1000000) return `${(n / 1000000).toFixed(1)}m`;
  if (n >= 1000)    return `${(n / 1000).toFixed(1)}k`;
  return String(n);
}

/** Total poll votes */
export function totalPollVotes(options: { votes: number }[]): number {
  return options.reduce((s, o) => s + o.votes, 0);
}
