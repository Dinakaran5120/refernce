import { useState, useMemo } from "react";
import {
  View, Text, ScrollView, Pressable, TextInput,
} from "react-native";
import { LinearGradient } from "expo-linear-gradient";
import { Ionicons } from "@expo/vector-icons";
import { useTheme } from "@/context/ThemeContext";
import { useExploreStore } from "@/store/exploreStore";
import { useExploreFeed } from "@/hooks/useExploreFeed";
import { PostCard } from "@components/explore/PostCards";
import { CommentsSheet } from "@components/explore/CommentsSheet";
import { ReelsViewer } from "@components/explore/ReelsViewer";
import { ShareMoodCard, CreatePostModal } from "@components/explore/ShareMoodCard";
import type { ExploreFeedTab } from "@/types/explore";

// ── Tab bar ───────────────────────────────────────────────────────────────────
const TABS: { id: ExploreFeedTab; label: string; icon: React.ComponentProps<typeof Ionicons>["name"] }[] = [
  { id: "forYou",   label: "For You",  icon: "sparkles-outline"  },
  { id: "trending", label: "Trending", icon: "trending-up-outline"},
  { id: "vibes",    label: "Vibes",    icon: "color-palette-outline"},
  { id: "reels",    label: "Reels",    icon: "play-circle-outline"},
];

function FeedTabBar() {
  const { colors } = useTheme();
  const activeTab  = useExploreStore((s) => s.activeTab);
  const setTab     = useExploreStore((s) => s.setActiveTab);

  return (
    <View
      style={{
        flexDirection: "row",
        borderBottomWidth: 1,
        borderBottomColor: colors.border,
        backgroundColor: colors.surface,
      }}
    >
      {TABS.map((tab) => {
        const isActive = activeTab === tab.id;
        return (
          <Pressable
            key={tab.id}
            onPress={() => setTab(tab.id)}
            style={{
              flex: 1,
              alignItems: "center",
              paddingVertical: 12,
              borderBottomWidth: 2.5,
              borderBottomColor: isActive ? colors.primary : "transparent",
            }}
          >
            <View style={{ flexDirection: "row", alignItems: "center", gap: 4 }}>
              <Ionicons
                name={tab.icon}
                size={14}
                color={isActive ? colors.primary : colors.textMuted}
              />
              <Text
                style={{
                  fontSize: 12,
                  fontWeight: isActive ? "800" : "600",
                  color: isActive ? colors.primary : colors.textMuted,
                  letterSpacing: 0.2,
                }}
              >
                {tab.label}
              </Text>
            </View>
          </Pressable>
        );
      })}
    </View>
  );
}

// ── Vibes header ──────────────────────────────────────────────────────────────
function VibesHeader() {
  const { colors } = useTheme();
  return (
    <LinearGradient
      colors={[colors.violet + "22", colors.rose + "11"]}
      start={{ x: 0, y: 0 }} end={{ x: 1, y: 1 }}
      style={{ marginBottom: 12, padding: 18, gap: 6, borderBottomWidth: 1, borderBottomColor: colors.border }}
    >
      <Text style={{ fontSize: 20, fontWeight: "800", color: colors.text, letterSpacing: -0.3 }}>
        🌈 Vibes Feed
      </Text>
      <Text style={{ fontSize: 13, color: colors.textMuted, lineHeight: 19 }}>
        Anonymous moods and thoughts from people near you.{"\n"}Your feelings are valid here.
      </Text>
    </LinearGradient>
  );
}

// ── Trending header ────────────────────────────────────────────────────────────
function TrendingHeader() {
  const { colors } = useTheme();
  return (
    <LinearGradient
      colors={[colors.primary + "18", colors.accent + "0a"]}
      start={{ x: 0, y: 0 }} end={{ x: 1, y: 1 }}
      style={{ marginBottom: 12, padding: 18, gap: 6, borderBottomWidth: 1, borderBottomColor: colors.border }}
    >
      <Text style={{ fontSize: 20, fontWeight: "800", color: colors.text, letterSpacing: -0.3 }}>
        🔥 Trending Now
      </Text>
      <Text style={{ fontSize: 13, color: colors.textMuted }}>
        Most-reacted posts in the last 24 hours
      </Text>
    </LinearGradient>
  );
}

// ── Reels tab ─────────────────────────────────────────────────────────────────
function ReelsTab() {
  const { colors } = useTheme();
  const [reelsOpen, setReelsOpen] = useState(true);
  const posts = useExploreStore((s) => s.posts).filter((p) => p.type === "video");

  return (
    <View style={{ flex: 1, backgroundColor: "#111", alignItems: "center", justifyContent: "center", gap: 16 }}>
      <View
        style={{
          width: 80,
          height: 80,
          borderRadius: 40,
          backgroundColor: "rgba(255,255,255,0.1)",
          alignItems: "center",
          justifyContent: "center",
          borderWidth: 2,
          borderColor: "rgba(255,255,255,0.15)",
        }}
      >
        <Ionicons name="play" size={36} color="#fff" />
      </View>
      <Text style={{ fontSize: 18, fontWeight: "800", color: "#fff" }}>
        {posts.length} Reels
      </Text>
      <Text style={{ fontSize: 14, color: "rgba(255,255,255,0.6)", textAlign: "center", paddingHorizontal: 40 }}>
        Short videos from people around you
      </Text>
      <Pressable
        onPress={() => setReelsOpen(true)}
        style={({ pressed }) => ({ opacity: pressed ? 0.85 : 1, transform: [{ scale: pressed ? 0.96 : 1 }] })}
      >
        <LinearGradient
          colors={[colors.primary, colors.accent]}
          start={{ x: 0, y: 0 }} end={{ x: 1, y: 0 }}
          style={{ paddingHorizontal: 32, paddingVertical: 16, borderRadius: 18, flexDirection: "row", alignItems: "center", gap: 8 }}
        >
          <Ionicons name="play" size={18} color="#fff" />
          <Text style={{ color: "#fff", fontSize: 16, fontWeight: "800" }}>Watch Reels</Text>
        </LinearGradient>
      </Pressable>

      <ReelsViewer visible={reelsOpen} startIndex={0} onClose={() => setReelsOpen(false)} />
    </View>
  );
}

// ── Main screen ────────────────────────────────────────────────────────────────
export default function ExploreScreen() {
  const { colors } = useTheme();
  const activeTab      = useExploreStore((s) => s.activeTab);
  const showCommentsId = useExploreStore((s) => s.showComments);
  const posts          = useExploreStore((s) => s.posts);
  const setShowCreate  = useExploreStore((s) => s.setShowCreatePost);

  const feed = useExploreFeed();

  const [reelsOpen, setReelsOpen] = useState(false);
  const [reelIndex, setReelIndex] = useState(0);
  const [search, setSearch]       = useState("");

  const commentPost = useMemo(
    () => posts.find((p) => p.id === showCommentsId) ?? null,
    [posts, showCommentsId]
  );

  const handleOpenReel = (postId: string) => {
    const allVideos = posts.filter((p) => p.type === "video");
    const idx = allVideos.findIndex((p) => p.id === postId);
    setReelIndex(Math.max(0, idx));
    setReelsOpen(true);
  };

  if (activeTab === "reels") {
    return (
      <View style={{ flex: 1 }}>
        <FeedTabBar />
        <ReelsTab />
      </View>
    );
  }

  return (
    <View style={{ flex: 1, backgroundColor: colors.background }}>
      <FeedTabBar />

      <ScrollView
        showsVerticalScrollIndicator={false}
        contentContainerStyle={{ paddingBottom: 32 }}
      >
        {/* Search bar */}
        <View
          style={{
            flexDirection: "row",
            alignItems: "center",
            marginHorizontal: 16,
            marginTop: 12,
            marginBottom: 4,
            backgroundColor: colors.inputBg,
            borderRadius: 16,
            paddingHorizontal: 14,
            paddingVertical: 10,
            borderWidth: 1,
            borderColor: colors.border,
            gap: 8,
          }}
        >
          <Ionicons name="search-outline" size={16} color={colors.textMuted} />
          <TextInput
            value={search}
            onChangeText={setSearch}
            placeholder="Search posts, moods, vibes…"
            placeholderTextColor={colors.textMuted}
            style={{ flex: 1, fontSize: 14, color: colors.text, padding: 0 }}
          />
          {search.length > 0 && (
            <Pressable onPress={() => setSearch("")}>
              <Ionicons name="close-circle" size={16} color={colors.textMuted} />
            </Pressable>
          )}
        </View>

        {/* Tab-specific header */}
        {activeTab === "vibes"    && <VibesHeader />}
        {activeTab === "trending" && <TrendingHeader />}

        {/* Share mood card */}
        {(activeTab === "forYou" || activeTab === "vibes") && (
          <View style={{ paddingHorizontal: 16, paddingTop: 12 }}>
            <ShareMoodCard />
          </View>
        )}

        {/* Feed */}
        <View style={{ paddingHorizontal: 16, paddingTop: 8 }}>
          {feed.length === 0 ? (
            <View style={{ alignItems: "center", paddingVertical: 48, gap: 12 }}>
              <View
                style={{
                  width: 72, height: 72, borderRadius: 36,
                  backgroundColor: colors.card,
                  alignItems: "center", justifyContent: "center",
                  borderWidth: 1, borderColor: colors.border,
                }}
              >
                <Ionicons name="leaf-outline" size={32} color={colors.textMuted} />
              </View>
              <Text style={{ fontSize: 16, fontWeight: "700", color: colors.text }}>Nothing here yet</Text>
              <Text style={{ fontSize: 14, color: colors.textMuted, textAlign: "center" }}>
                Be the first to post something
              </Text>
              <Pressable
                onPress={() => setShowCreate(true)}
                style={({ pressed }) => ({ opacity: pressed ? 0.8 : 1 })}
              >
                <LinearGradient
                  colors={[colors.primary, colors.accent]}
                  start={{ x: 0, y: 0 }} end={{ x: 1, y: 0 }}
                  style={{ paddingHorizontal: 24, paddingVertical: 12, borderRadius: 14, flexDirection: "row", alignItems: "center", gap: 6 }}
                >
                  <Ionicons name="add" size={18} color="#fff" />
                  <Text style={{ color: "#fff", fontWeight: "800", fontSize: 14 }}>Create Post</Text>
                </LinearGradient>
              </Pressable>
            </View>
          ) : (
            feed
              .filter((p) =>
                search.trim()
                  ? p.caption.toLowerCase().includes(search.toLowerCase()) ||
                    p.tags.some((t) => t.toLowerCase().includes(search.toLowerCase()))
                  : true
              )
              .map((post) => (
                <PostCard key={post.id} post={post} onOpenReel={() => handleOpenReel(post.id)} />
              ))
          )}
        </View>
      </ScrollView>

      {/* Comments sheet */}
      <CommentsSheet post={commentPost} />

      {/* Reels viewer */}
      <ReelsViewer visible={reelsOpen} startIndex={reelIndex} onClose={() => setReelsOpen(false)} />

      {/* Create post modal */}
      <CreatePostModal />

      {/* FAB */}
      {activeTab !== "reels" && (
        <View style={{ position: "absolute", bottom: 24, right: 20, zIndex: 50 }}>
          <Pressable
            onPress={() => setShowCreate(true)}
            style={({ pressed }) => ({ opacity: pressed ? 0.85 : 1, transform: [{ scale: pressed ? 0.93 : 1 }] })}
          >
            <LinearGradient
              colors={[colors.primary, colors.accent]}
              start={{ x: 0, y: 0 }} end={{ x: 1, y: 1 }}
              style={{
                width: 56, height: 56, borderRadius: 28,
                alignItems: "center", justifyContent: "center",
                shadowColor: colors.primary, shadowOffset: { width: 0, height: 6 },
                shadowOpacity: 0.4, shadowRadius: 12, elevation: 8,
              }}
            >
              <Ionicons name="add" size={28} color="#fff" />
            </LinearGradient>
          </Pressable>
        </View>
      )}
    </View>
  );
}
