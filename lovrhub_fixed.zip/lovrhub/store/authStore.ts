import { create } from "zustand";

export type AuthStep =
  | "welcome"
  | "phone"
  | "otp"
  | "email"
  | "setup_name"
  | "setup_age"
  | "setup_gender"
  | "setup_orientation"
  | "setup_interested_in"
  | "setup_relationship"
  | "setup_languages"
  | "setup_interests"
  | "setup_photo"
  | "done";

export interface UserProfile {
  phone: string;
  email: string;
  name: string;
  age: string;
  gender: string;
  orientation: string;
  interestedIn: string[];
  relationshipType: string[];
  languages: string[];
  interests: string[];
  photoEmoji: string;
}

interface AuthState {
  step: AuthStep;
  profile: UserProfile;
  isAuthenticated: boolean;
  setStep: (step: AuthStep) => void;
  updateProfile: (data: Partial<UserProfile>) => void;
  completeAuth: () => void;
  reset: () => void;
}

const DEFAULT_PROFILE: UserProfile = {
  phone: "",
  email: "",
  name: "",
  age: "",
  gender: "",
  orientation: "",
  interestedIn: [],
  relationshipType: [],
  languages: [],
  interests: [],
  photoEmoji: "",
};

export const useAuthStore = create<AuthState>((set) => ({
  step: "welcome",
  profile: DEFAULT_PROFILE,
  isAuthenticated: false,

  setStep: (step) => set({ step }),

  updateProfile: (data) =>
    set((state) => ({ profile: { ...state.profile, ...data } })),

  completeAuth: () => set({ isAuthenticated: true, step: "done" }),

  reset: () => set({ step: "welcome", profile: DEFAULT_PROFILE, isAuthenticated: false }),
}));
